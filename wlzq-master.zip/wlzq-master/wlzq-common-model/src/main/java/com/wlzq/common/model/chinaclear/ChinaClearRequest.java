package com.wlzq.common.model.chinaclear;

import java.util.List;

import lombok.Data;

/**
 * 中登请求参数
 * @author louie
 * @version 2017-10-18
 */
@Data
public class ChinaClearRequest {
	private String serviceDomain ;   //服务域
	private String serviceName ;		// 服务名
	private String serviceType ;		// 服务类型
	List<ChinaClearRequestValue> values; //请求参数
}