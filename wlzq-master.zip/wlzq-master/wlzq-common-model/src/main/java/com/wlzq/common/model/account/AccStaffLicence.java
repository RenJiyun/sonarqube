/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 员工职业编号Entity
 * @author zhaozx
 * @version 2019-09-27
 */
@Data
public class AccStaffLicence implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1758581534078112142L;
	private Integer id;	
	private String no;		// 员工号码
	private String typeName;		// 类型名称
	private Integer type;		// 证书类型
	private String licence;		// 证书编码
	private Date createTime;		// 创建时间
	private Integer isDelete;		// 是否删除，0-否，1-是
	
}