package com.wlzq.common.model.pay;

import com.wlzq.common.model.pay.constants.PayAgreementSource;

public enum PayAgreementBusiMethodEnum {
	/**决策商城周期付款协议**/
	VAS_PAY_AGREEMENT(PayAgreementSource.DECISION_GOODS, "vas.decisioncooperation.createcycleorder", "vas.decisioncooperation.checkpayagreementexecute");
	
	/**来源**/
	private  Integer source;
	/**创建订单方法**/
	private  String createBusiOrderMethod;
	/**检查协议方法**/
	private  String checkBusiAgreementMethod;
	
	PayAgreementBusiMethodEnum(Integer source, String createBusiOrderMethod, String checkBusiAgreementMethod) { 
		this.source = source;
		this.checkBusiAgreementMethod = checkBusiAgreementMethod;
		this.createBusiOrderMethod = createBusiOrderMethod;
	}
	
	public String getCheckBusiAgreementMethod() {
		return checkBusiAgreementMethod;
	}
	
	public String getCreateBusiOrderMethod() {
		return createBusiOrderMethod;
	}
	
	public Integer getSource() {
		return source;
	}
	
	/**
	 * 来源获取
	 * @param source
	 * @return
	 */
	public static PayAgreementBusiMethodEnum getBySource(Integer source) {
		if (source == null) {
			return null;
		}
		for (PayAgreementBusiMethodEnum each : PayAgreementBusiMethodEnum.values()) {
			if (source.equals(each.getSource())) {
				return each;
			}
		}
		return null;
	}
}
