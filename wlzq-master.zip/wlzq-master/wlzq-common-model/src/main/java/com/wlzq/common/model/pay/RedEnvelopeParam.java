/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.pay;

import lombok.Data;

/**
 * 红包Entity
 * @author louie
 * @version 2018-04-17
 */
@Data
public class RedEnvelopeParam {
	private String userId;		// 用户id
	private String openId;		// 用户openId
	private String mobile;		// 用户手机号
	private Integer amount;		// 金额
	private String businessCode;		// 业务编号
	private String businessNo;		// 业务单号
	private String nonceStr;		// 随机串
	private String notifyUrl;		// 回调平台地址
	private String remark;		// 备注
}