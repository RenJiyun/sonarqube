package com.wlzq.common.model.account;

import java.io.Serializable;
import java.util.Date;

public class Customer extends WCustomer implements Serializable {
	private static final long serialVersionUID = 78254763257L;

	/** 个人户类型 */
	public static final Integer USER_TYPE_PERSON = 0;
	/** 机构户类型 */
	public static final Integer USER_TYPE_ORG = 1;
	/** 自营户类型 */
	public static final Integer UER_TYPE_SELF = 2;
	/** 产品户类型 */
	public static final Integer USER_TYPE_PRODUCT = 3;
	/** 特法户类型 */
	public static final Integer USER_TYPE_SPECIAL = 4;
	
	private String jsessionid;
	private String user_id;
	private String user_name;
	private String mobile_phone;
	private String identity_num;
	private String client_no;
	private String fund_account;
	private String user_type;
	private String risk_level;
	private String risk_level_txt;
	private String fundAccount;
	private Integer loginBizType;
	private Date loginExpireTime;
	private String crhUserId; //财人汇userid
	private String client; //财人汇client，用于客户通信
	private String verifyId;
	public String getJsessionid() {
		return jsessionid;
	}
	public void setJsessionid(String jsessionid) {
		this.jsessionid = jsessionid;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getClient_no() {
		return client_no;
	}
	public void setClient_no(String client_no) {
		this.client_no = client_no;
	}
	public String getFund_account() {
		return fund_account;
	}
	public void setFund_account(String fund_account) {
		this.fund_account = fund_account;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public String getRisk_level() {
		return risk_level;
	}
	public void setRisk_level(String risk_level) {
		this.risk_level = risk_level;
	}
	public String getRisk_level_txt() {
		return risk_level_txt;
	}
	public void setRisk_level_txt(String risk_level_txt) {
		this.risk_level_txt = risk_level_txt;
	}
	public Integer getLoginBizType() {
		return loginBizType;
	}
	public void setLoginBizType(Integer loginBizType) {
		this.loginBizType = loginBizType;
	}
	public Date getLoginExpireTime() {
		return loginExpireTime;
	}
	public void setLoginExpireTime(Date loginExpireTime) {
		this.loginExpireTime = loginExpireTime;
	}
	public String getMobile_phone() {
		return mobile_phone;
	}
	public void setMobile_phone(String mobile_phone) {
		this.mobile_phone = mobile_phone;
	}
	public String getIdentity_num() {
		return identity_num;
	}
	public void setIdentity_num(String identity_num) {
		this.identity_num = identity_num;
	}
	public String getVerifyId() {
		return verifyId;
	}
	public void setVerifyId(String verifyId) {
		this.verifyId = verifyId;
	}
	public String getFundAccount() {
		return fundAccount;
	}
	public void setFundAccount(String fundAccount) {
		this.fundAccount = fundAccount;
	}
	public String getCrhUserId() {
		return crhUserId;
	}
	public void setCrhUserId(String crhUserId) {
		this.crhUserId = crhUserId;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
}
