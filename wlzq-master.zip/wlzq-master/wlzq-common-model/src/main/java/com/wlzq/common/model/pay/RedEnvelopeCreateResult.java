/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.pay;

import lombok.Data;

/**
 * 红包创建结果
 * @author louie
 * @version 2018-04-17
 */
@Data
public class RedEnvelopeCreateResult {
	private Integer amount;		// 金额
	private String businessCode;		// 业务编号
	private String businessNo;		// 业务单号
	private String orderNo;		// 订单号
	private String recieveUrl;	// 领取红包的链接
	
}