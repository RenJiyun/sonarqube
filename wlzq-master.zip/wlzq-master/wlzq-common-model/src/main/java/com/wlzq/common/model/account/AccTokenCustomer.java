package com.wlzq.common.model.account;

import java.io.Serializable;

import lombok.Data;

/**
 * 登录客户信息Entity
 * @author louie
 * @version 2017-09-15
 */
@Data
public class AccTokenCustomer implements Serializable {
	private static final long serialVersionUID = 121254763257L;
	private Integer type;		//类型，1：投顾平台，2：理财商城，3：同花顺验证
	private String customerId;		//客户ID
	private String fundAccount;  //资金账号
	
}