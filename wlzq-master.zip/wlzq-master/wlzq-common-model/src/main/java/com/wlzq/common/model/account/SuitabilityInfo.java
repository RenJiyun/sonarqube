package com.wlzq.common.model.account;

import java.io.Serializable;

import lombok.Data;

/**
 * 适当性判断信息
 * @author Administrator
 *
 */
@Data
public class SuitabilityInfo  implements Serializable{
	/**
	 * 无
	 */
	public static final String 	STATUS_NONE = "0";
	/**
	 * 过期
	 */
	public static final String 	STATUS_EXPIRE = "1";
	/**
	 * 有效
	 */
	public static final String 	STATUS_EFFECTIVE = "2";

	private static final long serialVersionUID = 54521543476457L;
	/**
	 * 客户号
	 */
	private String customerId;
	/**
	 * 客户类型，0：个人，1：机购
	 */
	private Integer customerType;
	/**
	 * 身份证有效标识，0：无，1：过期，2：有效
	 */
	private String identity_num_flag;
	/**
	 * 手机号有效标识，0：无，2：有效
	 */
	private String phone_flag;
	/**
	 * 风险等级
	 */
	private Integer riskLevel;
	/**
	 * 风险测评有效标识，0：未做/无，1：过期，2：有效
	 */
	private String risk_level_flag;
	/**
	 * 法人身份证有效标识，0：无，1：过期，2：有效
	 */
	private String instrepr_id_flag;
	/**
	 * 诚信记录
	 */
	private String creditRecord;
	/**
	 * 个人税收居民身份
	 */
	private String taxResidentPerson;
	
	/**
	 * 税收居民地区
	 */
	private String taxResidentCountry;
	
	/**
	 * 控制人证件类型
	 */
	private String controllerIdKind;
	/**
	 * 控制人证件号
	 */
	private String controllerIdNo;
	/**
	 * 控制人证件开始日期
	 */
	private String controllerIdBegindate;
	/**
	 * 控制人证件结束日期
	 */
	private String controllerIdEnddate;
	/**
	 * 控制人电话
	 */
	private String controllerTel;
	/**
	 * 受益人证件类型
	 */
	private String beneficiaryIdKind;
	/**
	 * 受益人证件号
	 */
	private String beneficiaryIdNo;
	/**
	 * 受益人证件开始日期
	 */
	private String beneficiaryIdBegindate;
	/**
	 * 受益人证件结束日期
	 */
	private String beneficiaryIdEnddate;
	/**
	 * 受益人电话
	 */
	private String beneficiaryTel;
}

