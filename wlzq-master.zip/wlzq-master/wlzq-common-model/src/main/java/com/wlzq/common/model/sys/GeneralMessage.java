/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.sys;

import lombok.Data;

/**
 * 常规消息（用于MQ）
 * @author louie
 * @version 2020-08-24
 */
@Data
public class GeneralMessage {
	private String value;
}