package com.wlzq.common.model.pay;

import lombok.Data;

/**
 * 订单参数
 * @author louie
 * @version 2017-12-18
 */
@Data
public class PayOrderParam {
	private Integer status;		// 支付状态
	private Integer payType;		// 支付方式
	private String timeEnd;      //支付完成时间
	private String userId;		// 用户ID
	private String subject;		// 订单标题
	private String body;		// 商品描述
	private String outTradeNo;		// 业务订单号
	private String orderNo;		// 支付订单号
	private String nonceStr;		// 随机串
	private Integer totalFee;		// 订单实付金额(单位：分)
	private Integer totalAmount;		// 订单总金额(单位：分)
	private Integer totalOrgAmount;		// 产品原价(单位：分)
	private String notifyUrl;		// 支付结果通知地址
	private String thirdUid;		// 第三方用户ID
	private Integer source;		// 来源，1：商城
	private Integer deviceType;		//设备类型，1：PC，2：安卓，3：IOS,4:其它
	private String customerId;   //客户号
	private String fundAccount;   //资金账号
	private String remark;		// 备注

	//订单来源平台与产品
	private Integer plate;		// 使用平台
	private String productCode;		// 订单产品编码
	private String productSpecification;		// 订单产品规格
	private String coupon;		// 优惠券编码
	private Integer couponDeduction;		// 优惠券抵扣金额
	
	private String agreementNo;	
}