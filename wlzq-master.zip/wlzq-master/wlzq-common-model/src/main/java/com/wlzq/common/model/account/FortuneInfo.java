package com.wlzq.common.model.account;

import java.io.Serializable;

/**
 * 财富账号信息
 * @author Administrator
 *
 */
public class FortuneInfo implements Serializable{
	private static final long serialVersionUID = 343432321L;
	private User user;
	private WCustomer customer;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public WCustomer getCustomer() {
		return customer;
	}
	public void setCustomer(WCustomer customer) {
		this.customer = customer;
	}
}
