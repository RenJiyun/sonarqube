package com.wlzq.common.model.canalnotify;

import java.util.List;

import lombok.Data;

@Data
public class CanalNotifyParams {
	
	private String schemaName;		
	private String tableName;
	private String eventType;		// 目前支持INSERT、UPDATE
	private Integer hasUniqueIndex;		// 是否有唯一索引，1-是，0-否
	private List<SimpleColumn> uniqueIndexColumns;		// 唯一索引列
	private List<SimpleColumn> allColumns;				// 所有列
	private List<SimpleColumn> beforeUpdColumns;		// 仅返回更新前字段
	private List<SimpleColumn> afterUpdColumns;		// 斤返回更新后字段
	
	public static String getUniqueIndexStatment(List<SimpleColumn> columns) {
		StringBuffer uniqueIndexBuffer = new StringBuffer();
		if(columns == null) {
			return "";
		}
		for (SimpleColumn column : columns) {
			uniqueIndexBuffer.append(column.getName()).append(" = ").append(column.getValue()).append(" AND");
		}
		return uniqueIndexBuffer.length() < 4 ? "" : uniqueIndexBuffer.substring(0, uniqueIndexBuffer.length() - 4).toString();
	}
}
