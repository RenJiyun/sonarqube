package com.wlzq.common.model.pay.constants;

/**
 * 支付订单平台
 * @author Administrator
 *
 */
public class PayPlate {
	/** 投顾平台*/
	public final static Integer INVEST_ADVISER = 1;
	
	/**课程**/
	public final static Integer INVEST_COURSE = 2;
	
	/**增值服务**/
	public final static Integer VAS_DECISION = 3;
}
