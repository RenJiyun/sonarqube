/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.base;

import java.util.Date;

import lombok.Data;

/**
 * 优惠券Entity
 * @author louie
 * @version 2018-11-23
 */
@Data
public class CouponInfo  {
	public static final Integer APPLICABLE_PLATE_INVEST = 1; //适用投顾平台
	public static final Integer APPLICABLE_PLATE_FIN_MALL = 2; //适用理财商城
	public static final Integer APPLICABLE_PLATE_RESEARCH = 3; //适用理财商城
	public static final Integer APPLICABLE_PLATE_COURSE = 4;	// 课程
	public static final Integer APPLICABLE_PLATE_VAS = 5;		// 增值服务

	public static final Integer VALIDITY_TYPE_TIME_RANGE = 1;
	public static final Integer VALIDITY_TYPE_DAYS = 2;

	public static final Integer TYPE_DISCOUNT = 1;
	public static final Integer TYPE_FREE = 2;
	public static final Integer TYPE_SATISFY = 3;
	public static final Integer TYPE_QUALIFICTION = 4;
	public static final Integer TYPE_AMOUNT = 5;

	public static final Integer TYPE_DECISIONMALL_DISCOUNT = 13;
	public static final Integer TYPE_DECISIONMALL_FREE = 14;
	public static final Integer TYPE_SATISFY_VAS = 16;	// 代金券（增值服务）

	public static final Integer STATUS_EXPIRED = 4;	// 已过期
	public static final Integer STATUS_USERD = 3;	// 已使用
	public static final Integer STATUS_SENDED = 2;	// 已领取

	private Integer type;		// 类型，1：折扣券，2：免单券，3：满减券，4：权益券
	private String code;		// 编码
	private String name;		// 名称
	private String description;		// 描述
	private Integer validityType;		// 有效期类型，1：日期范围，2：下发起天数
	private Date validityDateFrom;		// 有效期开始时间
	private Date validityDateTo;		// 有效期结束时间
	private Integer applicableType;		// 适用类型，1：通用，2：指定使用
	private Integer amountSatisfy;		// 满减基础金额
	private Integer amountReducation;		// 满减金额
	private Double discount;		// 折扣
	private Double amount;		// 额度，额度券有值
	private Integer validityDays;		// 下发起有效天数
	private String openUrl;		// 打开地址
	private Integer canUse;		// 是否可用，0：否，1：是
	private Integer status;		// 状态，0：已作废，1：未发出，2：已发出，3：已使用
	private Date sendTime;		// 发出时间
	private Date useTime;		// 使用时间
	private String regulation;	// 使用规则
	private String recommendCode;	// 推荐人手机号

	/*原始订单金额*/
	private Integer totalAmount;
	/*使用优惠券后的订单金额*/
	private Integer totalFee;

	private Integer time;//level2 时间
}
