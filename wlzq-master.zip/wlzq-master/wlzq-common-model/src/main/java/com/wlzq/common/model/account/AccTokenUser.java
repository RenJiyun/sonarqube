package com.wlzq.common.model.account;

import java.io.Serializable;
import java.util.Date;

/**
 * token对应Entity
 * @author louie
 * @version 2017-09-15
 */
public class AccTokenUser extends User implements Serializable {
	public static final Integer THIRDTYPE_WECHAT = 1;
	private static final long serialVersionUID = 1212547657L;
	private String thirdUid;		// 第三方uid
	private Integer thirdType;		//第三方类型，1：微信公众号
	private String shareCode;		//分享码
	private String openid;	//微信openid
	private String unionid;	//开放平台unionid
	private Date expireTime;	//过期时间
	private String loginIp;		//登录ip
	private String loginMac;	//登录mac
	private String loginIme;  //登录设备ime
	private String loginImsi; //登录设备ime
	private String loginDeviceType; //登录设备型号

	public String getThirdUid() {
		return thirdUid;
	}

	public void setThirdUid(String thirdUid) {
		this.thirdUid = thirdUid;
	}

	public Integer getThirdType() {
		return thirdType;
	}

	public void setThirdType(Integer thirdType) {
		this.thirdType = thirdType;
	}

	public String getShareCode() {
		return shareCode;
	}

	public void setShareCode(String shareCode) {
		this.shareCode = shareCode;
	}

	public String getUnionid() {
		return unionid;
	}

	public void setUnionid(String unionid) {
		this.unionid = unionid;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public Date getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Date expireTime) {
		this.expireTime = expireTime;
	}

	public String getLoginIp() {
		return loginIp;
	}
	public void setLoginIp(String loginIp) {
		this.loginIp = loginIp;
	}
	public String getLoginMac() {
		return loginMac;
	}
	public void setLoginMac(String loginMac) {
		this.loginMac = loginMac;
	}
	public String getLoginIme() {
		return loginIme;
	}
	public void setLoginIme(String loginIme) {
		this.loginIme = loginIme;
	}
	public String getLoginImsi() {
		return loginImsi;
	}
	public void setLoginImsi(String loginImsi) {
		this.loginImsi = loginImsi;
	}
	public String getLoginDeviceType() {
		return loginDeviceType;
	}
	public void setLoginDeviceType(String loginDeviceType) {
		this.loginDeviceType = loginDeviceType;
	}
	
}