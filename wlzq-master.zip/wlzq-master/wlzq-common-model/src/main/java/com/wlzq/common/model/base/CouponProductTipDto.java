package com.wlzq.common.model.base;

import lombok.Data;

@Data
public class CouponProductTipDto {
	
	private Integer plate;
	private String productCode;
	private Integer priceId;
	private Integer totalAmount;		// 使用优惠券前金额
	private Integer totalFee;			// 使用优惠券后金额
	private Integer time;				// 时间规格
	private Integer timeType;			// 时间类型
	private String specification;		// 时间规格-时间类型
	private String couponTips;			// 优惠券提示：折扣券为xx折， 免单券为免单券，满减券为满减券
	private Integer couponType;			// 优惠券类型
	
	private Double perMonthFee;			// 每月单价
	
}
