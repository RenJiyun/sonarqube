package com.wlzq.common.model.chinaclear;

import lombok.Data;

/**
 * 中登请求字段
 * @author louie
 * @version 2017-10-18
 */
@Data
public class ChinaClearRequestValue {
	private String name ;   //名称
	private Integer lenth ;		// 长度
	private String value ;		// 值
	
	public ChinaClearRequestValue() {
		super();
	}
	
	public ChinaClearRequestValue(String name, Integer lenth, String value) {
		super();
		this.name = name;
		this.lenth = lenth;
		this.value = value;
	}
}