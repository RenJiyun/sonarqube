package com.wlzq.common.model.pay.constants;

/**
 * 支付订单来源
 * @author Administrator
 *
 */
public class PayAgreementSource {
	/** 决策产品订阅 **/
	public final static Integer DECISION_GOODS = 1;
}
