/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 客户信息Entity
 * @author louie
 * @version 2018-07-17
 */
public class WCustomer  implements Serializable {
	public static final Integer ID_KIND_IDENTITYCARD = 0; //身份证
	public static final String NATION_CHINA= "0"; //男性
	public static final Integer GENDER_MAN = 0; //男性
	public static final Integer GENDER_WOMAN = 1; //女性
	public static final Integer SOURCE_THS_APP_SYN = 3; //同花顺app同步
	public static final Integer SOURCE_REGIST = 2; //互联网业务来源(实名)
	public static final Integer SOURCE_SECU_OPEN = 1; //证券开户来源
	public static final Integer REVIEW_STATUS_NOT_REVIEW = 1; //未审核
	public static final Integer REVIEW_STATUS_REVIEW_PASS = 2; //审核通过
	public static final Integer REVIEW_STATUS_REVIEW_NOT_PASS = 3; //审核不通过
	
	public static final String CLIENT_GROUP_SANHU= "0"; //客户类型: 散户
	
	private static final long serialVersionUID = 32154763257L;
	private String fortuneId;		// 业务账户ID
	private String customerId;		// 客户号
	private String userName;		// 姓名
	private String fullName;      //全名
	private String mobile;		// 手机号
	private String clientGroup;		//客户类型，0：散户，（对应柜台字典: 1051）
	private String identityKind;		//证件类型，0：身份证
	private String identityNum;		// 证件号码
	private String identityPhotos;		// 证件照片
	private String professionCode;		// 职业 代码（与柜台一致，字典1047）
	private String controlPerson;  //实际控制人
	private String benefitPerson;		// 实际受益人
	private Integer creditStatus;		// 是否有不良诚信记录，0：否，1：是
	private Date idBeginDate;		// 证件有效开始日期
	private Date idEndDate;		// 证件有效截止日期
	private String instreprName;    //法人代表姓名
	private String instreprIdNo;    //法人证件号码
	private String busLicense;		// 营业执照编号
	private String address;		// 联系地址
	private String idAddress;		// 证件地址
	private String nationality;		// 国籍，0:中国 （与柜台一致，字典1040）
	private Integer gender;		// 性别,0:男，1：女
	private Integer riskLevel;		// 风险等级
	private String riskLevelTxt;		// 风险等级文本
	private Date riskBeginDate;		// 风险测评开始日期
	private Date riskEndDate;		// 风险测评到期日
	private Integer userType;		// 客户类型，0:个人，1：机构，2：自营，3：产品，4：特法户
	private Date openDate;		// 开户日期
	private String branchNo;		// 分支机构
	private String userToken;		// 柜台登录token
	private String sessionNo;		// 会话编号
	private String foreignFlag;		// 境外标志，0：国内客户，1：国外客户，2：港澳台客户，3：在中国永久居留客户
	private String clientRights;		// 客户权限
	private BigDecimal currentBalance; //当前余额
	private BigDecimal enableBalance; //当前余额
	private Integer validFlag;		// 有效标识，0：无效，1：有效
	private Integer source;		// 来源，1：客户号认证,2:开户，3：同花顺app同步
	private Integer reviewStatus;		// 审核状态，1：未审核，2：审核通过，3：审核不通过
	private Integer status;		// 账户状态，1：正常, 2: 注销 ,3:冻结
	private Date createTime;		// 创建时间
	private Date updateTime;		// 更新时间
	private Integer identityStatus;	
	private String channelCode;		// 渠道
	private Integer age;//年龄	
	
	public WCustomer() {
		super();
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	
	public Integer getGender() {
		return gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}
	
	public Integer getRiskLevel() {
		return riskLevel;
	}

	public void setRiskLevel(Integer riskLevel) {
		this.riskLevel = riskLevel;
	}
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public Integer getUserType() {
		return userType;
	}

	public void setUserType(Integer userType) {
		this.userType = userType;
	}

	public String getBranchNo() {
		return branchNo;
	}

	public void setBranchNo(String branchNo) {
		this.branchNo = branchNo;
	}

	public String getIdentityNum() {
		return identityNum;
	}

	public void setIdentityNum(String identityNum) {
		this.identityNum = identityNum;
	}

	public String getInstreprName() {
		return instreprName;
	}

	public void setInstreprName(String instreprName) {
		this.instreprName = instreprName;
	}

	public String getInstreprIdNo() {
		return instreprIdNo;
	}

	public void setInstreprIdNo(String instreprIdNo) {
		this.instreprIdNo = instreprIdNo;
	}

	public String getBusLicense() {
		return busLicense;
	}

	public void setBusLicense(String busLicense) {
		this.busLicense = busLicense;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRiskLevelTxt() {
		return riskLevelTxt;
	}

	public void setRiskLevelTxt(String riskLevelTxt) {
		this.riskLevelTxt = riskLevelTxt;
	}

	public String getUserToken() {
		return userToken;
	}

	public void setUserToken(String userToken) {
		this.userToken = userToken;
	}

	public String getSessionNo() {
		return sessionNo;
	}

	public void setSessionNo(String sessionNo) {
		this.sessionNo = sessionNo;
	}

	public String getClientRights() {
		return clientRights;
	}

	public void setClientRights(String clientRights) {
		this.clientRights = clientRights;
	}

	public BigDecimal getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(BigDecimal currentBalance) {
		this.currentBalance = currentBalance;
	}

	public BigDecimal getEnableBalance() {
		return enableBalance;
	}

	public void setEnableBalance(BigDecimal enableBalance) {
		this.enableBalance = enableBalance;
	}

	public Date getRiskBeginDate() {
		return riskBeginDate;
	}

	public void setRiskBeginDate(Date riskBeginDate) {
		this.riskBeginDate = riskBeginDate;
	}

	public Date getRiskEndDate() {
		return riskEndDate;
	}

	public void setRiskEndDate(Date riskEndDate) {
		this.riskEndDate = riskEndDate;
	}

	public Integer getValidFlag() {
		return validFlag;
	}

	public void setValidFlag(Integer validFlag) {
		this.validFlag = validFlag;
	}

	public String getForeignFlag() {
		return foreignFlag;
	}

	public void setForeignFlag(String foreignFlag) {
		this.foreignFlag = foreignFlag;
	}

	public Date getIdEndDate() {
		return idEndDate;
	}

	public void setIdEndDate(Date idEndDate) {
		this.idEndDate = idEndDate;
	}

	public Integer getSource() {
		return source;
	}

	public void setSource(Integer source) {
		this.source = source;
	}

	public String getFortuneId() {
		return fortuneId;
	}

	public void setFortuneId(String forntuneId) {
		this.fortuneId = forntuneId;
	}

	public String getIdentityKind() {
		return identityKind;
	}

	public void setIdentityKind(String identityKind) {
		this.identityKind = identityKind;
	}

	public String getIdentityPhotos() {
		return identityPhotos;
	}

	public void setIdentityPhotos(String identityPhotos) {
		this.identityPhotos = identityPhotos;
	}

	public String getIdAddress() {
		return idAddress;
	}

	public void setIdAddress(String idAddress) {
		this.idAddress = idAddress;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getProfessionCode() {
		return professionCode;
	}

	public void setProfessionCode(String professionCode) {
		this.professionCode = professionCode;
	}

	public String getControlPerson() {
		return controlPerson;
	}

	public void setControlPerson(String controlPerson) {
		this.controlPerson = controlPerson;
	}

	public String getBenefitPerson() {
		return benefitPerson;
	}

	public void setBenefitPerson(String benefitPerson) {
		this.benefitPerson = benefitPerson;
	}

	public Integer getCreditStatus() {
		return creditStatus;
	}

	public void setCreditStatus(Integer creditStatus) {
		this.creditStatus = creditStatus;
	}

	public Date getIdBeginDate() {
		return idBeginDate;
	}

	public void setIdBeginDate(Date idBeginDate) {
		this.idBeginDate = idBeginDate;
	}

	public Integer getReviewStatus() {
		return reviewStatus;
	}

	public void setReviewStatus(Integer reviewStatus) {
		this.reviewStatus = reviewStatus;
	}
	
	public Integer getIdentityStatus() {
		return identityStatus;
	}
	
	public void setIdentityStatus(Integer identityStatus) {
		this.identityStatus = identityStatus;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getClientGroup() {
		return clientGroup;
	}

	public void setClientGroup(String clientGroup) {
		this.clientGroup = clientGroup;
	}

}