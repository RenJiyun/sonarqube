package com.wlzq.common.model.pay;

/**
 * 支付签约通知dto
 * @author 赵泽鑫
 * @version 2017-12-18
 */
public class PayAgreementNotify {
	
	public static final String NOTIFY_TYPE_SIGN = "dut_user_sign";
	public static final String NOTIFY_TYPE_UNSIGN = "dut_user_unsign";
	
	private String charset;
	private String notifyTime;	// yyyy-MM-dd HH:mm:ss 通知时间
	private String alipayUserId;	// 支付宝用户id
	private String sign;			// 签名
	private String nonceStr;    //随机串
	private String externalAgreementNo;		// 商户方订单号
	private String version;			// 版本
	private String signTime;		// 签约时间
	private String notifyId;
	private String notifyType;		// 通知类型 dut_user_sign,dut_user_unsign
	private String agreementNo;		// 签约协议
	private String invalidTime;		// yyyy-MM-dd HH:mm:ss  失效时间
	private String authAppId;
	private String personalProductCode;		// CYCLE_PAY_AUTH_P
	private String validTime;		// yyyy-MM-dd HH:mm:ss  生效时间
	private String loginToken;		// 
	private String appId;
	private String signType;
	private String signScene;
	private String status;			// NORMAL-签约，UNSIGN-解约
	private String alipayLogonId;	// 支付宝账号
	private String busiNotifyUrl;	// 业务平台通知url
	private String unsignTime;		// 解约时间
	
	public PayAgreementNotify() {
		super();
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getNotifyTime() {
		return notifyTime;
	}

	public void setNotifyTime(String notifyTime) {
		this.notifyTime = notifyTime;
	}

	public String getAlipayUserId() {
		return alipayUserId;
	}

	public void setAlipayUserId(String alipayUserId) {
		this.alipayUserId = alipayUserId;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getExternalAgreementNo() {
		return externalAgreementNo;
	}

	public void setExternalAgreementNo(String externalAgreementNo) {
		this.externalAgreementNo = externalAgreementNo;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getSignTime() {
		return signTime;
	}

	public void setSignTime(String signTime) {
		this.signTime = signTime;
	}

	public String getNotifyId() {
		return notifyId;
	}

	public void setNotifyId(String notifyId) {
		this.notifyId = notifyId;
	}

	public String getNotifyType() {
		return notifyType;
	}

	public void setNotifyType(String notifyType) {
		this.notifyType = notifyType;
	}

	public String getAgreementNo() {
		return agreementNo;
	}

	public void setAgreementNo(String agreementNo) {
		this.agreementNo = agreementNo;
	}

	public String getInvalidTime() {
		return invalidTime;
	}

	public void setInvalidTime(String invalidTime) {
		this.invalidTime = invalidTime;
	}

	public String getAuthAppId() {
		return authAppId;
	}

	public void setAuthAppId(String authAppId) {
		this.authAppId = authAppId;
	}

	public String getPersonalProductCode() {
		return personalProductCode;
	}

	public void setPersonalProductCode(String personalProductCode) {
		this.personalProductCode = personalProductCode;
	}

	public String getValidTime() {
		return validTime;
	}

	public void setValidTime(String validTime) {
		this.validTime = validTime;
	}

	public String getLoginToken() {
		return loginToken;
	}

	public void setLoginToken(String loginToken) {
		this.loginToken = loginToken;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getSignType() {
		return signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getSignScene() {
		return signScene;
	}

	public void setSignScene(String signScene) {
		this.signScene = signScene;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAlipayLogonId() {
		return alipayLogonId;
	}

	public void setAlipayLogonId(String alipayLogonId) {
		this.alipayLogonId = alipayLogonId;
	}

	public String getBusiNotifyUrl() {
		return busiNotifyUrl;
	}

	public void setBusiNotifyUrl(String busiNotifyUrl) {
		this.busiNotifyUrl = busiNotifyUrl;
	}

	public String getUnsignTime() {
		return unsignTime;
	}

	public void setUnsignTime(String unsignTime) {
		this.unsignTime = unsignTime;
	}
	
	public String getNonceStr() {
		return nonceStr;
	}
	
	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}
}