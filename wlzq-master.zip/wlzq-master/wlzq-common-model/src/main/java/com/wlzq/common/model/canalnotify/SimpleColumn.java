package com.wlzq.common.model.canalnotify;

import lombok.Data;

@Data
public class SimpleColumn {

	private String name;		// 列名
	private String value;		// 值
}
