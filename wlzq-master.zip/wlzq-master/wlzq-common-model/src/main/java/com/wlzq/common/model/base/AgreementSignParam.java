/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.base;

import java.util.List;

import lombok.Data;

/**
 * 协议签约参数
 * @author louie
 * @version 2018-09-05
 */
@Data
public class AgreementSignParam {
	public static final Integer INVEST_ADVISER = 1;
	public static final Integer INVEST_RESEARCH = 3;
	public static final Integer ACCOUNT = 4;
	public static final Integer INVEST_COURSE = 5;
	
	private Integer type;		// 类型，1：投顾平台
	private Integer userType;		// 客户类型
	private String customerId;		// 客户号
	private String fundAccount;		// 资金账号
	private String customerName;		// 客户姓名
	private String enMaxdeficitRate;		// 能承受的最大损失
	private String enMaxdeficitRateTxt;		// 能承受的最大损失文本
	private String enInvestTerm;		// 客户投资期限
	private String enInvestTermTxt;		// 客户投资期限字符串
	private String enInvestKind;		// 客户投资品种
	private String enInvestKindTxt;		// 客户投资品种字符串
	private String mobile;		// 手机号
	private String identityNum;		// 身份证号
	private String instreprName;    //法人代表姓名
	private String instreprIdNo;    //法人证件号码
	private String busLicense;		// 营业执照编号
	private String address;		// 地址
	private String productCode;		// 产品代码
	private String productName;		// 产品名称
	private String productPeroid;		// 产品期限
	private String productTypeStr;		// 投资类别
	private String version;		// 版本
	private Integer userRiskLevel;		// 客户风险等级
	private String userRiskLevelTxt;		// 客户风险等级描述
	private Integer productRiskLevel;		// 产品风险等级
	private String productRiskLevelTxt;		// 产品风险等级描述
	
	private String remark;		// 备注
	private String date;		// 日期
	private List<String> agreenmentNos;		// 协议编号
	private String agreementSerialNo;		// 签署协议流水号
	
	private String branchName;		// 营业部全称
	private String userRiskLevelCheckTxt;		// 勾选用户风险
	private String productRiskLevelCheckTxt;	// 勾选产品风险
	private String idNumber;       //实名签约
	private String idenSerialNo;   //实名信息流水号
}