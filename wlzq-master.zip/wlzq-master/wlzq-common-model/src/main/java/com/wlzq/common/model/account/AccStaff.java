/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 员工Entity
 * @author louie
 * @version 2018-12-17
 */
@Data
public class AccStaff {
	public final static Integer TYPE_SALE = new Integer(1);
	public final static Integer STATUS_YES = new Integer(1);
	public final static Integer STATUS_NO = new Integer(0);
	
	private Integer id;
	private String no;		// 人员编号
	private String nickName;   //营业部名称
	private String userName;   //营业部名称
	private String mobile;		// 手机号
	private Integer position;	//职位
	private String portrait;		// 手机号
	private String wechatQrcode;		//微信二维码
	private String wechat;		// 微信号
	private String officePhone;		// 工作座机
	private Integer status;		// 离职在职状态
	private Integer isDeleted;		// 是否删除
	private String branchno;   //营业部编号
	private String wechatStoreQrcode;		// 微店二维码
	private String wechatStoreUrl;		// 微店url
	private Date createTime;		// 手机号
	private Date updateTime;		//更新时间
	private String branchShortname;		// 营业部简称
	
	private List<String> branchnoList;	//营业部列表
}