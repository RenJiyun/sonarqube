package com.wlzq.common.model.account;

import java.util.Date;

/**
 * 账户管理Entity
 * @author louie
 * @version 2017-09-15
 */
public class AccUser extends User {
	public static final String TABLE_NAME = "acc_user";
	private static final long serialVersionUID = 1547657L;
	private String deviceId;
	private Integer id;
	private String email;		// 密码
	private String password;		// 密码
	private String shareCode;		// 分享码
	private Date lastLoginTime;		// 上次登录时间
	private String lastLoginIp;		// 上次登录IP
	private Integer errorCount;		// 登录错误次数
	private Integer loginCount;		// 登录次数
	private Integer isLocked;		// 是否锁住，0：否，1：是
	private Integer regType;		// 注册类型，1：验证码注册
	private Integer regSource;		// 注册来源， WECHAT (1),APP(2),H5(3)，灯塔(4);
	private Date createTime;		// 创建时间
	private Date updateTime;		// 更新时间
	private String remark;		// 备注
	private Integer isDeleted;  //是否删除，0：否，1：是
	private String agreementSerialNo; //协议流水
	private String channelCode; //渠道
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
	
	public String getLastLoginIp() {
		return lastLoginIp;
	}

	public void setLastLoginIp(String lastLoginIp) {
		this.lastLoginIp = lastLoginIp;
	}
	
	public Integer getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(Integer errorCount) {
		this.errorCount = errorCount;
	}
	
	public Integer getLoginCount() {
		return loginCount;
	}

	public void setLoginCount(Integer loginCount) {
		this.loginCount = loginCount;
	}
	
	public Integer getIsLocked() {
		return isLocked;
	}

	public void setIsLocked(Integer isLocked) {
		this.isLocked = isLocked;
	}
	
	public Integer getRegType() {
		return regType;
	}

	public void setRegType(Integer regType) {
		this.regType = regType;
	}
	
	public Integer getRegSource() {
		return regSource;
	}

	public void setRegSource(Integer regSource) {
		this.regSource = regSource;
	}
	
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getShareCode() {
		return shareCode;
	}

	public void setShareCode(String shareCode) {
		this.shareCode = shareCode;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getAgreementSerialNo() {
		return agreementSerialNo;
	}

	public void setAgreementSerialNo(String agreementSerialNo) {
		this.agreementSerialNo = agreementSerialNo;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}
	
}