/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.util.Map;

import lombok.Data;

/**
 * 员工职业编号Entity
 * @author zhaozx
 * @version 2019-09-27
 */
@Data
public class AccAccountOpeninfo {
	
	public final static Integer ACCOUNT_TYPE_COMMON = 1;
	public final static Integer ACCOUNT_TYPE_OPTION = 2;
	public final static Integer ACCOUNT_TYPE_CREDIT = 3;
	private String id;
	private String customerId;
	private String customerName;
	private Integer accountType;		// 1-普通，2-期权，3-两融
	private String openDate;
	
	public static AccAccountOpeninfo parseFromFsdpMap(Map<String, Object> map) {
		if (map == null || map.isEmpty()) {
			return null;
		}
		String customerId = String.valueOf(map.get("KHH"));
		String customerName = String.valueOf(map.get("KHXM"));
		String openDate = String.valueOf(map.get("KHRQ"));
		String typeStr = String.valueOf(map.get("ZHLX"));
		Integer accountType = null;
		if ("普通账号".equals(typeStr)) {
			accountType = ACCOUNT_TYPE_COMMON;
		}
		if ("期权账户".equals(typeStr)) {
			accountType = ACCOUNT_TYPE_OPTION;
		}
		if ("两融账户".equals(typeStr)) {
			accountType = ACCOUNT_TYPE_CREDIT;
		}
		AccAccountOpeninfo info = new AccAccountOpeninfo();
		info.setAccountType(accountType);
		info.setCustomerId(customerId);
		info.setCustomerName(customerName);
		info.setOpenDate(openDate);
		return info;
	}
}