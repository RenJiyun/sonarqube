package com.wlzq.common.model.base;

import lombok.Data;

@Data
public class AgreementBrief {
	public static final Integer TYPE_CONTRACT = 2; //合同
	public static final Integer TYPE_APPROPRIATE = 4; //适当性评估确认书
	public static final Integer TYPE_PAUSE_READ = 6; //书面阅读（需停留阅读）
	public static final Integer TYPE_SERVICE_AGREEMENT = 13; //产品服务协议书
	public static final Integer TYPE_RISK_ANNOUNCEMENT = 14; //风险揭示书
	public static final Integer TYPE_AUTO_PAY = 15; // 自动续费
	private Integer type;
	private Integer contentType;
	private String no;
	private String title;
	private String address;
}
