package com.wlzq.common.model.account;

import java.io.Serializable;

import lombok.Data;

@Data
public class Staff  implements Serializable{

	private static final long serialVersionUID = 121543476457L;
	/**
	 * userid
	 */
	private String userId;
	/**
	 * 手机
	 */
	private String mobile;
	/**
	 * 姓名
	 */
	private String name;
	/**
	 * 营业部id
	 */
	private Integer officeId;
	/**
	 * 营业部名称
	 */
	private String officeName;
	
}

