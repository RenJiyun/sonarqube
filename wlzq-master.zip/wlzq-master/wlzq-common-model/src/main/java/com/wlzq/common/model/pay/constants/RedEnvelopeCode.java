package com.wlzq.common.model.pay.constants;

/**
 * 红包业务编号
 * @author Administrator
 *
 */
public class RedEnvelopeCode {
	/** 答题有奖活动 */
	public final static String ACTIVITY_ANSWER = "ACTIVITY.ANSWER";
}
