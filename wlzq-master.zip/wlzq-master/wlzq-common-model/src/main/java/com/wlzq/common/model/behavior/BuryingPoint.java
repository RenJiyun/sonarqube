package com.wlzq.common.model.behavior;

import java.util.Date;

public class BuryingPoint {

	private String action; // 事件
	private Date clientStartTime; // 客户端开始时间
	private Date serverTime; // 服务端时间
	private String mobile;   //用户手机号
	private String userId; // 用户id
	private String lastUrl; // 上一跳url
	private String currentUrl; // 当前url
	private String customerId; // 客户号

	private String wlzqstatId; // wl统计id
	private Integer platformId; // 平台
	private String language; // 语言
	private String resolution; // 分辨率
	private String clientIp; // ip
	private String useragent; // userAgent
	
	public static final Integer PLATFORM_OTHER = 0;
	public static final Integer PLATFORM_WECHAT = 1;
	public static final Integer PLATFORM_APP = 2;

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Date getClientStartTime() {
		return clientStartTime;
	}

	public void setClientStartTime(Date clientStartTime) {
		this.clientStartTime = clientStartTime;
	}

	public Date getServerTime() {
		return serverTime;
	}

	public void setServerTime(Date serverTime) {
		this.serverTime = serverTime;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getLastUrl() {
		return lastUrl;
	}

	public void setLastUrl(String lastUrl) {
		this.lastUrl = lastUrl;
	}

	public String getCurrentUrl() {
		return currentUrl;
	}

	public void setCurrentUrl(String currentUrl) {
		this.currentUrl = currentUrl;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getWlzqstatId() {
		return wlzqstatId;
	}

	public void setWlzqstatId(String wlzqstatId) {
		this.wlzqstatId = wlzqstatId;
	}

	public Integer getPlatformId() {
		return platformId;
	}

	public void setPlatformId(Integer platformId) {
		this.platformId = platformId;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getResolution() {
		return resolution;
	}

	public void setResolution(String resolution) {
		this.resolution = resolution;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clienIp) {
		this.clientIp = clienIp;
	}

	public String getUseragent() {
		return useragent;
	}

	public void setUseragent(String useragent) {
		this.useragent = useragent;
	}

}
