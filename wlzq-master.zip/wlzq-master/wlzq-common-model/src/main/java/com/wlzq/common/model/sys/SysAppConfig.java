/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.sys;

import lombok.Data;

/**
 * 配置管理2Entity
 * @author zhaozx
 * @version 2019-06-25
 */
@Data
public class SysAppConfig {
	
	private String name;		// 名称
	private String platform;		// 平台
	private String key;		// 配置key
	private String value;		// 配置value
	private String description;		// 描述
	
	
}