package com.wlzq.common.model.sys;

import java.io.Serializable;

public class LoginTerminalInfo implements Serializable{
	public static final Integer TYPE_IOS = 1;//"MI";
	public static final Integer TYPE_ANDRIOD = 2;//"MA";
	public static final Integer TYPE_OTHER = 3;//"other";
	public static final Integer TYPE_PC = 4;//"other";
	/**
	 * 
	 */
	private static final long serialVersionUID = 123212232L;
	/**
	 * 终端类型,1:ios,2:andriod,3:h5
	 */
	private Integer type;
	/**
	 * 登录手机(注册手机)
	 */
	private String mobile;
	/**
	 * 实际使用的手机
	 */
	private String actMobile;
	
	/**
	 * 登录客户号
	 */
	private String customerId;
	
	private String loginMac;	//登录mac
	
	private String lip;	//内网IP
	
	private String idfv;	//IOS用户标识

	private String iccid;	//ios
	
	private String guid;	//and

	private String uuid;	//ios
	
	private String loginImei;  //登录设备imei
	
	private String loginImsi; //登录设备imsi
	
	private String loginDeviceType; //登录设备型号
	
	private String osv; //操作系统
	
	private String ver; //版本

	/**
	 * 客户端IP
	 */
	private String clientIp;
	/**
	 * 客户端端口
	 */
	private Integer clientPort;

	private String hd; //硬盘序列号
	private String pcn; //PC终端设备名
	private String cpu; //CPU序列号
	private String pi; //硬盘分区信息
	private String vol; //系统盘卷标号
	
	public String toOpstation() {
		String opstation = "";
		if(TYPE_IOS.equals(this.type)) {
			opstation = getIosOpstation();
		}else if(TYPE_ANDRIOD.equals(this.type)) {
			opstation = getAndriodOpstation();
		}else if(TYPE_OTHER.equals(this.type)) {
			opstation = getOtherOpstation();
		}else if(TYPE_PC.equals(this.type)) {
			opstation = getPcOpstation();
		}
		return opstation;
	}
	
	private String getIosOpstation() {
		String opstation = "MI;" + "IIP=" + this.getClientIp() + ";" +
				"IPORT=" + this.clientPort + ";" +
				"LIP=" + this.getLip() + ";" +
				"MAC=" + this.getLoginMac() + ";" +
				"IDFV=" + this.getIdfv() + ";" +
				"RMPN=" + this.getMobile() + ";" +
				"UMPN=NA;" +
				"ICCID=NA;"  + this.getIccid() + ";" +
				"OSV=IOS" + this.getOsv() + ";" +
				"IMSI=NA";
		String device = this.getLoginDeviceType();
		if(!device.equals("NA")) {
			opstation += "@"+device;
		}
		return opstation;
	}
	
	private String getAndriodOpstation() {
		String opstation = "MA;" + "IIP=" + this.getClientIp() + ";" +
				"IPORT=" + this.clientPort + ";" +
				"LIP=" + this.getLip() + ";" +
				"MAC=" + this.getLoginMac() + ";" +
				"IMEI=" + this.getLoginImei() + ";" +
				"RMPN=" + this.getMobile() + ";" +
				"UMPN=NA;" +
				"ICCID=" + this.getIccid() + ";" +
				"OSV=Android" + this.getOsv() + ";" +
				"IMSI=" + this.getLoginImsi() ;
		String device = this.getLoginDeviceType();
		if(!device.equals("NA")) {
			opstation += "@"+device;
		}
		return opstation;
	}
	
	private String getOtherOpstation() {
		String opstation = "OH;" + "IIP=" + this.getClientIp() + ";" +
				"IPORT=" + this.clientPort + ";" +
				"LIP=" + this.getLip() + ";" +
				"MAC=" + this.getLoginMac() + ";" +
				"GUID=" + this.getGuid() + ";" +
				"RMPN=" + this.getMobile()+ ";" +
				"UMPN=NA;" +
				"@H5";
		return opstation;
	}

	private String getPcOpstation() {
		String opstation = "PC;" + "IIP=" + this.getClientIp() + ";" +
				"IPORT=" + this.clientPort + ";" +
				"LIP=" + this.getLip() + ";" +
				"MAC=" + this.getLoginMac() + ";" +
				"HD=" + this.getHd() + ";" +
				"PCN=" + this.getPcn() + ";" +
				"CPU=" + this.getCpu() + ";" +
				"PI=" + this.getPi()+ ";" +
				"VOL=" + this.getVol();
		return opstation;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	
	public String getTypeStr() {
		return type == null?"ds-":type.equals(TYPE_IOS)?"MI":
				type.equals(TYPE_ANDRIOD)?"MA":"OH";
	}
	
	public String getMobile() {
		return this.mobile == null || this.mobile.trim().equals("")?"NA":this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getActMobile() {
		return this.actMobile == null || this.actMobile.trim().equals("")?"NA":this.actMobile;
	}

	public void setActMobile(String actMobile) {
		this.actMobile = actMobile;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getLoginMac() {
		return this.loginMac == null || this.loginMac.trim().equals("")?"NA":this.loginMac.replaceAll("-", "");
	}

	public void setLoginMac(String loginMac) {
		this.loginMac = loginMac;
	}

	public String getLip() {
		return this.lip == null || this.lip.trim().equals("")?"NA":this.lip;
	}

	public void setLip(String lip) {
		this.lip = lip;
	}

	public String getIdfv() {
		return this.idfv == null || this.idfv.trim().equals("")?"NA":this.idfv;
	}

	public void setIdfv(String idfv) {
		this.idfv = idfv;
	}

	public String getIccid() {
		return this.iccid == null || this.iccid.trim().equals("")?"NA":this.iccid;
	}

	public void setIccid(String iccid) {
		this.iccid = iccid;
	}

	public String getLoginImei() {
		return this.loginImei == null || this.loginImei.trim().equals("")?"NA":this.loginImei;
	}

	public void setLoginImei(String loginImei) {
		this.loginImei = loginImei;
	}

	public String getLoginImsi() {
		return this.loginImsi == null || this.loginImsi.trim().equals("")?"NA":this.loginImsi;
	}

	public void setLoginImsi(String loginImsi) {
		this.loginImsi = loginImsi;
	}

	public String getLoginDeviceType() {
		return this.loginDeviceType == null || this.loginDeviceType.trim().equals("")?"NA":this.loginDeviceType;
	}

	public void setLoginDeviceType(String loginDeviceType) {
		this.loginDeviceType = loginDeviceType;
	}

	public String getOsv() {
		return this.osv == null || this.osv.trim().equals("")?"NA":this.osv.replace("\r\n", "");
	}

	public void setOsv(String osv) {
		this.osv = osv;
	}

	public String getVer() {
		return this.ver == null || this.ver.trim().equals("")?"NA":this.ver;
	}

	public void setVer(String ver) {
		this.ver = ver;
	}

	public String getClientIp() {
		return this.clientIp == null || this.clientIp.trim().equals("")?"NA":this.clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public Integer getClientPort() {
		return clientPort;
	}

	public void setClientPort(Integer clientPort) {
		this.clientPort = clientPort;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getGuid() {
		return this.guid == null || this.guid.trim().equals("")?"NA":this.guid;
	}

	public void setGuid(String guid) {
		this.guid = guid;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getHd() {
		return this.hd == null || this.hd.trim().equals("")?"NA":this.hd;
	}

	public void setHd(String hd) {
		this.hd = hd;
	}

	public String getPcn() {
		return this.pcn == null || this.pcn.trim().equals("")?"NA":this.pcn;
	}

	public void setPcn(String pcn) {
		this.pcn = pcn;
	}

	public String getCpu() {
		return this.cpu == null || this.cpu.trim().equals("")?"NA":this.cpu;
	}

	public void setCpu(String cpu) {
		this.cpu = cpu;
	}

	public String getPi() {
		return this.pi == null || this.pi.trim().equals("")?"NA":this.pi;
	}

	public void setPi(String pi) {
		this.pi = pi;
	}

	public String getVol() {
		return this.vol == null || this.vol.trim().equals("")?"NA":this.vol;
	}

	public void setVol(String vol) {
		this.vol = vol;
	}

	public static LoginTerminalInfo fromLighthouse(String deviceInfo) {
		if(deviceInfo == null || deviceInfo.trim().equals("")) {
			return new LoginTerminalInfo();
		}
		String[] infos = deviceInfo.split(",");
		if(infos.length != 3) {
			return  new LoginTerminalInfo();
		}
		LoginTerminalInfo tInfo = new LoginTerminalInfo();
		Integer type = deviceInfo.toLowerCase().contains("iphone")?LoginTerminalInfo.TYPE_IOS:LoginTerminalInfo.TYPE_ANDRIOD;
		tInfo.setType(type);
		if(type.equals(LoginTerminalInfo.TYPE_IOS)) {
			tInfo.setUuid(infos[0]);
		}else if(type.equals(LoginTerminalInfo.TYPE_ANDRIOD)) {
			tInfo.setLoginImei(infos[0]);
		}
		tInfo.setVer(infos[2]);
		tInfo.setLoginDeviceType(infos[2]);
		return tInfo;
	}

	public static LoginTerminalInfo fromThsApp(String deviceInfo) {
		if(deviceInfo == null || deviceInfo.trim().equals("")) return new LoginTerminalInfo();
		LoginTerminalInfo tInfo = new LoginTerminalInfo();
		String[] hInfos = deviceInfo.split(",");
		for(String infoStr:hInfos) {
			String[] info = infoStr.split(":");
			if(info.length == 2) {
				String infoKey = info[0];
				if(infoKey.toUpperCase().equals("MAC")) {
					tInfo.setLoginMac(info[1]);
				}
				if(infoKey.toUpperCase().equals("IMEI")) {
					tInfo.setLoginImei(info[1]);
					tInfo.setType(LoginTerminalInfo.TYPE_ANDRIOD);
				}
				if(infoKey.toUpperCase().equals("IMSI")) {
					tInfo.setLoginImsi(info[1]);
				}
				if(infoKey.toUpperCase().equals("TYPE")) {
					tInfo.setLoginDeviceType(info[1]);
				}
				if(infoKey.toUpperCase().equals("LIP")) {
					tInfo.setLip(info[1]);
				}
				if(infoKey.toUpperCase().equals("IDFV")) {
					tInfo.setIdfv(info[1]);
					tInfo.setType(LoginTerminalInfo.TYPE_IOS);
				}
				if(infoKey.toUpperCase().equals("OSV")) {
					tInfo.setOsv(info[1]);
				}
				if(infoKey.toUpperCase().equals("ICCID")) {
					tInfo.setIccid(info[1]);
				}
			}
		}
		
		return tInfo;
	}
}
