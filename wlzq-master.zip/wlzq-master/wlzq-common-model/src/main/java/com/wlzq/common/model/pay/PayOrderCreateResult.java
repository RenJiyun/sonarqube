/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.pay;

import lombok.Data;

/**
 * 订单创建结果
 * @author louie
 * @version 2018-04-17
 */
@Data
public class PayOrderCreateResult {
	private String orderNo;		// 订单号
}