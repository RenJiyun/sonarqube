package com.wlzq.common.model.base;

import java.util.Date;

import lombok.Data;

@Data
public class MediaLibrary {
	
	public static final Integer TYPE_FILE = 1;
	public static final Integer TYPE_MP3 = 2;
	public static final Integer TYPE_VIDEO = 3;
	
	private String id;
	private Integer type;		// 素材类型，1-文件，2-音频，3-视频
	private String name;		// 文件名称
	private String icon;		// 图标
	private String aliyunUrl;	// 阿里云链接
	private String localUrl;	// 本地服务器链接
	private Date createTime;	// 创建时间
	private Integer isDeleted;	
}
