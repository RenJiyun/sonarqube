/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.pay;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 代扣协议管理Entity
 * @author zhaozx
 * @version 2022-01-05
 */
public class PayAgreement {
	
	private String id;
	private Integer plate;		// 平台， 1-投顾社区，2-投顾课程，3-决策商城
	private String body;		// 商品描述
	private String outTradeNo;		// 业务订单号
	private String notifyUrl;		// 回调链接
	private String payNotifyUrl;		// 回调链接
	private Integer source;		// 来源，0-决策商城
	private String userId;		// 用户号
	private String openId;		// openid
	private String customerId;		// 客户号
	private Integer deviceType;		// 设备类型，1：ios，2：安卓，3：wx,4:pc,5:其它
	private String thirdPartyType;		// 签约第三方主体类型，1. PARTNER（平台商户） 2. MERCHANT（集团商户）
	private String signValidityPeriod;		// 协议有效周期，1. d：天，2. m：月
	private String signScene;		// 协议签约场景
	private String agreementNo;		// 签约编号
	private String zmOpenId;		// 芝麻信用openId
	private String validTime;		// 用户代扣协议的实际生效时间，格式为yyyy-MM-dd HH:mm:ss
	private String invalidTime;		// 用户代扣协议的失效时间，格式为yyyy-MM-dd HH:mm:ss
	private String signTime;		// 支付宝代扣协议的实际签约时间，格式为yyyy-MM-dd HH:mm:ss
	private String status;		// 协议的当前状态。1. TEMP：暂存，协议未生效过；2. NORMAL：正常；3. STOP：暂停。
	private String alipayLogonId;		// 返回脱敏的支付宝账号
	private String periodType;		// 枚举值为DAY和MONTH
	private Long period;		// 周期数
	private String singleAmount;		// 单次扣款最大金额
	private String totalAmount;		// 总金额限制，单位为元
	private Integer totalPayments;		// 总扣款次数
	private Date createTime;		// 创建时间
	private Date updateTime;		// 更新时间
	private Integer isDeleted;		// is_deleted
	
	private String productCode;		// 产品代码
	private String productName;		// 产品名称
	
	private String externalAgreementNo;
	private String executeTime;		// 首次执行时间，精确到日，格式为yyyy-MM-dd
	
	private String signParams;		// 签约参数json
	private String notifyInfo;		// 通知信息json
	private String payOutTradeNo;	// 先支付后签约关联业务订单
	private String payOrderNo;		// 先支付后签约关联支付订单
	private String unsignTime;		// 解约时间
	
	private String sign;
	private String nonceStr;		// 随机串
	private String appKey;
	private String failReason;		// 失败原因
	
	private String lastDeductTime;		// 上次扣款成功时间, yyyy-MM-dd
	private String nextDeductTime;		// 预计下次扣款时间, yyyy-MM-dd
	
	public PayAgreement() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getPlate() {
		return plate;
	}

	public void setPlate(Integer plate) {
		this.plate = plate;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public Integer getSource() {
		return source;
	}

	public void setSource(Integer source) {
		this.source = source;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public String getThirdPartyType() {
		return thirdPartyType;
	}

	public void setThirdPartyType(String thirdPartyType) {
		this.thirdPartyType = thirdPartyType;
	}

	public String getSignValidityPeriod() {
		return signValidityPeriod;
	}

	public void setSignValidityPeriod(String signValidityPeriod) {
		this.signValidityPeriod = signValidityPeriod;
	}

	public String getSignScene() {
		return signScene;
	}

	public void setSignScene(String signScene) {
		this.signScene = signScene;
	}

	public String getAgreementNo() {
		return agreementNo;
	}

	public void setAgreementNo(String agreementNo) {
		this.agreementNo = agreementNo;
	}

	public String getZmOpenId() {
		return zmOpenId;
	}

	public void setZmOpenId(String zmOpenId) {
		this.zmOpenId = zmOpenId;
	}

	public String getValidTime() {
		return validTime;
	}

	public void setValidTime(String validTime) {
		this.validTime = validTime;
	}

	public String getInvalidTime() {
		return invalidTime;
	}

	public void setInvalidTime(String invalidTime) {
		this.invalidTime = invalidTime;
	}

	public String getSignTime() {
		return signTime;
	}

	public void setSignTime(String signTime) {
		this.signTime = signTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAlipayLogonId() {
		return alipayLogonId;
	}

	public void setAlipayLogonId(String alipayLogonId) {
		this.alipayLogonId = alipayLogonId;
	}

	public String getPeriodType() {
		return periodType;
	}

	public void setPeriodType(String periodType) {
		this.periodType = periodType;
	}

	public Long getPeriod() {
		return period;
	}

	public void setPeriod(Long period) {
		this.period = period;
	}

	public String getSingleAmount() {
		return singleAmount;
	}

	public void setSingleAmount(String singleAmount) {
		this.singleAmount = singleAmount;
	}

	public String getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(String totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getTotalPayments() {
		return totalPayments;
	}

	public void setTotalPayments(Integer totalPayments) {
		this.totalPayments = totalPayments;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public String getExternalAgreementNo() {
		return externalAgreementNo;
	}
	
	public void setExternalAgreementNo(String externalAgreementNo) {
		this.externalAgreementNo = externalAgreementNo;
	}
	
	public String getExecuteTime() {
		return executeTime;
	}
	
	public void setExecuteTime(String executeTime) {
		this.executeTime = executeTime;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSignParams() {
		return signParams;
	}

	public void setSignParams(String signParams) {
		this.signParams = signParams;
	}

	public String getNotifyInfo() {
		return notifyInfo;
	}

	public void setNotifyInfo(String notifyInfo) {
		this.notifyInfo = notifyInfo;
	}
	
	public String getPayOutTradeNo() {
		return payOutTradeNo;
	}
	
	public void setPayOutTradeNo(String payOutTradeNo) {
		this.payOutTradeNo = payOutTradeNo;
	}
	
	public String getPayOrderNo() {
		return payOrderNo;
	}
	
	public void setPayOrderNo(String payOrderNo) {
		this.payOrderNo = payOrderNo;
	}
	
	public String getUnsignTime() {
		return unsignTime;
	}
	
	public void setUnsignTime(String unsignTime) {
		this.unsignTime = unsignTime;
	}
	
	public String getPayNotifyUrl() {
		return payNotifyUrl;
	}
	
	public void setPayNotifyUrl(String payNotifyUrl) {
		this.payNotifyUrl = payNotifyUrl;
	}
	
	public String getAppKey() {
		return appKey;
	}
	
	public void setAppKey(String appKey) {
		this.appKey = appKey;
	}
	
	/**
	 * 计算下一个比当前日期大的执行日，包括当日
	 * @param periodType
	 * @param period
	 * @param executeTime
	 * @return
	 */
	public static Date caculateNextExecuteDate(String periodType, Long period, String executeTime) {
		if (executeTime == null) {
			return null;
		}
		if (!"DAY".equals(periodType) && !"MONTH".equals(periodType)) {
			return null;
		}
		if (period == null) {
			return null;
		}

		Date now = new Date();
		Date nextExecuteDateEnd = null;
		Date nextExecuteDateStart = null;
		String nowStr = null;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			nextExecuteDateEnd = sdf.parse(executeTime + " 23:59:59");
			nextExecuteDateStart = sdf.parse(executeTime + " 00:00:00");
		} catch (Exception e) { 
			return null;
		}

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			nowStr = sdf.format(now);
		} catch (Exception e) {
			return null;
		}

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(nextExecuteDateEnd);
		/**
		 * 计算下一个比当前日期大的执行日
		 */
		boolean flag = executeTime.equals(nowStr);
		while (flag || nextExecuteDateEnd.before(now)) {
			if ("MONTH".equals(periodType)) {
				calendar.add(Calendar.MONTH, period.intValue());
			}
			if ("DAY".equals(periodType)) {
				calendar.add(Calendar.DATE, period.intValue());
			}
			nextExecuteDateEnd = calendar.getTime();
			flag = false;
		}
		return calendar.getTime();
	}
	
	/**
	 * 
	 * @param periodType
	 * @param period
	 * @param executeTime
	 * @return
	 */
	public static String caculateNextExecuteDateStr(String periodType, Long period, String executeTime) {
		executeTime = convertTo28th(executeTime);
		Date nextExecuteDate = caculateNextExecuteDate(periodType, period, executeTime);
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String sd = sdf.format(nextExecuteDate);
		return sd;
	}
	
	public static String getPeriodStr(String periodType, Long period) {
		String periodStr = "";
		if ("MONTH".equals(periodType) && period != null) {
			if (period.longValue() == 1) {
				periodStr = "连续包月";
			}
			if (period.longValue() == 3) {
				periodStr = "连续包季";
			}
			if (period.longValue() == 6) {
				periodStr = "连续包半年";
			}
			if (period.longValue() == 12) {
				periodStr = "连续包年";
			}
		}
		return periodStr;
	}
	
	public static String getExecutePeriodStr(String periodType, Long period, String executeTime) {
		executeTime = convertTo28th(executeTime);
		String executePeriodStr = "";
		if ("MONTH".equals(periodType) && period != null && period.longValue() == 1 && executeTime != null) {
			String date = executeTime.split("-").length != 3 ? "" : executeTime.split("-")[2];
			executePeriodStr = "每月" + date + "日";
		}
		return executePeriodStr;
	}

	/**
	 * 替换超过28日的日期为28日
	 * @param dateString
	 * @return
	 */
	public static String convertTo28th(String dateString) {
		// 截取日部分字符串
		String dayOfMonthString = dateString.substring(8);
		int dayOfMonth = Integer.parseInt(dayOfMonthString);

		if (dayOfMonth > 28) {
			// 替换日部分为28
			dateString = dateString.substring(0, 8) + "28";
		}

		return dateString;
	}
	
	public String getNonceStr() {
		return nonceStr;
	}
	
	public void setNonceStr(String nonceStr) {
		this.nonceStr = nonceStr;
	}

	public String getSign() {
		return sign;
	}
	
	public void setSign(String sign) {
		this.sign = sign;
	}
	
	public String getFailReason() {
		return failReason;
	}
	
	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}
	
	public String getLastDeductTime() {
		return lastDeductTime;
	}
	
	public void setLastDeductTime(String lastDeductTime) {
		this.lastDeductTime = lastDeductTime;
	}
	
	public String getNextDeductTime() {
		return nextDeductTime;
	}
	
	public void setNextDeductTime(String nextDeductTime) {
		this.nextDeductTime = nextDeductTime;
	}
}