/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import lombok.Data;

/**
 * 账户信息Entity
 * @author zhaozx
 * @version 2019-09-26
 */
@Data
public class AccMsg {
	public final static Integer BUZITYPE_SALE_STAFF = new Integer(1); 	//营销平台员工新消息
	public final static Integer STATUS_NOT_READ = new Integer(0);
	public final static Integer STATUS_READ = new Integer(1);
	private Integer id;
	private String serial;			//消息序列号
	private Integer buziType;		//消息业务类型
	private String  buziTag;		//消息业务标签
	private String userId;		// 用户号
	private String customerId;		// 客户号
	private String staffno;		// 员工号码
	private String msg;		// 信息
	private String openUrl;		//打开链接
	private String params;		//json字符串参数
	private Date createTime;		// 创建时间
	private Date updateTime;		// 更新时间
	private Integer status;		// 信息状态，0-未读，1-已读
	private Integer isDelete;		// 是否删除，0-否，1-是
	private String title;			//标题
	private String smsTemplate;		//信息模板
	private List<Object> smsParam;	//信息参数
	private String methodName;		//方法名
	private Map<String, Object> methodParam;		//方法参数
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSmsTemplate() {
		return smsTemplate;
	}
	public void setSmsTemplate(String smsTemplate) {
		this.smsTemplate = smsTemplate;
	}
	public List<Object> getSmsParam() {
		return smsParam;
	}
	public void setSmsParam(List<Object> smsParam) {
		this.smsParam = smsParam;
	}
	public String getSerial() {
		return serial;
	}
	public void setSerial(String serial) {
		this.serial = serial;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getBuziType() {
		return buziType;
	}
	public void setBuziType(Integer buziType) {
		this.buziType = buziType;
	}
	public String getBuziTag() {
		return buziTag;
	}
	public void setBuziTag(String buziTag) {
		this.buziTag = buziTag;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getStaffno() {
		return staffno;
	}
	public void setStaffno(String staffno) {
		this.staffno = staffno;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getOpenUrl() {
		return openUrl;
	}
	public void setOpenUrl(String openUrl) {
		this.openUrl = openUrl;
	}
	public String getParams() {
		return params;
	}
	public void setParams(String params) {
		this.params = params;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getIsDelete() {
		return isDelete;
	}
	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}
	
	
	
	public static AccMsg build(Integer buziType, String buziTag, String userId, String customerId, String staffno, String title, String msg, String openUrl, String params, String methodName, Map<String, Object> methodParam, String smsTemplate, List<Object> smsParam ) {
		String serial = UUID.randomUUID().toString().replace("-", "");
		AccMsg entity = new AccMsg();
		entity.setSerial(serial);
		entity.setBuziType(buziType);
		entity.setBuziTag(buziTag);
		entity.setUserId(userId);
		entity.setCustomerId(customerId);
		entity.setStaffno(staffno);
		entity.setStatus(AccMsg.STATUS_NOT_READ);
		entity.setCreateTime(new Date());
		entity.setMsg(msg);
		entity.setOpenUrl(openUrl);
		entity.setParams(params);
		entity.setSmsTemplate(smsTemplate);
		entity.setSmsParam(smsParam);
		entity.setMethodName(methodName);
		entity.setMethodParam(methodParam);
		return entity;
	}
}