package com.wlzq.common.model.pay;

import lombok.Data;

/**
 * 支付订单dto
 * @author louie
 * @version 2017-12-18
 */
@Data
public class PayOrderNotify {
	
	private Integer status;		//状态，0：未支付，1：已支付
	private String outTradeNo;		//务订单号（调用方订单号）
	private String orderNo;		// 支付订单号
	private Integer totalAmount;		// 订单总金额（单位：分）
	private Integer totalFee;		// 订单实际金额（单位：分）
	private Integer cashFee;		// 现金支付金额（单位：分）
	private String nonceStr;    //随机串
	private Integer payType;    //支付类型，1：微信公众号，2：微信原生扫码支付，3：微信app支付，4：保证金
	private String timeEnd;     //支付完成时间
	private String sign;     //签名
	private String failReason;	// 失败原因
//	private String coupon;		// 优惠券编码
//	private Integer couponDeduction;		// 优惠券抵扣金额
}