/**
 * Copyright &copy; 2012-2016 <a href="https://github.com/thinkgem/jeesite">JeeSite</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.util.Date;

/**
 * 积分明细Entity
 * @author louie
 * @version 2018-03-12
 */
public class PointRecord {
	public static final Integer SOURCE_GUESS = 1;
	public static final Integer SOURCE_TURNTABLE = 2;
	public static final Integer SOURCE_POINT_PRIZE = 3;
	public static final Integer SOURCE_SERVICE_COMMENT = 4;
	/* 完成任务 */
	public static final Integer SOURCE_TASK = 5;
	public static final Integer SOURCE_GUESS_51 = 3;
	public static final Integer SOURCE_TURNTABLE_51 = 4;
	public static final Integer FLOW_PLUS = 0;
	public static final Integer FLOW_ADD = 1;
	private String userId;		// 用户ID
	private Long point;		// 积分
	private String serialNo;		// 交易号
	private Integer flow;		// 流向，0：减，1：增
	private Integer sourceType;		// 来源,1-猜涨跌,2-大转盘抽奖,3-积分兑换,4-投顾社区评论
	private String remark;		// 备注
	private String description;		// 描述
	private Date participateTime;		// 行为时间

	public PointRecord() {
		super();
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Long getPoint() {
		return point;
	}

	public void setPoint(Long point) {
		this.point = point;
	}

	public String getSerialNo() {
		return serialNo;
	}

	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}

	public Integer getFlow() {
		return flow;
	}

	public void setFlow(Integer flow) {
		this.flow = flow;
	}

	public Integer getSourceType() {
		return sourceType;
	}

	public void setSourceType(Integer sourceType) {
		this.sourceType = sourceType;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getParticipateTime() {
		return participateTime;
	}

	public void setParticipateTime(Date participateTime) {
		this.participateTime = participateTime;
	}
}
