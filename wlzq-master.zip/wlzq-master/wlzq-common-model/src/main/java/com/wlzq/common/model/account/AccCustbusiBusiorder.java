/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.account;

import java.util.Date;

import lombok.Data;

/**
 * 客户业务订单Entity
 * @author zhaozx
 * @version 2020-12-22
 */
@Data
public class AccCustbusiBusiorder {
	
	private String id;
	private String customerId;		// 客户号
	private String staffAccount;		// 员工账号
	private String registerId;			// 关联登记Id
	private String accountType;		// 账号类型，2-ekp，3-crm
	private String busiType;		// 业务类型
	private String busiName;		// 业务名
	private String busiPlate;		// 业务平台，0-开户，1-投顾，2-理财
	private String busiProductName;		// 产品名
	private String busiAmt;		// 金额
	private String busiQuantity;		// 规格
	private String busiOrderId;		// 订单号
	private String busiRecommendMobile;		// 推荐人手机号
	private String busiCreateTime;		// 业务订单创建时间
	private String claimStaffCrm;		// 认领员工crm编号
	private String claimStaffName;		// 认领员工姓名
	private String claimStaffBranchname;		// 认领员工营业部
	private String comfirmStatus;		// 确认状态，1-已确认，0-为确认。空-无需确认
	private String comfirmPushCount;		// 确认推送次数
	private String pushStatus;		// 推送状态，1-完成，0-未完成
	private Date createTime;		// create_time
	private Date updateTime;		// update_time
	private String isDeleted;		// is_deleted
	
}