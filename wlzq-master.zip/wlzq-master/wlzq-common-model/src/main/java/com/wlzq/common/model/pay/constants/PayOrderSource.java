package com.wlzq.common.model.pay.constants;

/**
 * 支付订单来源
 * @author Administrator
 *
 */
public class PayOrderSource {
	/** 商城 */
	public final static Integer OUT_SD_STORE = 1;
	/** 服务平台投顾打赏 */
	public final static Integer SERVICE_INVEST_ADVISER_REWARD = 2;
	/** 服务平台策略订阅 */
	public final static Integer SERVICE_INVEST_SUB = 3;
	/** 万联研究文章订阅 */
	public final static Integer SERVICE_INVEST_RESEARCH_SUB = 4;
	/** 投顾课程 **/
	public final static Integer SERVICE_INVEST_COURSE_SUB = 5;
	/** 决策产品订阅 **/
	public final static Integer DECISION_GOODS_SUB = 6;
}
