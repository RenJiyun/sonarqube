/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.common.model.sys;

import java.util.Map;

import lombok.Data;

/**
 * 数据变动通知
 * @author louie
 * @version 2020-08-24
 */
@Data
public class DBDataNotify {
	public final static  Integer ROW_OPERATION_INSERT = 1;
	public final static  Integer ROW_OPERATION_UPDATE = 2;
	public final static  Integer ROW_OPERATION_DELETE = 3;
	public final static  Integer FIELD_TYPE_NUMBER = 1;
	public final static  Integer FIELD_TYPE_CHAR = 2;
	public final static  Integer FIELD_TYPE_DATE = 3;
	
	private Integer rowOperation;		// 操作，1：增加，2：更新，3：删除
	private String tableName;		// 表名
	private Map<String,Object> data;		// 变动数据
	private Map<String,Integer> fieldType;		// 数据类型
}