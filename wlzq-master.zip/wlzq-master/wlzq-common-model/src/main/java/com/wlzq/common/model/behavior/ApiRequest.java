package com.wlzq.common.model.behavior;

import java.util.Date;

import lombok.Data;

/**
 * 请求记录Entity
 * @author louie
 * @version 2017-10-18
 */
@Data
public class ApiRequest {
	
	private Integer id;
	private String requestId;   //请求ID
	private Integer requestOrder;   //请求顺序
	private String userId;		// 用户Id
	private String mobile;		// 用户手机
	private String key;		// key
	private String method;		// 请求方法
	private String searchParam;		// 搜索参数
	private String url;		// 请求方法
	private String ip;		// 请求IP
	private String server;		// 服务器IP
	private Integer type;		// 类型
	private Integer spend;		// 消耗时间
	private String customerId;		// 客户ID
	private String params;		// 链接
	private Integer status;		// 状态，1：成功，其它：失败
	private String statusMessage;		// 状态提示
	private Date createTime;		// 创建时间
}