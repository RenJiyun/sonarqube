package com.wlzq.common.model.account;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

/**
 * 用户Entity
 * @author louie
 * @version 2017-09-15
 */
@Data
public class User implements Serializable {
	private static final long serialVersionUID = 12152476457L;

	public static final Integer IDENTITY_STATUS_NOT_IDENTITY = 1;
	public static final Integer IDENTITY_STATUS_HALF_IDENTITY = 2;
	public static final Integer IDENTITY_STATUS_REVIEW_NOT__PASS = 3;
	public static final Integer IDENTITY_STATUS_IDENTITY = 4;
	
	private String userId;		// uid
	private String openid;	//微信openid
	private String unionid;	//开放平台unionid
	private String nickName;		// 昵称
	private String modNickName;		// 可修改昵称
	private String userName;		// 用户名
	private String mobile;		// mobile
	private String portrait;		// 头像
	private String modPortrait;		// 可修改头像
	private Integer isStaff;		//是否为员工，0：否，1：是
	private String staffNo;		//员工编号
	private String ekpAccount;		//员工编号
	private List<Integer> staffTypes;		//员工类型
	private String setAgreementSerialNo; //签署协议流水
	private Integer isIdentified;  //是否实名,
	private Integer identityStatus; //实名状态，1:未实名，2：半实名，3：审核不通过，4：实名
}