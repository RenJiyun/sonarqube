package com.wlzq.service.web;

import com.wlzq.common.RequestId;
import com.wlzq.common.constant.CodeConstant;
import com.wlzq.common.constant.SysConstant;
import com.wlzq.common.model.account.AccTokenUser;
import com.wlzq.common.model.account.Customer;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.ApiServiceTypeAnnotationProcessor;
import com.wlzq.core.RequestParams;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.annotation.LoginAnnotationProcessor;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.core.global.ThreadGlobal;
import com.wlzq.core.signature.AppSignatureMd5;
import com.wlzq.core.signature.SignatureAnnotationProcessor;
import com.wlzq.service.base.sys.biz.UserBiz;
import com.wlzq.service.base.sys.biz.application.AccApplicationBiz;
import com.wlzq.service.base.sys.utils.AppConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author
 */
@RestController
@Slf4j
@ConfigurationProperties("serviceconfig")
public class ServiceController {	
	private String[] passwordKeys = new String[] {"password","trade_pwd"};
	public static final String TOPIC_BEHAVIOR = "behavior-mysql";
	public static final String BEHAVIOR_TAGS_APIREQUEST = "apirequest";
    //jsonp 参数
	private static final String JSONP_CALLBACK = "callbackparam";
	//custtoken不参与签名标志配置（旧Api移除后可删除）
	private static final String CONFIG_IGNORE_CUSTTOKEN_SIGN = "service.ignorecusttokensign.flag";	

	//请求消息发送线程池
	private ExecutorService requestMessageSendPool = Executors.newFixedThreadPool(3);
	
	//是否只从缓存查询登录用户信息
	private boolean loginUserInfoOnlyFromCache = false;
	
    @RequestMapping(value = "/check")
    public Object check(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
    	return "ok";
    }
    
    @RequestMapping(value = "/call")
    public Object call(@RequestBody RequestParams params,HttpServletRequest request) throws UnsupportedEncodingException {
    	//打印参数，日志打印时替换密码
    	RequestParams logParams = (RequestParams) params.clone();
    	for(String psKey:passwordKeys) {
    		if(logParams.getParams().containsKey(psKey)){
    			logParams.getParams().put(psKey, "");
    		}
    	}
    	if(ObjectUtils.isEmptyOrNull(params.getServerClientIp())) {
    		params.setServerClientIp(request.getRemoteAddr());
    	}
    	logParams.getSysParams().put("params", JsonUtils.object2JSON(logParams.getParams()));
    	String paramsStr = JsonUtils.object2JSON(logParams);
    	int logStrIndex = paramsStr.length() > 1000?1000:paramsStr.length();
    	log.info("request :"+paramsStr.substring(0, logStrIndex));
    	
		Date startTime = new Date();
    	Long start = System.currentTimeMillis();
    	
    	//设置requestid
    	String requestId = params.getRequestId();
    	requestId = ObjectUtils.isEmptyOrNull(requestId)?UUID.randomUUID().toString().replaceAll("-", ""):requestId;
    	params.setRequestId(requestId);
    	//设置请求序号
    	Integer requestOrder = params.getRequestOrder();
    	requestOrder = requestOrder == null ? 1:requestOrder+1;
    	params.setRequestOrder(requestOrder);
    	logParams.setRequestOrder(requestOrder);
    	//设置requestid与请求序号的线程变量
    	RequestId requestIdInfo = new RequestId(requestId,requestOrder);
    	requestIdInfo.setClientIp(params.getClientIp());
    	requestIdInfo.setClientPort(params.getClietPort());
    	requestIdInfo.setToken(params.getToken());
    	requestIdInfo.setCustToken(params.getCustToken());
    	ThreadGlobal.reqestId.set(requestIdInfo);
    	
    	String service = params.getService();
    	String methodCall = params.getMethod();
    	if(ObjectUtils.isEmptyOrNull(service) || ObjectUtils.isEmptyOrNull(methodCall)) {
			log.info("method参数错误");
    		return new ResultDto(1 ,"method参数错误");
    	}

    	String key = params.getKey();
    	
    	Object object = SpringApplicationContext.getBean(service);
    	ResultDto result = null;
    	if(object == null) {
			log.info("服务不存在");
    		return  new ResultDto(1 ,"服务不存在");
    	}
    	Method methodC = getMethod(methodCall,object);
    	if(methodC == null) {
			log.info("服务不存在");
    		return  new ResultDto(1 ,"服务不存在");
    	}

    	// 验证服务调用类型
		if (!new ApiServiceTypeAnnotationProcessor(object).checkAccess(params.getServiceType())) {
			log.info("验证服务调用类型不匹配");
			return new ResultDto(BizException.NO_AUTH.getCode(),BizException.NO_AUTH.getMsg());
		}
		
		String userId = null;
		String mobile = null;
		String customerId = null;
	    String token = getToken(params);
    	try {
    		SignatureAnnotationProcessor signProcess = new SignatureAnnotationProcessor(object,methodC);
    		 if(signProcess.mustSign()) {
    			 AccApplicationBiz accApplicationBiz = SpringApplicationContext.getBean(AccApplicationBiz.class);
		    	String secr = accApplicationBiz.getSecret(key);
		    	if(ObjectUtils.isEmptyOrNull(secr) && !params.getServiceType().equals(ApiServiceTypeEnum.CALLBACK)) {
					log.info("应用不存在");
		    		return  new ResultDto(1 ,"应用不存在");
		    	}
    			 Map signparams = params.getSysParams();
    			 if(token != null) {
    				 signparams.put(SysConstant.TOKEY_NAME, token);
    			 }
    			 if(ObjectUtils.isNotEmptyOrNull(params.getNoncestr())) {
    				 signparams.put("noncestr", params.getNoncestr());
    			 }
    			 AppSignatureMd5 sign = new AppSignatureMd5(secr, signparams);
    			 sign.addIgnoreSignParam("nickname");
    			 sign.addIgnoreSignParam("k");
    			 sign.addIgnoreSignParam("device");
    			 Integer ignoreCustTokenSign = AppConfigUtils.getInt(CONFIG_IGNORE_CUSTTOKEN_SIGN, 1);
    			 if(ignoreCustTokenSign.equals(CodeConstant.CODE_YES)) {
    				 sign.addIgnoreSignParam("custtoken");
    			 }
    			 sign.addIgnoreSignParam(JSONP_CALLBACK);
    			 if(signProcess.tokenIgnoreSign()) {
    				 sign.addIgnoreSignParam("token");
    			 }
				if (!sign.verifySign()) {
					log.error("sign failed," + sign.singFail());
					return new ResultDto(101,"请求失败");
				}
    		 }
    		 
    		 UserBiz userBiz = SpringApplicationContext.getBean(UserBiz.class);

    		 String custmerToken = getCustomerToken(params);
    		 AccTokenUser accUser = null;
    		 int paramLength = methodC.getParameters().length;
    		 if(ObjectUtils.isNotEmptyOrNull(token)) { 
				 StatusObjDto<AccTokenUser> tokenUserResult = userBiz.findUserByToken(token,loginUserInfoOnlyFromCache);
				 accUser = tokenUserResult.getObj();
    		 }
			 if(accUser == null && new LoginAnnotationProcessor(object,methodC).mustLogin()) {//用户必需登录验证
				 log.info("用户必需登录验证");
				 return new ResultDto(BizException.NOT_LOGIN_ERROR.getCode(),BizException.NOT_LOGIN_ERROR.getMsg());
			 }
			 if(new LoginAnnotationProcessor(object,methodC).mustIdentified() && (accUser == null || 
					 !CodeConstant.CODE_YES.equals(accUser.getIsIdentified()))) {
				 log.info("必需实名用户登录验证");
				 return new ResultDto(BizException.USER_NOT_IDENTIFIED.getCode(),BizException.USER_NOT_IDENTIFIED.getMsg());
			 }
    		 Customer customer = null;
    		 if(ObjectUtils.isNotEmptyOrNull(custmerToken)) {
				 StatusObjDto<Customer> tokenCustomerResult = userBiz.findCustomerByToken(custmerToken,loginUserInfoOnlyFromCache);
				 customer = tokenCustomerResult.getObj();
    		 }
			 if(customer == null && new LoginAnnotationProcessor(object,methodC).customerMustLogin()) { //客户必需登录验证
				 log.info("客户必需登录验证");
				 return new ResultDto(BizException.CUSTOMER_NOT_LOGIN_ERROR.getCode(),BizException.CUSTOMER_NOT_LOGIN_ERROR.getMsg());
			 }
    		 
    		 if (paramLength == 1) {
    			 result = (ResultDto) methodC.invoke(object, params);
    		 } else if (paramLength == 2) {//带用户信息
    			 if(accUser == null) {
    				 StatusObjDto<AccTokenUser> tokenUserResult = userBiz.findUserByToken(token,loginUserInfoOnlyFromCache);
    				 accUser = tokenUserResult.getObj(); 
    			 }
    			 result = (ResultDto) methodC.invoke(object, params,accUser);
    		 }else if(paramLength == 3) {//带用户、客户信息
    			 if(accUser == null) {
    				 StatusObjDto<AccTokenUser> tokenUserResult = userBiz.findUserByToken(token,loginUserInfoOnlyFromCache);
     				 accUser = tokenUserResult.getObj(); 
    			 }
    			 if(customer == null) {
    				 StatusObjDto<Customer> tokenCustomerResult = userBiz.findCustomerByToken(custmerToken,loginUserInfoOnlyFromCache);
    				 if(tokenCustomerResult.isOk()) {
    					 customer = tokenCustomerResult.getObj();
    				 }
				 }
    			 result = (ResultDto) methodC.invoke(object, params,accUser,customer);
    		 }
    		 userId = accUser == null?result.getUserId():accUser.getUserId();
    		 mobile = accUser == null?result.getMobile():accUser.getMobile();
    		 customerId = customer == null?result.getCustomerId():customer.getCustomerId();
		}  catch (IllegalAccessException e) {
			log.error(e.getMessage(),e);
			result =  new ResultDto(1,"网络异常");
		} catch (IllegalArgumentException e) {
			log.error("方法参数错误，参数："+JsonUtils.object2JSON(params),e);
			result =  new ResultDto(1,"网络异常");
		} catch (InvocationTargetException e) {
			log.error("调用异常，参数："+JsonUtils.object2JSON(logParams),e);
			Object exception = e.getTargetException();
			if(exception != null && exception instanceof BizException) {
				BizException bizException = (BizException) exception;
				result =  new ResultDto(bizException.getCode(),bizException.getMsg());
			} else {
				result =  new ResultDto(1,"网络异常");
			}
		}

    	Long end = System.currentTimeMillis();
    	Long spend = end-start;
    	String outParamsStr = JsonUtils.object2JSON(result);
    	log.info("api日志<|>excute<|>"+logParams.getService()+"."+logParams.getMethod()+"<|>"+JsonUtils.map2Json(logParams.getSysParams())+"<|>"+JsonUtils.map2Json(logParams.getParams())+"<|>"+outParamsStr+"<|>"+spend);
    	result.setUserId(userId);
    	result.setMobile(mobile);
    	result.setCustomerId(customerId);
    	
    	//发送请求消息
    	sendRequestMessage(logParams,spend,result,startTime);
    	
    	return result;
    }

    private Method getMethod(String name,Object object) {
    	Method[] methods = object.getClass().getMethods();
    	for(Method method:methods) {
    		String mname = method.getName();
    		if(name.equals(mname)) {
    			return method;
    		}
    	}
    	return null;
    }

	/**
	 * 发送请求信息
	 * @param params
	 * @param spend
	 * @param result
	 * @throws UnknownHostException 
	 */
	private void sendRequestMessage(RequestParams params,Long spend,ResultDto result,Date startTime) {
//    	//若无客户端，设置客户端IP
//    	if(ObjectUtils.isEmptyOrNull(params.getClientIp())) {
//	    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
//			String clientIp = req.getRemoteAddr();
//			params.setClientIp(clientIp);
//		}
//    	//发送api请求消息
//    	requestMessageSendPool.submit(new RequestSendHandler(params, spend, result,TOPIC_BEHAVIOR,BEHAVIOR_TAGS_APIREQUEST,startTime));
	}

	public boolean isLoginUserInfoOnlyFromCache() {
		return loginUserInfoOnlyFromCache;
	}

	public void setLoginUserInfoOnlyFromCache(boolean loginUserInfoOnlyFromCache) {
		this.loginUserInfoOnlyFromCache = loginUserInfoOnlyFromCache;
	}
	
	/**
	 * 获取用户token
	 * @param params
	 * @return
	 */
    private String getToken(RequestParams params ) {
    	//若系统参数包含了token参数，则以此参数值为准
    	if(params.getSysParams().containsKey("token")) {
    		String token =  params.getSysString("token");
    		return token == null?"":token;
    	}
    	String token = params.getToken();
    	if(ObjectUtils.isNotEmptyOrNull(token)) return token;
    	token = params.getSysString(SysConstant.TOKEN_NAME);
    	if(ObjectUtils.isEmptyOrNull(token)) {
    		token = params.getCookie(SysConstant.TOKEN_NAME);
    	}
    	return token;
    }
    
    /**
     * 获取客户token
     * @param params
     * @return
     */
    private String getCustomerToken(RequestParams params) {
    	String token = params.getCustToken();
    	if(ObjectUtils.isNotEmptyOrNull(token)) return token;
    	token = params.getSysString(SysConstant.CUSTOMER_TOKEN_NAME);
    	if(ObjectUtils.isEmptyOrNull(token)) {
    		token = params.getCookie(SysConstant.CUSTOMER_TOKEN_NAME);
    	}
    	return token;
    }
    
}
