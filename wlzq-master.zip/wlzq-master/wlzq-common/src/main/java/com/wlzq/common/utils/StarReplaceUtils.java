package com.wlzq.common.utils;


public class StarReplaceUtils {

    public static String replaceStarAction(String string) {
    	if (string == null) return null;
        String userNameAfterReplaced = "";
        int nameLength = string.length();
        if(nameLength<3 && nameLength>0){
            if(nameLength==1){
                userNameAfterReplaced = "*";
            }else{
                userNameAfterReplaced = string.substring(0, 1) + "*";
            }
        }else{
            Integer num1,num2,num3;
            num2=(new Double(Math.ceil(new Double(nameLength)/3))).intValue();
            num1=(new Double(Math.floor(new Double(nameLength)/3))).intValue();
            num3=nameLength-num1-num2;
            String star = "";
            for (int i = 0; i < num2; i++) {
            	star += "*";
			}
            userNameAfterReplaced = string.replaceAll("(.{"+num1+"})(.{"+num2+"})(.{"+num3+"})","$1"+star+"$3");
        }
        return userNameAfterReplaced;
    }
}
