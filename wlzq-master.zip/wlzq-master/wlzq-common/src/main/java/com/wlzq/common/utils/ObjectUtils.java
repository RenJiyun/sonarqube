package com.wlzq.common.utils;
 
public class ObjectUtils {

    /**
     * Removes characters likely to enable Cross Site Scripting attacks from the
     * provided input string. The characters that are removed from the input
     * string, if present, are:
     *
     * <pre>
     * &lt; &gt; &quot; ' % ; ) ( &amp; + -
     * </pre>
     *
     * @param string input
     * @return Input without certain characters;
     */
    public static String removeXSSCharacters(String input) {
        final String[] xss = {"<", ">", "\"", "'", "%", ";", ")", "(", "&",
            "+", "-"};
        for (int i = 0; i < xss.length; i++) {
            input = input.replace(xss[i], "");
        }
        return input;
    }

    public static String valueOf(Object object) {

        return valueOf(object, "").trim();
    }

    public static String valueOf(Object object, String defaultEmptyValue) {

        if (object == null) {
            return defaultEmptyValue;
        }

        return String.valueOf(object);
    }
    /**
     * 判断对象是否为空
     * @param object
     * @return
     */
    public static boolean isEmptyOrNull(Object object) {

        if (ObjectUtils.valueOf(object).equals("")) {
            return true;
        }
        if(ObjectUtils.valueOf(object).equals("null")){
            return true;
        }
        return false;
    }
    /**
     * 判断对象是否为，如果为空
     * @param object
     * @return
     */
    public static boolean isNotEmptyOrNull(Object object) {
        return !isEmptyOrNull(object);
    }
 

}
