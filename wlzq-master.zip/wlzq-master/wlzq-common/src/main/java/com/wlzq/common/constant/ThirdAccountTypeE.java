package com.wlzq.common.constant;

public enum ThirdAccountTypeE {
	// 利用构造函数传参
    WECHAT (1);

    // 定义私有变量
    private int value ;

    // 构造函数，枚举类型只能为私有
    private ThirdAccountTypeE( int value) {
        this . value = value;
    }
    public int getValue(){
    	return this . value ;
    }  
}
