package com.wlzq.common.utils;

import java.util.Collection;

/***
 * 逻辑测试工具
 * @author 丁伟
 * @date 2016年6月23日
 * @version 1.0
 */
public abstract class LogicUtils {
	/***
	 * 验证值在数组中存在
	 * 
	 * @param value
	 *            要验证的值
	 * @param arr
	 *            数组集合
	 * @return
	 */
	@SafeVarargs
	public static <T> boolean in(T value, T... arr) {
		if(arr == null) {
			return false;
		}
		for (T i : arr) {
			if((i == null && value == null) || (i != null && i.equals(value))) {
				return true;
			}
		}
		return false;
	}

	/***
	 * 验证值在数组中不存在
	 * 
	 * @param value
	 *            要验证的值
	 * @param arr
	 *            数组集合
	 * @return
	 */
	@SafeVarargs
	public static <T> boolean notIn(T value, T ... arr) {
		return !in(value, arr);
	}
	
	/***
	 * 验证值是否在集合中
	 * @param value
	 * @param arr
	 * @return
	 */
	public static <T> boolean in(T value, Collection<T> arr) {
		if(arr == null) {
			return false;
		}
		for (T i : arr) {
			if ((i == null && value == null) || (i != null && i.equals(value))) {
				return true;
			}
		}
		return false;
	}
	
	/***
	 * 验证值在集合中不存在
	 * @param value
	 * @param arr
	 * @return
	 */
	public static <T> boolean notIn(T value, Collection<T> arr) {
		return !in(value, arr);
	}
}
