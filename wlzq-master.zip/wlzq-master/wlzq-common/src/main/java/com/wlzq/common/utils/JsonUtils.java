package com.wlzq.common.utils;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

/**
 * JSON工具类
 * @author 
 */
@SuppressWarnings("rawtypes")
public abstract class JsonUtils {
	private static final ObjectMapper objectMapper = new ObjectMapper();

	static {
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	}
	
	@SuppressWarnings("unchecked")
	public static final Map<String, Object> jsonToMap(String jsonStr) {
		return (Map<String, Object>)json2Map(jsonStr);
	}

	@SuppressWarnings("unchecked")
	public static final List jsonToList(String jsonStr) {
		if(ObjectUtils.isEmptyOrNull(jsonStr)) return null;
		
		try {
			return objectMapper.readValue(jsonStr, List.class);
		} catch (Exception e) {
			//logger.error("Json转换异常", e);
			return null;
		} 
	}
	
	public static String mapToJson(Map<String, Object> map) {
		return object2JSON(map);
	}
	
	public static final Map json2Map(String jsonStr) {
		if(ObjectUtils.isEmptyOrNull(jsonStr)) return null;
		
		try {
			return objectMapper.readValue(jsonStr, Map.class);
		} catch (Exception e) {
			//logger.error("Json转换异常", e);
			return null;
		} 
	}
	
	
	public static final SortedMap json2SortedMap(String jsonStr) {
		if(ObjectUtils.isEmptyOrNull(jsonStr)) return null;
		
		try {
			return objectMapper.readValue(jsonStr, SortedMap.class);
		} catch (Exception e) {
			//logger.error("Json转换异常", e);
			return null;
		} 
	}
	
	public static String object2JSON(Object obj) {
		if(obj == null){
			return "{}";
		}
		
		try {
			return objectMapper.writeValueAsString(obj);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//logger.error("转换异常", e);
			return "";
		}
		//return JSON.toJSONString(obj,SerializerFeature.WriteDateUseDateFormat);
	}
	
	public static String map2Json(Map map) {
		return object2JSON(map);
	}
	
	public static final <T> T json2Bean(String content, Class<T> valueType) {
		if (ObjectUtils.isEmptyOrNull(content))
			return null;

		try {
			return objectMapper.readValue(content, valueType);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 
	 * @param object1 当前值
	 * @param object2 前期值
	 * @return
	 */
	public static Map<String, Object> variation(Object object1, Object object2) {
		BigDecimal now = null;
		BigDecimal before = null;
		BigDecimal mulity =new BigDecimal(100);
		Map<String, Object> result = new HashMap<>();
		try {
			now = new BigDecimal(String.valueOf(object1));
			before = new BigDecimal(String.valueOf(object2));
		} catch (Exception e) {
			/**非double**/
			e.printStackTrace();
		}
		if (ObjectUtils.isEmptyOrNull(now) || ObjectUtils.isEmptyOrNull(before) || BigDecimal.ZERO.compareTo(before) == 0) {
			result.put("rate", "-");
			result.put("value", "-");
			result.put("isNegative", "+");
			return result;
		}
		BigDecimal value = now.subtract(before);
		String isNegative = BigDecimal.ZERO.compareTo(value) < 0  ? "0" : BigDecimal.ZERO.compareTo(value) > 0 ? "1" : "";
		result.put("value", String.valueOf(value));
		result.put("isNegative", isNegative);
		String rate = new DecimalFormat("#.##").format(value.multiply(mulity).divide(before, 2));
		result.put("rate", rate);
		return result;
	}
	
	/**
	* 将对象的大写转换为下划线加小写，例如：userName-->user_name
	* 
	* @param object
	* @return
	 * @throws JsonProcessingException
	*/
	public static String toUnderlineJSONString(Object object){
		ObjectMapper mapper = new ObjectMapper();
		mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
		mapper.setSerializationInclusion(Include.NON_NULL);      
		String reqJson;
		try {
			reqJson = mapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return reqJson;
	}
	
	/**
	 * 将下划线转换为驼峰的形式，例如：user_name-->userName
	 * 
	 * @param json
	 * @param clazz
	 * @return
	 * @throws IOException
	 */
	public static <T> T toSnakeObject(String json, Class<T> clazz){
		ObjectMapper mapper = new ObjectMapper();
		// mapper的configure方法可以设置多种配置（例如：多字段 少字段的处理）
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.setPropertyNamingStrategy(PropertyNamingStrategy.SNAKE_CASE);
		T reqJson;
		try {
			reqJson = mapper.readValue(json, clazz);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		return reqJson;
	}
}

