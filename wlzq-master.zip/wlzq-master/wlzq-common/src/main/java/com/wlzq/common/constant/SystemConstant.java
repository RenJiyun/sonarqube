package com.wlzq.common.constant;

/**
 * app客户端类型
 * @author Administrator
 *
 */
public class SystemConstant {
	
	public static final Integer IOS = 1;
	
	public static final Integer ANDROID = 2;
}
