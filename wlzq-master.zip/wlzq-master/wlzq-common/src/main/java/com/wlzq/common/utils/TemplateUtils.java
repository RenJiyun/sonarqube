package com.wlzq.common.utils;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * 模板参数辅助类
 * @author Administrator
 *
 */
public class TemplateUtils {

    /**
     * 参数值替换掉变量
     * @param old 内容格式 如： String content = "亲爱的用户，您获取的{0}验证码是{1}，{2}分钟内有效。日期：{3},祝您购物愉快";//短信内容
     * @param args 短信变量参数值 如: String[] params = { "{0}@@商城", "{1}@@668668", "{2}@@3", "{3}@@2014-9-5" };
     * @return 返回完整的（短信）内容
     */
    public static String getParamContent(String old, String[] args) {
        if (args != null) {
            for (int i = 0; i < args.length; i++) {
                String[] keywords = args[i].split("@@");
                String key = keywords[0];
                String word = keywords[1];
                old = old.replace(key, word);
            }
        }
        return old.replaceAll("\\{\\d\\}", "");
    }
    
    public static String replaceVar(String content, List<Object> params) {
    	if(ObjectUtils.isEmptyOrNull(content)) return content;
        if(params != null){
        	Map<String,Object> mapParams = new HashMap<String,Object>();
            for(int i =0;i<params.size();i++){
                mapParams.put("{"+i+"}", params.get(i));
            }
           content = replaceVar(content,mapParams);
        }
        return content;
    }

    /**
     * （短信）参数值替换掉变量
     * @param content 短信内容格式 如： String content = "亲爱的用户，您获取的{0}验证码是{1}，{2}分钟内有效。日期：{3},祝您购物愉快";//短信内容
     * @param map 短信变量参数值 如: map.put("{0}","雅居乐");    map.put("{1}","665698");  根据模板设置的参数格式，map的key跟模板的一致
     * @return 返回完整的（短信）内容
     */
    public static String replaceVar(String content, Map<String,Object> map) {
        if(map != null){
            Set<Map.Entry<String,Object>> entry=map.entrySet();
            for(Map.Entry<String, Object> entryMap:entry){
                String key = entryMap.getKey().toString();
                String value = entryMap.getValue().toString();
                content = content.replace(key,value);
            }
        }
        return content;
    }
    
    // content : "亲爱的用户，您获取的{0}验证码是{1}，{2}分钟内有效。日期：{3},祝您购物愉快" new Object[] {"sdfsd","1111",1}
    public static String replaceVarByArr(String content, Object ... params) {
    	if(ObjectUtils.isEmptyOrNull(content) || params== null || params.length == 0) return content;
    	
    	return MessageFormat.format(content, params);
    }

}
