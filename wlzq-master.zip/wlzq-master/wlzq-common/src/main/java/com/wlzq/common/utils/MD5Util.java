package com.wlzq.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @Title:MD5Util.java
 * @Package com.wlzq.util
 * @Description TODO
 * @author 
 * @date 
 */

public abstract class MD5Util {

	/** 
	 * 默认的密码字符串组合，用来将字节转换成 16 进制表示的字符,apache校验下载的文件的正确性用的就是默认的这个组合 
	 */
	private final static char HexDigits[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };


	/**
	 * 创建
	 * @param s 原始字符串
	 * @param charset 字符串要转换成二进制的字符集
	 * @return md5后的字符串
	 */
	public static String md5(String s, String charset) {
		byte[] bytes = null;
		try {
			bytes = s.getBytes(charset);
		} catch (UnsupportedEncodingException e) {
			return "";
		}
		MessageDigest md = newMd();
		md.update(bytes);
		return bytesToHex(md.digest());
	}
	
	/***
	 * 产生字符串的MD5
	 * @param s
	 * @return
	 */
	public static String md5(String s) {
		return md5(s, "UTF-8");
	}
	
	private static MessageDigest newMd() {
		try {
			return MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			throw new RuntimeException("不能构建Md5解密对象");
		}
	}
	
	/** 
	 * 生成字符串的md5校验值<br> 
	 * 请使用 md5方法
	 * @param s 
	 * @return 
	 */
	@Deprecated
	public static String getMD5String(String s) {
		return md5(s);
	}

	

	/** 
	 * 生成文件的md5校验值 
	 *  
	 * @param file 
	 * @return 
	 * @throws IOException 
	 */
	public static String getFileMd5(File file) throws IOException {
		InputStream fis;
		fis = new FileInputStream(file);
		byte[] buffer = new byte[1024];
		int numRead = 0;
		MessageDigest md = newMd();
		while ((numRead = fis.read(buffer)) > 0) {
			md.update(buffer, 0, numRead);
		}
		fis.close();
		return bytesToHex(md.digest());
	}

	private static String bytesToHex(byte bytes[]) {
		return bufferToHex(bytes, 0, bytes.length);
	}

	private static String bufferToHex(byte bytes[], int m, int n) {
		StringBuffer stringbuffer = new StringBuffer(2 * n);
		int k = m + n;
		for (int l = m; l < k; l++) {
			appendHexPair(bytes[l], stringbuffer);
		}
		return stringbuffer.toString();
	}

	private static void appendHexPair(byte bt, StringBuffer stringbuffer) {
		char c0 = HexDigits[(bt & 0xf0) >> 4];// 取字节中高 4 位的数字转换, >>> 为逻辑右移，将符号位一起右移,此处未发现两种符号有何不同   
		char c1 = HexDigits[bt & 0xf];// 取字节中低 4 位的数字转换   
		stringbuffer.append(c0);
		stringbuffer.append(c1);
	}

}
