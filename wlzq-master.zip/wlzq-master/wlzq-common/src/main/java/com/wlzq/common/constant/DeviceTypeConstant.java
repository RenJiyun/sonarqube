package com.wlzq.common.constant;

public class DeviceTypeConstant {
	
	/**
	 * ios
	 */
	public static final Integer IOS = 1;

	/**
	 * apk
	 */
	public static final Integer APK = 2;

	/**
	 * wx
	 */
	public static final Integer WX = 3;

	/**
	 * pc
	 */
	public static final Integer PC = 4;
	
}
