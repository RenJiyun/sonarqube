package com.wlzq.common.utils;

/**
 * 类的说明
 * @author 
 * @version 1.0
 */
public abstract class CommonUtils {
	
	public static final Integer parseInt(String value) {
		if(ObjectUtils.isEmptyOrNull(value)) return new Integer(-1);
		
		return Integer.parseInt(value);
	}

	public static String getCustomerRiskLevelTxt(Integer customerRiskLevel) {
		if(customerRiskLevel == null) return "";
		//激进型
		if(customerRiskLevel.equals(5) || customerRiskLevel.equals(6) || customerRiskLevel.equals(7) ||
				customerRiskLevel.equals(15)) {
			return "激进型";
		}
		//积极型
		if((customerRiskLevel.equals(4) || customerRiskLevel.equals(14))) {
			return  "积极型";
		}
		//稳健型
		if((customerRiskLevel.equals(3) || customerRiskLevel.equals(13))) {
			return  "稳健型";
		}
		//谨慎型
		if((customerRiskLevel.equals(2) || customerRiskLevel.equals(12))) {
			return  "谨慎型";
		}
		//保守型
		if((customerRiskLevel.equals(1) || customerRiskLevel.equals(11))) {
			return "保守型";
		}
		return "";
	}
	
}

