package com.wlzq.common.constant;

public enum RegistTypeE {
	// 利用构造函数传参
    CHECKCODE (1),AUTO_WECHAT (2),AUTO_APP(3),ACTIVITY_GUSSES(4),HOME_APP(6),LIGHTHOUSE(7);

    // 定义私有变量
    private int value ;

    // 构造函数，枚举类型只能为私有
    private RegistTypeE( int value) {
        this . value = value;
    }
    public int getValue(){
    	return this . value ;
    }  
}
