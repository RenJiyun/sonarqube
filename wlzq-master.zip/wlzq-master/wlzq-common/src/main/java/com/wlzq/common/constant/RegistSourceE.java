package com.wlzq.common.constant;

public enum RegistSourceE {
	// 利用构造函数传参
    WECHAT (1),APP(2),H5(3);

    // 定义私有变量
    private int value ;

    // 构造函数，枚举类型只能为私有
    private RegistSourceE( int value) {
        this . value = value;
    }

    public int getValue(){
    	return this . value ;
    }  
    
    public static RegistSourceE getByValue(int value){
        for(RegistSourceE rs : RegistSourceE.values()){
          if(value == rs.getValue()){
            return rs;
          }
        }
        return null;
    }
}
