/**
 * Copyright &copy; 2012-2016 <a href="https://github.com/thinkgem/jeesite">JeeSite</a> All rights reserved.
 */
package com.wlzq.common.persist;

/**
 * DAO支持类实现
 * @author 
 * @version
 */
public interface BaseDao {

}