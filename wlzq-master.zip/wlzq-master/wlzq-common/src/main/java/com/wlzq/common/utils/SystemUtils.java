package com.wlzq.common.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class SystemUtils {

	public static String getMACAddress() {
		String macAddress = "";
		if (SystemUtils.isLinux()) {
            macAddress = SystemUtils.getMACAddressByLinux();
        } else {
            macAddress = SystemUtils.getMACAddressByWindows();
        }
		return macAddress;
    }
	
	public static String getIdentifier() {
		String identifier = "";
		if (SystemUtils.isLinux()) {
			identifier = SystemUtils.getIdentifierByLinux();
        } else {
        	identifier = SystemUtils.getIdentifierByWindows();
        }
		return identifier;
    }
	
	private static Boolean isLinux() {
         String os = System.getProperty("os.name");
         return !os.toLowerCase().startsWith("win");
    }
	
	private static String getMACAddressByLinux(){
		try {
	        String[] cmd = {"ifconfig"};
	
	        Process process = Runtime.getRuntime().exec(cmd);
	        process.waitFor();
	
	        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
	        StringBuffer sb = new StringBuffer();
	        String line;
	        while ((line = br.readLine()) != null) {
	            sb.append(line);
	        }
	
	        String str1 = sb.toString();
	        String str2 = str1.split("ether")[1].trim();
	        String result = str2.split("txqueuelen")[0].trim();
	        br.close();
	
	        return result;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "";
    }
	
	private static String getIdentifierByLinux() {
		try {
	        String[] cmd = {"fdisk", "-l"};
	
	        Process process = Runtime.getRuntime().exec(cmd);
	        process.waitFor();
	
	        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
	        StringBuffer sb = new StringBuffer();
	        String line;
	        while ((line = br.readLine()) != null) {
	            sb.append(line);
	        }
	
	        String str1 = sb.toString();
	        String str2 = str1.split("identifier:")[1].trim();
	        String result = str2.split("Device Boot")[0].trim();
	        br.close();
	
	        return result;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "";
    }
	
	private static String getMACAddressByWindows()  {
		try {
	        String result = "";
	        Process process = Runtime.getRuntime().exec("ipconfig /all");
	        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), "GBK"));
	
	        String line;
	        int index = -1;
	        while ((line = br.readLine()) != null) {
	            index = line.toLowerCase().indexOf("物理地址");
	            if (index >= 0) {// 找到了
	                index = line.indexOf(":");
	                if (index >= 0) {
	                    result = line.substring(index + 1).trim();
	                }
	                break;
	            }
	        }
	       
	        br.close();
	        return result;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return "";
    }
	
	private static String getIdentifierByWindows()  {
		try {
	        String result = "";
	        Process process = Runtime.getRuntime().exec("cmd /c dir C:");
	        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), "GBK"));
	
	        String line;
	        while ((line = br.readLine()) != null) {
	            if (line.indexOf("卷的序列号是 ") != -1) {
	                result = line.substring(line.indexOf("卷的序列号是 ") + "卷的序列号是 ".length(), line.length());
	                break;
	            }
	        }
	        br.close();
	        return result;
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return "";
    }
}
