package com.wlzq.common.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class T2Utils {
	/**
	 * 解析柜台返回的错误信息，错误信息如：" [220193][证券理财账户信息表记录不存在]\r\n[p_prodta_no=CZZp_fund_account=42002076]\n",结果：
	 * 220193
	 * 证券理财账户信息表记录不存在
	 * p_prodta_no=CZZp_fund_account=42002076
	 * @param errorMsg
	 * @return
	 */
	public static List<String> getErrors(String errorMsg){
		if(ObjectUtils.isEmptyOrNull(errorMsg)) return new ArrayList<String>();
		Pattern p = Pattern.compile("(\\[[^\\]]*\\])");
	    Matcher m = p.matcher(errorMsg);
	    List<String> errors = new ArrayList<String>();
	    while(m.find()){
	      String error = m.group();
	      if(error.length() > 2) {
	    	  errors.add(error.substring(1, error.length()-1));
	      }	   
	    }
	    return errors;
	}
}
