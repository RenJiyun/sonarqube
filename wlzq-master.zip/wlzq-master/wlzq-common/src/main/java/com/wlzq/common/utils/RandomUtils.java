package com.wlzq.common.utils;

/**
 * 随机数生成
 * 
 * @author 
 * @version 1.0
 */
public abstract class RandomUtils {

	private static final int DEFAULT_POINT_BITS = 4;

	/**
	 * 生成几位随机数
	 * 
	 * @param length
	 * @return
	 */
	public static final String random(int length) {
		double d = Math.pow(10, length);
		int baseNum = Integer.parseInt(String.valueOf(d).substring(0, String.valueOf(d).lastIndexOf(".")));
		int num = java.util.concurrent.ThreadLocalRandom.current().nextInt(baseNum);
		String snum = String.valueOf(num);
		if (snum.length() == length)
			return snum;

		for (int i = 0, len = length - snum.length(); i < len; i++) {
			snum = "0" + snum;
		}
		return snum;

	}

	/**
	 * 产生从minRange到maxRange之间被multiple整除的数
	 * 
	 * @param minRange
	 * @param maxRange
	 * @param multiple
	 * @return
	 */
	/*
	public static Long multipleRandomNum(Long minRange, Long maxRange, Integer multiple) {
		Long newBalance;
		int max = (int) (maxRange / multiple + 1);
		int min = (int) (minRange % multiple == 0 ? minRange / multiple : minRange / multiple + 1);
		int range = max - min;// 将最大值除以倍数，使得不连续的值转为连续

		int random = org.apache.commons.lang.math.RandomUtils.nextInt((int) range);
		newBalance = (long) ((random + min) * multiple);
		return newBalance;
	}
	*/

	/**
	 * 产生从minRange到maxRange之间被multiple整除的数
	 * 
	 * @param minRange
	 * @param maxRange
	 * @param multiple
	 * @return
	 */
	/*
	public static double multipleRandomNumDouble(double minRange, double maxRange, double multiple) {
		return multipleRandomNumDouble(minRange, maxRange, multiple, DEFAULT_POINT_BITS);
	}
	*/

	/**
	 * 产生从minRange到maxRange之间被multiple整除的数</br>
	 * 计算是需要将double型放大倍数成为long型
	 * 
	 * @param minRange
	 * @param maxRange
	 * @param multiple
	 * @param pointBits
	 *            double值放大时，指定移动的小数位数
	 * @return
	 */
	/*
	public static double multipleRandomNumDouble(double minRange, double maxRange, double multiple, int pointBits) {

		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(pointBits);
		nf.setGroupingUsed(false);// format后不带逗号分隔

		// 使用BigDecimal 防止double失真的问题
		BigDecimal bdMinRange = new BigDecimal(nf.format(minRange)).movePointRight(pointBits);
		BigDecimal bdMaxRange = new BigDecimal(nf.format(maxRange)).movePointRight(pointBits);
		BigDecimal bdMultiple = new BigDecimal(nf.format(multiple)).movePointRight(pointBits);

		long longMinRange = bdMinRange.longValue();
		long longMaxRange = bdMaxRange.longValue();
		int intMultiple = bdMultiple.intValue();

		Long multipleRandomNum = multipleRandomNum(longMinRange, longMaxRange, intMultiple);

		BigDecimal movePointLeft = new BigDecimal(multipleRandomNum).movePointLeft(pointBits);
		double doubleValue = movePointLeft.doubleValue();

		return doubleValue;

	}
	*/
}
