package com.wlzq.common.constant;

public class WechatConstant {
	public static final String OPEN_ID = "oid";
}
