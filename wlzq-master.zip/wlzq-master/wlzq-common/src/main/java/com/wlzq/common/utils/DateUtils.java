package com.wlzq.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
 


/**
 * TODO
 * @author
 * 
 */
public class DateUtils {
	
	public static Date tomorrow(){
		return addDay(new Date(), 1);
	}
	/**
	 * 时间戳转格式化的日期
	 * @param tt
	 * @return
	 */
	public static String parseTimetamp(Integer tt){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sd = sdf.format(new Date(tt*1000));
		return sd;
	}
	public static String parseTimetamp(Long tt){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String sd = sdf.format(new Date(tt));
		return sd;
	}
	public static String parseTimetamp(Long tt,String format){
		if(tt == null){
			return null;
		}
		if(ObjectUtils.isEmptyOrNull(format)) {
			format = "yyyy-MM-dd";
		}
		SimpleDateFormat sdf=new SimpleDateFormat(format);
		String sd = sdf.format(new Date(tt));
		return sd;
	}
	/**
	 * 获取当前毫秒数
	 * @return
	 */
	public static long getSysCurrentTimeMillis(){
		return System.currentTimeMillis();
	}
	/**
	 * 获取当前时间戳.1970-1-1 至今的秒数。单位：秒。
	 * @return
	 */
	public static int getCurrentTimestamp() {
		return (int)(System.currentTimeMillis() / 1000);
	}
	
	/**
	 * 将1970-1-1 0:0:0 算起的秒数转化为时间
	 * @param second
	 * @return
	 */
	public static Date fromSecond(long second) {
		return new Date(second * 1000);
	}
	

    /**
     * 将1970-1-1 0:0:0 算起的秒数转化为时间
     * @param second
     * @return
     */
    public static Date fromMsec(long second) {
        return new Date(second);
    }
	
	/**
	 * 将时间转化为时间戳。1970-1-1 至指定时间的秒数。
	 * @param date
	 * @return
	 */
	public static int dateToTimestamp(Date date) {
		return (int)(date.getTime() / 1000);
	}
	
	public static final Date getSystemDate() {
		return Calendar.getInstance().getTime();
	}
	
	/**
	 * 格式化日期输出。如果传入data为null，则返回空字符串
	 * @param date
	 * @param format
	 * @return
	 */
	public static final String formate(Date date, String format) {
		if(date == null) return "";
		format = ObjectUtils.isEmptyOrNull(format) ? "yyyy-MM-dd" : format;
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}
	
	public static final String formate(Date date) {
		return formate(date,null);
	}
	/**
	 * 解析日期
	 * @param dateStr
	 * @param format
	 * @return
	 */
	public static final Date parseDate(String dateStr, String format) {
		if(ObjectUtils.isEmptyOrNull(dateStr)) {
			return null;
		}
		
		if(ObjectUtils.isEmptyOrNull(format)) {
			format = "yyyy-MM-dd";
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		try {
			return sdf.parse(dateStr);
		} catch (ParseException e) {
//			e.printStackTrace();
			e.printStackTrace();
			return null;
		}
		
	}
	
	/**
	 * 将java.util.Date 转换成 java.sql.Date
	 * @param date
	 * @return
	 */
	public static java.sql.Date toSqlDate(java.util.Date date) {
		if (date == null)
			return null;
		return new java.sql.Date(date.getTime());
	}

	/**
	 * 将字符串转换成数据集对象
	 * @param dateStr        目前只支持格式 yyyyMMddHHmmss
	 * @return
	 */
	public static java.sql.Date toSqlDate(String dateStr, String formate) {
		if (ObjectUtils.isEmptyOrNull(dateStr))
			return null;
		if(ObjectUtils.isEmptyOrNull(formate)) {
			formate = "yyyyMMddHHmmss";
		}
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		try {
			java.util.Date jd = sdf.parse(dateStr);
			return new java.sql.Date(jd.getTime());
		} catch (ParseException e) {
			return null;
		}

	}
	
	
	/**
	 * 获取当天时间 天 开始时间
	 * 
	 * @param d
	 * @return
	 */
	public static final Date getDayStart(Date d) {
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		return c.getTime();
	}

	/**
	 * 获取当天时间 天 开始时间
	 * 
	 * @param d
	 * @return
	 */
	public static final Date getDayEnd(Date d) {
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		c.set(Calendar.HOUR_OF_DAY, 23);
		c.set(Calendar.MINUTE, 59);
		c.set(Calendar.SECOND, 59);
		c.set(Calendar.MILLISECOND, 999);
		return c.getTime();
	}
	
	public static final Date addDay(Date d, int day) {
		return addHour(d, day * 24);
	}
	
	public static final Date addHour(Date d, int hour) {
		if( d == null || hour == 0 ) return d;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(d);
		calendar.add(Calendar.HOUR, hour);
		return calendar.getTime();
	}
	
	public static final Date minusDayStart(Date d, int day) {
		
		if( d == null) return d;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(d);
		calendar.add(Calendar.DATE, day);
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}
	
	/**
	 * 往后几个月
	 * @param d
	 * @param count
	 * @return
	 */
	public static final Date addMonth(Date d, int count) {
		if( d == null || count == 0 ) return d;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(d);
		calendar.add(Calendar.MONTH, count);
		return calendar.getTime();
	}
	
	/**
	 * 增加或减少分钟
	 * @param d
	 * @param m
	 * @return
	 */
	public static final Date addMinute(Date d, int m) {
		if( d == null || m == 0 ) return d;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(d);
		calendar.add(Calendar.MINUTE, m);
		return calendar.getTime();
	}
	
	/**
	 * 增加或减少秒
	 * @param date
	 * @param seconds
	 * @return
	 */
	public static final Date addSeconds(Date date, int seconds) {
		if( date == null || seconds == 0 ) return date;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.SECOND, seconds);
		return calendar.getTime();
	}
	
	
	/**
	 * 判断日期字符串是否为合法的日期格式 
	 * @param str
	 * @param format
	 * @return
	 */
	public static boolean isValidate(String str, String format) {
		if (ObjectUtils.isEmptyOrNull(str) || ObjectUtils.isEmptyOrNull(format))
			return false;
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			sdf.parse(str);
			return true;
		} catch (Exception e) {
			return false;
		}
		
	}
	
	public static final Date getYearStart(Date d) {
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		c.set(Calendar.MONTH, 0);
		c.set(Calendar.DATE, 1);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		return c.getTime();
	}
	
	public static final Date getYearEnd(Date d) {
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		c.set(Calendar.MONTH, 12);
		c.set(Calendar.DATE, 31);
		c.set(Calendar.HOUR_OF_DAY, 23);
		c.set(Calendar.MINUTE, 59);
		c.set(Calendar.SECOND, 59);
		return c.getTime();
	}
	
	/**
	 * 获取月 的开始时间，结束时间
	 * @param d
	 * @return
	 */
	public static final Date[] getMonthStartAndEndDates(Date d) {
		Calendar c = Calendar.getInstance();
		c.setTime(d);
		Integer year = c.get(Calendar.YEAR) ;
		Integer month = c.get(Calendar.MONTH) + 1;
		return new Date[] {getMonthStart(year, month),  getMonthEnd(year, month) };
	}
	
	
	/**
	 * 获取月 的开始时间，结束时间
	 * @param d
	 * @return
	 */
	public static final Date[] getDayStartAndEndDates(Date d) {
		return new Date[] {getDayStart(d),  getDayEnd(d) };
	}
	
	
	public static final Date getMonthStart(Integer year, Integer month) {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, month - 1);
		c.set(Calendar.DATE, 1);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		return c.getTime();
	}
	
	/**
	 * 
	 * @param year
	 * @param month  月，，10代表10月
	 * @return
	 */
	public static final Date getMonthEnd(Integer year, Integer month) {
		Calendar c = Calendar.getInstance();
		
		c.set(Calendar.YEAR, year);
		c.set(Calendar.MONTH, month - 1);
		c.set(Calendar.DATE, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		c.set(Calendar.HOUR_OF_DAY, 23);
		c.set(Calendar.MINUTE, 59);
		c.set(Calendar.SECOND, 59);
		c.set(Calendar.MILLISECOND, 999);
		return c.getTime();
	}
	
	/**
	 * 获取指定时间的年月
	 * @param date
	 * @return
	 */
	public static final Integer[] getYearAndMonth(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return new Integer[] { c.get(Calendar.YEAR) ,c.get(Calendar.MONTH) + 1 };
	}
	
    /**
     * 根据传入的格式，获取时间
     * @param format
     * @return
     */
    public static String getTimeByDateFormat(String format){
        if(ObjectUtils.isNotEmptyOrNull(format)){
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            return sdf.format(new Date()).toString();
        }
        return null;
    }
    
    /**
     * 时间比较的方法
     * 如果paramsNew>paramsOld return true,否则都return false
     * @param paramsNew
     * @param paramsOld
     * @return
     */
    public static boolean compareDate(Date paramsNew, Date paramsOld) {
        try {
           
            if (paramsNew.getTime() > paramsOld.getTime()) {
               return true;
            } else if (paramsNew.getTime() < paramsOld.getTime()) {
              return false;
            } else {
                return false;
            }
        } catch (Exception exception) {
        	 return false;
        }
    } 
     
    /** 
     * 得到本月第一天的日期 
     * @Methods Name getFirstDayOfMonth 
     * @return Date 
     */  
    public static Date getFirstDayOfMonth(Date date)   {     
        Calendar cDay = Calendar.getInstance();     
        cDay.setTime(date);  
        cDay.set(Calendar.DAY_OF_MONTH, 1); 
        return getDayStart(cDay.getTime());     
    }     
    
    /** 
     * 得到本月最后一天的日期 
     * @Methods Name getLastDayOfMonth 
     * @return Date 
     */  
    public static Date getLastDayOfMonth(Date date)   {     
        Calendar cDay = Calendar.getInstance();     
        cDay.setTime(date);  
        cDay.set(Calendar.DAY_OF_MONTH, cDay.getActualMaximum(Calendar.DAY_OF_MONTH));  
        return getDayEnd(cDay.getTime());     
    }  
    
    /*** 获取指定日期是星期几
     * 参数为null时表示获取当前日期是星期几
     * @param date
     * @return
    */
   public static String getWeekOfDate(Date date) {      
       String[] weekOfDays = {"星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六"};        
       Calendar calendar = Calendar.getInstance();      
       if(date != null){        
            calendar.setTime(date);      
       }        
       int w = calendar.get(Calendar.DAY_OF_WEEK) - 1;      
       if (w < 0){        
           w = 0;      
       }      
       return weekOfDays[w];    
   }
   
   /*** 获取指定日期是周几
    * 参数为null时表示获取当前日期是周几
    * @param date
    * @return
   */
  public static String getWeekForDate(Date date) {      
      String[] weekOfDays = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};        
      Calendar calendar = Calendar.getInstance();      
      if(date != null){        
           calendar.setTime(date);      
      }        
      int w = calendar.get(Calendar.DAY_OF_WEEK) - 1;      
      if (w < 0){        
          w = 0;      
      }      
      return weekOfDays[w];    
  }
    
   /*** 获取指定日期是星期几
    * 参数为null时表示获取当前日期是星期几
    * @param date
    * @return
   */
  public static int getIntWeekOfDate(Date date) {      
      int[] weekOfDays = {7, 1, 2, 3, 4, 5, 6};        
      Calendar calendar = Calendar.getInstance();      
      if(date != null){        
           calendar.setTime(date);      
      }        
      int w = calendar.get(Calendar.DAY_OF_WEEK) - 1;      
      if (w < 0){        
          w = 0;      
      }      
      return weekOfDays[w];    
  }
  
  /**
   * 获取所属周
   * @param date
   * @return
   */
  public static int  getWeek(Date date){
	  date = date == null?new Date():date;
      Calendar calendar = Calendar.getInstance();
      calendar.setFirstDayOfWeek(Calendar.MONDAY);//设置星期一为一周开始的第一天
      calendar.setTime(date);      
      //计算当前周
      int weekOfYear = calendar.get(Calendar.WEEK_OF_YEAR);
      return weekOfYear;
  }

  /**
   * 获取所属周周几的日期
   * @param date
   * @param weekDay
   * @return
   */
  public static Date  getWeekDate(Date date,int weekDay){
	  date = date == null?new Date():date;
      Calendar calendar = Calendar.getInstance(); 
      calendar.setFirstDayOfWeek(Calendar.MONDAY);//设置星期一为一周开始的第一天
      calendar.setTime(date);     
      int oriWeekDay = weekDay + 1 == 8?1:weekDay + 1;     
      calendar.setWeekDate(calendar.getWeekYear(), calendar.get(Calendar.WEEK_OF_YEAR), oriWeekDay);
      return calendar.getTime();
  }
  
  /*** 获取指定日期是否为周末
   * 参数为null时表示获取当前日期是否为周末
   * @param date
   * @return
  */
 public static boolean isWeekend(Date date) {
	 date = date == null?new Date():date;
     int weekOfDays = getIntWeekOfDate(date);
     boolean isWeekend = weekOfDays == 6 || weekOfDays == 7?true:false;
     return isWeekend;    
 }
  
  /**
   * 返回当前所属月天数 
   * @return
   */
  public static int getDaysOfMonth(){
	   Calendar aCalendar = Calendar.getInstance();
	   int day=aCalendar.getActualMaximum(Calendar.DATE);
	   return day;
	}
  
  /*** 获取指定日期是当月第几天
   * @param date
   * @return
  */
  public static int getDayNumberOfMonth(Date date){  
	  Calendar calendar = Calendar.getInstance();
	  if(date != null){        
          calendar.setTime(date);      
     }      
      return calendar.get(Calendar.DAY_OF_MONTH);  
  }  
    /**
     * 
     * @Title: 返回指定年月的工作日
     * @Description:
     * @Version 1.0
     * @param year 年
     * @param month 月
     * @param size 获取天数，比如返回当月前三天，则size等于3
     * @return
     */
    public static List<Date> getWorkDates(int year,int month, int size){    
        List<Date> dates = new ArrayList<Date>();    
            
        Calendar cal = Calendar.getInstance();  
        cal.set(Calendar.YEAR, year);    
        cal.set(Calendar.MONTH,  month-1);    
        cal.set(Calendar.DATE, 1);    
            
        while(cal.get(Calendar.YEAR) == year &&  cal.get(Calendar.MONTH) < month){    
            if(ObjectUtils.isNotEmptyOrNull(size) && dates.size()>= size) break;
            int day = cal.get(Calendar.DAY_OF_WEEK);    
            if(!(day == Calendar.SUNDAY || day == Calendar.SATURDAY)){    
                dates.add((Date)cal.getTime().clone());    
            }    
            cal.add(Calendar.DATE, 1);    
        }    
        return dates;    
    
    }    
    
    /**
     * 计算两个日期之间相差的天数 
     * @param dateStart 开始时间
     * @param dateEnd	结束时间
     * @return
     */
    public static int daysBetween(Date dateStart,Date dateEnd) {
    	try {
	        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");  
	        dateStart=sdf.parse(sdf.format(dateStart));  
	        dateEnd=sdf.parse(sdf.format(dateEnd));  
	        Calendar cal = Calendar.getInstance();    
	        cal.setTime(dateStart);    
	        long time1 = cal.getTimeInMillis();                 
	        cal.setTime(dateEnd);    
	        long time2 = cal.getTimeInMillis();         
	        long between_days=(time2-time1)/(1000*3600*24);  
	            
	        return Integer.parseInt(String.valueOf(between_days));
    	}catch(Exception ex) {
    		ex.printStackTrace();
    	}
    	return -1;
    }  
    
    /**
     * 加上正常工作时间(不排除假期)
     * @param date
     * @param workDays
     * @return
     */
    public static Date addWorkDays(Date date,int workDays) {
    	int comparedays = 0;
    	for(int i = 0;comparedays < workDays;i++) {
    		date = addDay(date,1);
	    	int dayofweek = getIntWeekOfDate(date);
	    	if(dayofweek == 6 || dayofweek == 7) continue;
	    	comparedays++;
    	}
    	return date;
    }
    
    /**
     * 
     * @param now
     * @param timeUnit 1-天，2-周，3-月，4-年
     * @param timeQuantity 
     * @return
     */
	public static Date addDays(Date now, Integer timeUnit, Integer timeQuantity) {
		if (now == null || timeUnit == null || timeQuantity == null) {
			return now;
		}
		Date result = now;
		switch (timeUnit) {
		case 1:
			result = addDay(now, timeQuantity);
			break;
		case 2:
			result = addDay(now, timeQuantity * 7);
			break;
		case 3:
			result = addMonth(now, timeQuantity);
			break;
		case 4:
			result = addDay(now, timeQuantity * 365);
			break;
		default:
			break;
		}
		return result;
	}
	
	/**
	 * 获取指定日期后几周的周几的日期
	 * @param currentDay
	 * @param weekStep
	 * @param dayOfWeek
	 * @return
	 */
	public static Date getDateOfNextWeek(Date currentDay, int weekStep,int dayOfWeek) {
        Calendar cal = Calendar.getInstance();   
        cal.setFirstDayOfWeek(Calendar.MONDAY);//设置星期一为一周开始的第一天
        Date date = currentDay == null?new Date():currentDay;
        cal.setTime(date);    
        int currentDayOfWeek =  cal.get(Calendar.DAY_OF_WEEK);
        currentDayOfWeek = currentDayOfWeek == 1?7:currentDayOfWeek - 1;
        int currentWeek =  cal.get(Calendar.WEEK_OF_YEAR);
        int setWeek = dayOfWeek == 7?currentWeek + 1:currentWeek;
        dayOfWeek = dayOfWeek == 7?1: dayOfWeek + 1;
        cal.setWeekDate(cal.getWeekYear(), setWeek + weekStep, dayOfWeek);
        return cal.getTime();
	}
	
	public static Integer getAge(String birthday) {
		birthday = birthday != null?birthday.trim():birthday;
		if(ObjectUtils.isEmptyOrNull(birthday) || birthday.length() != 8)  return null;
		
		String birthYear = birthday.substring(0,4);
		String birthDate = birthday.substring(4,8);
		String today = DateUtils.formate(new Date(),"yyyyMMdd");
		String nowYear = today.substring(0,4);
		String nowDate = today.substring(4,8);
		Integer yearAge = Integer.valueOf(nowYear) - Integer.valueOf(birthYear);
		Integer dateCom = Integer.valueOf(nowDate) - Integer.valueOf(birthDate);
			
		return dateCom >= 0?yearAge:yearAge -1;
	}
}
