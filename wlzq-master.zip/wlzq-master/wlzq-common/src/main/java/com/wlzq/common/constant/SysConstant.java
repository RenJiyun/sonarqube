package com.wlzq.common.constant;

public class SysConstant {
	/**
	 * 登录超时天数
	 */
	public static final Integer TOKEN_TIMEOUT_DAY = 30;
	/**
	 * 公众号登录超时天数
	 */
	public static final Integer TOKEN_TIMEOUT_DAY_WECHAT = 14;
	/**
	 * 员工登录超时天数
	 */
	public static final Integer TOKEN_TIMEOUT_DAY_STAFF = 14;
	/**
	 * app登录超时天数
	 */
	public static final Integer TOKEN_TIMEOUT_DAY_APP = 1;
	/**
	 * 用户TOKEN 参数名
	 */
	public static final String TOKEN_NAME = "token";
	/**
	 * 客户TOKEN 参数名
	 */
	public static final String CUSTOMER_TOKEN_NAME = "custtoken";
	/**
	 * 应用KEY 参数名
	 */
	public static final String KEY_NAME = "k";

	/**
	 * 用户TOKEN 参数名(历史保留)
	 */
	public static final String TOKEY_NAME = "token";
}
