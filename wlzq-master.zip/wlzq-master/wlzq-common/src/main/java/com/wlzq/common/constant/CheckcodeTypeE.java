package com.wlzq.common.constant;

public enum CheckcodeTypeE {
	// 利用构造函数传参
	LOGIN (1),
	LEVEL2_LOTTERY(2),
	ACTIVITY_ANSWER_RECIEVE_PRIZE(3),
	/** hr实习招聘活动 */
	ACTIVITY_INTERNSHIP_RECRUITMENT(4)
	/** level2领取活动 */
	,ACTIVITY_LEVEL2_RECIEVE_INVITE(5)
	/** 用户注册 */
	,USER_REGIST(6)
	/** 字节营销短信 */
	,BYTED_SALE(7)
	/** 非法证券活动举报功能 */
	,PHONE_CHECK(8)
	/** 条件单手机号校验 */
	,TJD_PHONE_CHECK(9);
	

    // 定义私有变量
    private int value ;

    // 构造函数，枚举类型只能为私有
    private CheckcodeTypeE( int value) {
        this . value = value;
    }

    public int getValue(){
    	return this . value ;
    }  
}
