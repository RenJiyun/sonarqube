package com.wlzq.common.utils;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.http.HttpStatus;

/**
 * 下载工具类
 * @author 
 *
 */
public class DownLoadUtils {
	
	/**
	 * 通过连接下载文件
	 * @param url
	 * @return
	 */
	public static byte[] download(String url){
		try{
			URL urlMgr=new URL(url);
			HttpURLConnection https=(HttpURLConnection)urlMgr.openConnection();
			//设置连续属性
			// 连接超时
            https.setConnectTimeout(25000);
            // 读取超时 --服务器响应比较慢，增大时间
            https.setReadTimeout(25000);
            https.setRequestMethod("GET");
            https.setDoOutput(true);
            https.setDoInput(true);
            https.connect();//打开连接
            
            if(https.getResponseCode()==HttpStatus.SC_OK){
            	//接收返回数据
                InputStream in = https.getInputStream();
            	ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
            	
				// 创建一个输出流  
				int bytesRead = 0;
                byte[] buffer = new byte[1024 * 1024];
                while ((bytesRead = in.read(buffer)) != -1) {
                	swapStream.write(buffer, 0, bytesRead);
                }
                in.close();
                https.disconnect();
                
                return swapStream.toByteArray();
            }else{
            	https.disconnect();
            }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
}
