package com.wlzq.common.constant;

public class ClientTypeConstant {
	
	/**
	 * 微信
	 */
	public static final Integer WECHAT = 1;

	/**
	 * app
	 */
	public static final Integer APP = 2;

	/**
	 * h5
	 */
	public static final Integer H5 = 3;

	/**
	 * 其它
	 */
	public static final Integer OTHER = 4;
	
}
