package com.wlzq.common;

public class RequestId {
	private String requestId;
	private Integer requestOrder;
	private String clientIp;
	private Integer clientPort;
	private String token;
	private String custToken;
	
	public RequestId(String requestId, Integer requestOrder) {
		super();
		this.requestId = requestId;
		this.requestOrder = requestOrder;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Integer getRequestOrder() {
		return requestOrder;
	}

	public void setRequestOrder(Integer requestOrder) {
		this.requestOrder = requestOrder;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public Integer getClientPort() {
		return clientPort;
	}

	public void setClientPort(Integer clientPort) {
		this.clientPort = clientPort;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getCustToken() {
		return custToken;
	}

	public void setCustToken(String custToken) {
		this.custToken = custToken;
	}
	
}
