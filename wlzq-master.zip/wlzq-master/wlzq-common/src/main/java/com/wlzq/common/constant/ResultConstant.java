package com.wlzq.common.constant;

public class ResultConstant {
	/**
	 * 成功
	 */
	public static final Integer SUCCESS = 0;
	/**
	 * 失败
	 */
	public static final Integer FAIL = 1;
	/**
	 * json输出
	 */
	public static final Integer OUTPUT_TYPE_JSON = 1;
	/**
	 * text输出
	 */
	public static final Integer OUTPUT_TYPE_TEXT = 2;
	/**
	 * 图片输出
	 */
	public static final Integer OUTPUT_TYPE_IMAGE = 3;
}
