package com.wlzq.common.utils;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.net.URLDecoder;
import java.net.URLEncoder;

/**
 * @author woohedy
 * @class  AES
 * @description AES加密用于账户对接
 * @date 2017/5/9
 * @project power-mnjy-common
 * @package com.mogucaifu.common.util
 */
public class AES {

    /**
     * 加密
     * @param encData 要加密的数据
     * @param secretKey 密钥 ,16位的数字和字母
     * @param vector 初始化向量,16位的数字和字母
     * @return
     * @throws Exception
     */
    public static String Encrypt(String encData ,String secretKey,String vector) throws Exception {

        if(secretKey == null) {
            return null;
        }
        if(secretKey.length() != 16) {
            return null;
        }
        byte[] raw = secretKey.getBytes();
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");// "算法/模式/补码方式"
        IvParameterSpec iv = new IvParameterSpec(vector.getBytes());// 使用CBC模式，需要一个向量iv，可增加加密算法的强度
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
        byte[] encrypted = cipher.doFinal(encData.getBytes());
        return encodeBytes( encrypted );
    }

    /**
     * 解密
     * @param decData
     * @param secretKey 密钥 ,16位的数字和字母
     * @param vector 初始化向量,16位的数字和字母
     * @return
     * @throws Exception
     */
    public static String Decrypt(String decData ,String secretKey,String vector) throws Exception{

        if(secretKey == null) {
            return null;
        }
        if(secretKey.length() != 16) {
            return null;
        }
        byte[] raw = secretKey.getBytes("ASCII");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec iv = new IvParameterSpec(vector.getBytes());
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
        byte[] encrypted1 = decodeBytes(decData);
        byte[] original = cipher.doFinal(encrypted1);
        String originalString = new String(original);
        return originalString;
    }

    public static String EncryptByUtf8(String encData ,String secretKey,String vector) throws Exception {

        if(secretKey == null) {
            return null;
        }
        if(secretKey.length() != 16) {
            return null;
        }
        byte[] raw = secretKey.getBytes();
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");// "算法/模式/补码方式"
        IvParameterSpec iv = new IvParameterSpec(vector.getBytes());// 使用CBC模式，需要一个向量iv，可增加加密算法的强度
        cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
        byte[] byteContent = URLEncoder.encode(encData, "UTF-8").getBytes("UTF-8");
        byte[] encrypted = cipher.doFinal(byteContent);
        return encodeBytes( encrypted );
    }

    /**
     * 转16进制
     * @param bytes
     * @return
     */
    public static String encodeBytes(byte[] bytes) {
        StringBuffer strBuf = new StringBuffer();
        for (int i = 0; i < bytes.length; i++) {
            strBuf.append((char) (((bytes[i] >> 4) & 0xF) + ((int) 'a')));
            strBuf.append((char) (((bytes[i]) & 0xF) + ((int) 'a')));
        }
        return strBuf.toString();
    }

    /**
     * 转字节数组
     * @param str
     * @return
     */
    public static byte[] decodeBytes(String str) {
        byte[] bytes = new byte[str.length() / 2];
        for (int i = 0; i < str.length(); i += 2) {
            char c = str.charAt(i);
            bytes[i / 2] = (byte) ((c - 'a') << 4);
            c = str.charAt(i + 1);
            bytes[i / 2] += (c - 'a');
        }
        return bytes;
    }


    /**
     * 解密
     * @param decData
     * @param secretKey 密钥 ,16位的数字和字母
     * @param vector 初始化向量,16位的数字和字母
     * @return
     * @throws Exception
     */
    public static String DecryptForJhzq(String decData ,String secretKey,String vector) throws Exception{

        if(secretKey == null) {
            return null;
        }
        if(secretKey.length() != 16) {
            return null;
        }
        byte[] raw = secretKey.getBytes("UTF-8");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec iv = new IvParameterSpec(vector.getBytes());
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
        byte[] encrypted1 = Base64.decode(decData);
        byte[] original = cipher.doFinal(encrypted1);
        String originalString = new String(original);
        return originalString;
    }

    /**
     * 解密UTF-8
     * @param decData
     * @param secretKey 密钥 ,16位的数字和字母
     * @param vector 初始化向量,16位的数字和字母
     * @return
     * @throws Exception
     */
    public static String DecryptByUTF8(String decData ,String secretKey,String vector) throws Exception{

        if(secretKey == null) {
            return null;
        }
        if(secretKey.length() != 16) {
            return null;
        }
        byte[] raw = secretKey.getBytes("ASCII");
        SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        IvParameterSpec iv = new IvParameterSpec(vector.getBytes());
        cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
        byte[] encrypted1 = decodeBytes(decData);
        byte[] original = cipher.doFinal(encrypted1);
        return  URLDecoder.decode(new String(original), "UTF-8");
    }
   
    // 解密
    public static String Decrypt( byte[] encrypted, String sKey) throws Exception {
        try {
            // 判断Key是否正确
            if (sKey == null) {
                return null;
            }
            // 判断Key是否为16位
            if (sKey.length() != 16) {
                return null;
            }
            byte[] raw = sKey.getBytes("utf-8");
            SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec);
            try {
                byte[] original = cipher.doFinal(encrypted);
                String originalString = new String(original,"utf-8");
                return originalString;
            } catch (Exception e) {
                return null;
            }
        } catch (Exception ex) {
            return null;
        }
    }
    
    public static void main(String[] args) throws Exception {

//        String secretKey = "tnKhqETVG2ytO9Bv"; //测试环境
//        String vector = "9536822434263094"; //测试环境
//
//        String toEncryptStr = "{\"openid\":\"oBxq1wLIGMiHv6DwTKv8utxffwqo\",\"nickname\":\"%E5%AE%8F%E6%B3%BD\",\"logoId\":\"http://wx.qlogo.cn/mmopen/PiajxSqBRaEL308QFrERqLy3E8dqYJawxe2RjYPkZ8ibvyvc42UYicc1oa9YW2yw8UJvpsBicc4iaibst93n9bU97MFQ/0\"}";
//
//        String encryptStr = AES.Encrypt(toEncryptStr, secretKey, vector);
//        System.out.println(encryptStr);
//
//        String decryptStr = AES.Decrypt(encryptStr, secretKey, vector);
//        System.out.println(encryptStr);
//
//        Assert.assertTrue(toEncryptStr.equals(decryptStr));


    }

}
