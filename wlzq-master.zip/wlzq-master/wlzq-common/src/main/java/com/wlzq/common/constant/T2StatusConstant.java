package com.wlzq.common.constant;

public class T2StatusConstant {
	/**
	 * 停止运行
	 */
	public static final String STOP = "0";
	/**
	 * 正常运行
	 */
	public static final String NORMAL = "1";
	/**
	 * 系统测试
	 */
	public static final String TEST = "2";
	/**
	 * 系统维护
	 */
	public static final String MAINTAINANCE = "5";
	/**
	 * 收市数据处理
	 */
	public static final String CLOSEING_DATA_PROCESSING = "6";
	
}
