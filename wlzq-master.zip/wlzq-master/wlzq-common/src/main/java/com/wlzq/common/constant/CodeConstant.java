package com.wlzq.common.constant;

public class CodeConstant {
	
	/**
	 * 成功
	 */
	public static final Integer SUCCESS = 0;

	/**
	 * 是
	 */
	public static final Integer CODE_YES = 1;

	/**
	 * 否
	 */
	public static final Integer CODE_NO = 0;
	
	/**
	 * 成功
	 */
	public static final String SUCCESS_MSG = "";
	
	/**
	 * 未登录
	 */
	public static final Integer NOT_LOGIN = 1000001;
	/**
	 * 应用不存在
	 */
	public static final Integer APPLICATION_NOT_FOUND = 1000002;
}
