package com.wlzq.common.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 基于 httpclient 4.3.1版本的 http工具类
 * 
 * @author
 *
 */
public class SdHttpClientUtils {
	private static String[] passwordKeys = new String[] {"password","trade_pwd"};
	public static class HttpResult {
		public int stateCode;
		public Object content;
		public Map<String,String> responseCookies;
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(SdHttpClientUtils.class);
	//private static CloseableHttpClient httpClient;
	public static final String DefaultCharset = "UTF-8";

	/*static {
		RequestConfig config = RequestConfig.custom().setConnectTimeout(600000).setSocketTimeout(600000).build();
		httpClient = HttpClientBuilder.create().setDefaultRequestConfig(config).build();
	}*/

	public static <T extends Object> Object doGet(String url, Map<String, T> params) {
		return doGet(url, params, DefaultCharset);
	}

	public static <T extends Object> Object doPost(String url, Map<String, T> params) {
		return doPost(url, params,null, DefaultCharset);
	}

	public static <T extends Object> Object doPost(String url, Map<String, T> params,Map<String, String> cookies) {
		return doPost(url, params,cookies, DefaultCharset);
	}
	

	public static <T extends Object> String doPost(String url, String input) {
		return doPost(url,input,10000);
	}

	public static <T extends Object> String doPost(String url, String input,int timeout) {
		// post请求返回结果  
        CloseableHttpClient httpClient = HttpClients.createDefault();  
        HttpPost httpPost = new HttpPost(url);  
        // 设置请求和传输超时时间  
        RequestConfig requestConfig = RequestConfig.custom()  
                .setSocketTimeout(10000).setConnectTimeout(10000).build();  
        httpPost.setConfig(requestConfig);  
        try {  
            if (null != input) {  
                // 解决中文乱码问题  
                StringEntity entity = new StringEntity(input,  "utf-8");  
                entity.setContentEncoding("UTF-8");  
                entity.setContentType("application/json");  
                httpPost.setEntity(entity);  
            }  
            CloseableHttpResponse result = httpClient.execute(httpPost);  
            //请求发送成功，并得到响应  
            if (result.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {  
                String str = "";  
                try {  
                    //读取服务器返回过来的json字符串数据   
                    str = EntityUtils.toString(result.getEntity(), "utf-8"); 
                    LOGGER.info("http:post:result: {}", url+":"+str);
                    return str;
                } catch (Exception e) {  
                   e.printStackTrace(); 
                }  
            }  
        } catch (IOException e) {  
        	e.printStackTrace();   
        } finally {  
            httpPost.releaseConnection();  
        }  
        return null;  
	}
	
	private static CloseableHttpClient getHttpClient(){
		RequestConfig config = RequestConfig.custom().setConnectTimeout(10000).setSocketTimeout(10000).build();
		return  HttpClientBuilder.create().setDefaultRequestConfig(config).build();
	}

	private static CloseableHttpClient getHttpClient(BasicCookieStore cookieStore){
		RequestConfig config = RequestConfig.custom().setConnectTimeout(10000).setSocketTimeout(10000).build();
		return  HttpClientBuilder.create().setDefaultCookieStore(cookieStore).setDefaultRequestConfig(config).build();
	}
	
	/**
	 * HTTP Get 获取内容
	 * 
	 * @param url
	 *            请求的url地址 ?之前的地址
	 * @param params
	 *            请求的参数
	 * @param charset
	 *            编码格式
	 * @return 页面内容
	 */
	public static <T extends Object> String doGet(String url, Map<String, T> params, String charset) {
		if (url == null || url.equals("")) {
			return null;
		}
		String oUrl = url;
		CloseableHttpResponse response = null;
		String result = null;

		try {
			if (params != null && !params.isEmpty()) {
				List<NameValuePair> pairs = new ArrayList<NameValuePair>(params.size());
				for (Map.Entry<String, T> entry : params.entrySet()) {
					Object value = entry.getValue();
					if (value != null) {
						pairs.add(new BasicNameValuePair(entry.getKey(), value.toString()));
					}
				}
				url += "?" + EntityUtils.toString(new UrlEncodedFormEntity(pairs, charset));
			}
			HttpGet httpGet = new HttpGet(url);
			response = getHttpClient().execute(httpGet);

			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != 200) {
				httpGet.abort();
				throw new RuntimeException("HttpClient,error status code :" + statusCode);
			}
			HttpEntity entity = response.getEntity();

			if (entity != null) {
				result = EntityUtils.toString(entity, "utf-8");
			}
			EntityUtils.consume(entity);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
				}
			}
			response = null;
		}
		
		//日志打印时替换密码
		if(params != null) {
			for(String password:passwordKeys) {
				if(params.containsKey(password)) {
					params.put(password, null);
				}
			}
		}
		LOGGER.info("http:get:request:url: {}, params:{}", oUrl, params);
		LOGGER.info("http:get:result: {}", result);
		return result;
	}

	/**
	 * HTTP Post 获取内容 请求响应，非200将抛出异常。
	 * 
	 * @param url
	 *            请求的url地址 ?之前的地址
	 * @param params
	 *            请求的参数
	 * @param charset
	 *            编码格式
	 * @return 页面内容
	 */
	public static <T extends Object> Object doPost(String url, Map<String, T> params,Map<String, String> cookies, String charset) {

		HttpResult result = doPostReturnStateCode(url, params,cookies, charset);
		if (result.stateCode != 200) {
			throw new RuntimeException("HttpClient,error status code :" + result.stateCode);
		}
		return result.content;

	}

	public static <T extends Object> HttpResult doGetReturnStateCode(String url, Map<String, T> params) {
		return doGetReturnStateCode(url, params, null, DefaultCharset);
	}

	public static <T extends Object> HttpResult doPostReturnStateCode(String url, Map<String, T> params) {
		return doPostReturnStateCode(url, params,null, DefaultCharset);
	}

	/**
	 * HTTP Get 获取内容，返回状态和请求内容 <br>
	 * 返回状态码，不是200也成功返回结果
	 * 
	 * @param url
	 *            请求的url地址
	 * @param params
	 *            请求参数
	 * @param charset
	 *            编码格式
	 * @return 页面内容
	 */
	public static <T extends Object> HttpResult doGetReturnStateCode(String url, Map<String, T> params,
			Map<String, String> reqcookies,	String charset) {
		if (url == null || url.equals("")) {
			return null;
		}
		String oUrl = url;
		BasicCookieStore cookieStore = new BasicCookieStore();
		CloseableHttpClient httpClient=getHttpClient(cookieStore);
		//CloseableHttpClient httpClient=getHttpClient();
		int statusCode = -1;
		CloseableHttpResponse response = null;
		HttpResult result = new HttpResult();
		
		try {
			if (params != null && !params.isEmpty()) {
				List<NameValuePair> pairs = new ArrayList<NameValuePair>(params.size());
				for (Map.Entry<String, T> entry : params.entrySet()) {
					Object value = entry.getValue();
					if (value != null) {
						pairs.add(new BasicNameValuePair(entry.getKey(), value.toString()));
					}
				}
				url += "?" + EntityUtils.toString(new UrlEncodedFormEntity(pairs, charset));
			}
			HttpGet httpGet = new HttpGet(url);

			if(reqcookies != null && reqcookies.size() > 0) {
				String cookies = "";
				for(String key:reqcookies.keySet()) {
					cookies += key+"="+reqcookies.get(key)+";";
				}
				cookies = cookies.substring(0, cookies.length()-1);
				httpGet.setHeader("Cookie",cookies);
			}
			
			response = httpClient.execute(httpGet);

			statusCode = response.getStatusLine().getStatusCode();
			result.stateCode = response.getStatusLine().getStatusCode();
			HttpEntity entity = response.getEntity();
			
			if (entity != null) {
				String mineType = EntityUtils.getContentMimeType(entity);
				if(!mineType.contains("image")) {
					result.content = EntityUtils.toString(entity, charset);
				}else {
					result.content = EntityUtils.toByteArray(entity);
				}
			}
			
			EntityUtils.consume(entity);

			List<Cookie> cookies = cookieStore.getCookies();
			String session = "";
			if (!cookies.isEmpty()) {
				for (int i = 0; i < cookies.size(); i++) {
					if(cookies.get(i).getName().equals("JSESSIONID")) {
						session = cookies.get(i).getValue();
						break;
					}
				}
			}
			if(!session.equals("")) {
				result.responseCookies = new HashMap<String,String>();
				result.responseCookies.put("JSESSIONID",session);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
				}
			}
			if(httpClient!=null){
				try {
					httpClient.close();
				} catch (IOException e) {
				}
			}
			httpClient=null;
			response = null;
		}

		//日志打印时替换密码
		if(params != null) {
			for(String password:passwordKeys) {
				if(params.containsKey(password)) {
					params.put(password, null);
				}
			}
		}
		
		LOGGER.info("http:get:request:url: {}, params:{}", oUrl, params);
		LOGGER.info("http:get:result: {}", result);
		
		return result;
	}

	/**
	 * HTTP Post 获取内容,返回状态和请求内容。<br>
	 * 返回状态码，不是200也成功返回结果
	 * 
	 * @param url
	 *            请求的url地址 ?之前的地址
	 * @param params
	 *            请求的参数
	 * @param charset
	 *            编码格式
	 * @return 页面内容
	 */
	@SuppressWarnings("deprecation")
	public static <T extends Object> HttpResult doPostReturnStateCode(String url, Map<String, T> params,
			Map<String, String> reqcookies,String charset) {
		if (url == null || url.equals("")) {
			return null;
		}
		String oUrl = url;
		BasicCookieStore cookieStore = new BasicCookieStore();
		CloseableHttpClient httpClient=getHttpClient(cookieStore);
		HttpResult result = new HttpResult();
		String paramsStr = params.toString();
		int index = paramsStr.length() > 500?500:paramsStr.length();
		CloseableHttpResponse response = null;

		try {
			List<NameValuePair> pairs = null;
			if (params != null && !params.isEmpty()) {
				pairs = new ArrayList<NameValuePair>(params.size());
				for (Map.Entry<String, T> entry : params.entrySet()) {
					Object value = entry.getValue();
					if (value != null) {
						pairs.add(new BasicNameValuePair(entry.getKey(), value.toString()));
					}
				}
			}
			HttpPost httpPost = new HttpPost(url);
			if (pairs != null && pairs.size() > 0) {
				httpPost.setEntity(new UrlEncodedFormEntity(pairs, charset));
			}
			
			if(reqcookies != null && reqcookies.size() > 0) {
				String cookies = "";
				for(String key:reqcookies.keySet()) {
					cookies += key+"="+reqcookies.get(key)+";";
				}
				cookies = cookies.substring(0, cookies.length()-1);
				httpPost.setHeader("Cookie",cookies);
			}
			
			response = httpClient.execute(httpPost);
			result.stateCode = response.getStatusLine().getStatusCode();
			
			HttpEntity entity = response.getEntity();
			if (entity != null) {
				String mineType = EntityUtils.getContentMimeType(entity);
				if(!mineType.contains("image")) {
					result.content = EntityUtils.toString(entity, charset);
				}else {
					result.content = EntityUtils.toByteArray(entity);
				}
			}
			EntityUtils.consume(entity);
			
			List<Cookie> cookies = cookieStore.getCookies();
			String session = "";
			if (!cookies.isEmpty()) {
				for (int i = 0; i < cookies.size(); i++) {
					if(cookies.get(i).getName().equals("JSESSIONID")) {
						session = cookies.get(i).getValue();
						break;
					}
				}
			}
			if(!session.equals("")) {
				result.responseCookies = new HashMap<String,String>();
				result.responseCookies.put("JSESSIONID",session);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (response != null) {
				try {
					response.close();
				} catch (IOException e) {
				}
			}
			if(httpClient!=null){
				try {
					httpClient.close();
				} catch (IOException e) {
				}
			}
			httpClient=null;
			response = null;
		}

		//日志打印时替换密码
		if(params != null) {
			for(String password:passwordKeys) {
				if(params.containsKey(password)) {
					params.put(password, null);
				}
			}
		}
		
		LOGGER.info("http:post:request:url: {}, params:{}", oUrl, params.toString().substring(0, index));
		LOGGER.info("http:post:result: {}", result.content);
		
		return result;
	}

}
