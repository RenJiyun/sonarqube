package com.wlzq.dtasource.dynamic.enums;

/**
 * 数据源枚举
 * @author zhujt
 */
public enum DataSourceEnum {

	/**
	 * 主库
	 */
	MASTER,

	/**
	 * 从库
	 */
	SLAVE;
	
}
