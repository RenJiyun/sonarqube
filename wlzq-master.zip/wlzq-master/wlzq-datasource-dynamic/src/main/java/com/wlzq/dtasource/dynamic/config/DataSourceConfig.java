package com.wlzq.dtasource.dynamic.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.wlzq.dtasource.dynamic.DynamicDataSource;
import com.wlzq.dtasource.dynamic.enums.DataSourceEnum;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * 自定义动态数据源类
 * @author zhujt
 */
@Configuration
public class DataSourceConfig {

    @Bean(name = "dataSourceMaster")
    @Primary
    public DataSource dataSourceMaster(MasterConfig masterConfig) throws Exception {
        DruidDataSource druidDataSourceMaster = new DruidDataSource();
        druidDataSourceMaster.setUrl(masterConfig.getUrl());
        druidDataSourceMaster.setUsername(masterConfig.getUsername());
        druidDataSourceMaster.setPassword(masterConfig.getPassword());
        druidDataSourceMaster.setDriverClassName(masterConfig.getDriverClassName());
        druidDataSourceMaster.setInitialSize(masterConfig.getInitialSize());
        druidDataSourceMaster.setMinIdle(masterConfig.getMinIdle());
        druidDataSourceMaster.setMaxActive(masterConfig.getMaxActive());
        druidDataSourceMaster.setMaxWait(masterConfig.getMaxWait());
        druidDataSourceMaster.setTimeBetweenEvictionRunsMillis(masterConfig.getTimeBetweenEvictionRunsMillis());
        druidDataSourceMaster.setValidationQuery(masterConfig.getValidationQuery());
        druidDataSourceMaster.setTestWhileIdle(masterConfig.getTestWhileIdle());
        druidDataSourceMaster.setTestOnBorrow(masterConfig.getTestOnBorrow());
        druidDataSourceMaster.setTestOnReturn(masterConfig.getTestOnReturn());
        druidDataSourceMaster.setPoolPreparedStatements(masterConfig.getPoolPreparedStatements());
        druidDataSourceMaster.setMaxPoolPreparedStatementPerConnectionSize(masterConfig.getMaxPoolPreparedStatementPerConnectionSize());
        druidDataSourceMaster.setFilters(masterConfig.getFilters());
        druidDataSourceMaster.setConnectProperties(masterConfig.getConnectionProperties());
        return druidDataSourceMaster;
    }

    @Bean(name = "dataSourceSlave")
    public DataSource dataSourceSlave(SlaveConfig slaveConfig) throws Exception {
        DruidDataSource druidDataSourceSlave = new DruidDataSource();
        druidDataSourceSlave.setUrl(slaveConfig.getUrl());
        druidDataSourceSlave.setUsername(slaveConfig.getUsername());
        druidDataSourceSlave.setPassword(slaveConfig.getPassword());
        druidDataSourceSlave.setDriverClassName(slaveConfig.getDriverClassName());
        druidDataSourceSlave.setInitialSize(slaveConfig.getInitialSize());
        druidDataSourceSlave.setMinIdle(slaveConfig.getMinIdle());
        druidDataSourceSlave.setMaxActive(slaveConfig.getMaxActive());
        druidDataSourceSlave.setMaxWait(slaveConfig.getMaxWait());
        druidDataSourceSlave.setTimeBetweenEvictionRunsMillis(slaveConfig.getTimeBetweenEvictionRunsMillis());
        druidDataSourceSlave.setValidationQuery(slaveConfig.getValidationQuery());
        druidDataSourceSlave.setTestWhileIdle(slaveConfig.getTestWhileIdle());
        druidDataSourceSlave.setTestOnBorrow(slaveConfig.getTestOnBorrow());
        druidDataSourceSlave.setTestOnReturn(slaveConfig.getTestOnReturn());
        druidDataSourceSlave.setPoolPreparedStatements(slaveConfig.getPoolPreparedStatements());
        druidDataSourceSlave.setMaxPoolPreparedStatementPerConnectionSize(slaveConfig.getMaxPoolPreparedStatementPerConnectionSize());
        druidDataSourceSlave.setFilters(slaveConfig.getFilters());
        druidDataSourceSlave.setConnectProperties(slaveConfig.getConnectionProperties());
        return druidDataSourceSlave;
    }

    /**
     * 动态数据源，配置需要使用到的多个数据源
     * @param master
     * @param slave
     * @return
     */
    @Bean
    public DynamicDataSource dynamicDataSource(@Qualifier("dataSourceMaster") DataSource master, @Qualifier("dataSourceSlave") DataSource slave) {
        Map<Object, Object> targetDataSources = new HashMap<>(2);
        targetDataSources.put(DataSourceEnum.MASTER, master);
        targetDataSources.put(DataSourceEnum.SLAVE, slave);
        DynamicDataSource dynamicDataSource = new DynamicDataSource();
        /**设置默认数据源为dataSourceMaster*/
        dynamicDataSource.setDefaultTargetDataSource(master);
        /**设置targetDataSources*/
        dynamicDataSource.setTargetDataSources(targetDataSources);
        return dynamicDataSource;
    }

    /**
     * 将动态数据源交给事务管理器，确保执行事务时使用动态数据源
     * @param dynamicDataSource
     * @return
     */
    @Bean
    public PlatformTransactionManager transactionManager(DynamicDataSource dynamicDataSource) {
        return new DataSourceTransactionManager(dynamicDataSource);
    }

    @Bean
    public SqlSessionFactory sqlSessionFactory(DynamicDataSource dynamicDataSource) throws Exception {
        SqlSessionFactoryBean sessionFactory = new SqlSessionFactoryBean();
        sessionFactory.setDataSource(dynamicDataSource);
        sessionFactory.setMapperLocations(((ResourcePatternResolver) new PathMatchingResourcePatternResolver())
                .getResources("classpath*:mappers/**/*Dao.xml"));
        sessionFactory.setTypeAliasesPackage("com.wlzq");
        return sessionFactory.getObject();
    }
}
