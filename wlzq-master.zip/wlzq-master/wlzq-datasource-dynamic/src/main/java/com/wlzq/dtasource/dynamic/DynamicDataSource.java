package com.wlzq.dtasource.dynamic;

import com.wlzq.dtasource.dynamic.enums.DataSourceEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.util.ObjectUtils;

/**
 * 自定义动态数据源类
 * @author zhujt
 */
@Slf4j
public class DynamicDataSource extends AbstractRoutingDataSource {
	@Override
	protected Object determineCurrentLookupKey() {
		DataSourceEnum dataSourceEnum = DynamicDataSourceContextHolder.getDataSource();
		log.info("当前使用数据源为：{}", ObjectUtils.isEmpty(dataSourceEnum)?DataSourceEnum.MASTER:dataSourceEnum);
		return dataSourceEnum;
	}

}