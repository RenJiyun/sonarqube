package com.wlzq.dtasource.dynamic;


import com.wlzq.dtasource.dynamic.enums.DataSourceEnum;

/**
 * @author zhujt
 */
public class DynamicDataSourceContextHolder {

	/**
	 * 定义一个ThreadLocal变量，保存数据源类型（保证线程安全，多个线程之间互不影响）
	 */
	private static final ThreadLocal<DataSourceEnum> dataSourceContextHolder = new ThreadLocal<>();

	public static final DataSourceEnum defaultDataSource = DataSourceEnum.MASTER;
	
	static {
		setDefaultDataSource(); // 默认指定主库
	}
	
	public static void setDefaultDataSource() {
		dataSourceContextHolder.set(defaultDataSource);
	}

	public static void setDataSource(DataSourceEnum dataSourceEnum) {
		dataSourceContextHolder.set(dataSourceEnum);
	}

	public static DataSourceEnum getDataSource() {
		return dataSourceContextHolder.get();
	}
	public static void clear() {
		dataSourceContextHolder.remove();
	}
}