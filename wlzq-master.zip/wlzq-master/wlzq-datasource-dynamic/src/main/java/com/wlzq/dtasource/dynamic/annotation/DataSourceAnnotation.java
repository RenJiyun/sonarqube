package com.wlzq.dtasource.dynamic.annotation;



import com.wlzq.dtasource.dynamic.enums.DataSourceEnum;

import java.lang.annotation.*;

/**
 * 自定义数据源注解
 * @author zhujt
 */
@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface DataSourceAnnotation {
	
	DataSourceEnum value() default DataSourceEnum.MASTER;
	
}
