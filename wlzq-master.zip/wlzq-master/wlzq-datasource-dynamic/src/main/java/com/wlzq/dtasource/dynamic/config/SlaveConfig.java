package com.wlzq.dtasource.dynamic.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * 从库配置
 * @author zhujt
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.datasource.slave")
public class SlaveConfig {
	private String url;
	private String username;
	private String password;
	private String driverClassName;
	private Integer initialSize;
	private Integer minIdle;
	private Integer maxActive;
	private Integer maxWait;
	private Integer timeBetweenEvictionRunsMillis;
	private String validationQuery;
	private Boolean testWhileIdle;
	private Boolean testOnBorrow;
	private Boolean testOnReturn;
	private Boolean poolPreparedStatements;
	private Integer maxPoolPreparedStatementPerConnectionSize;
	private String filters;
	private Properties connectionProperties;
}