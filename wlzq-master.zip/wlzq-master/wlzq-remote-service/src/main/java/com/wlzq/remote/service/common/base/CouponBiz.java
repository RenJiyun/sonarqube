package com.wlzq.remote.service.common.base;

import java.util.List;
import java.util.Map;

import com.wlzq.common.model.base.CouponInfo;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;

/**
 * CouponBiz类
 * @author
 * @version 1.0
 */
public interface CouponBiz {

	/**
	 * 领取优惠券
	 * @param customerId
	 * @param code
	 * @return
	 */
	StatusObjDto<CouponInfo> receiveCoupon(String customerId,String userId,String code);

	/**
	 * 获取客户可用优惠券
	 * @param customerId
	 * @param type
	 * @param plate
	 * @param productCode
	 * @param productSpecification
	 * @return
	 */
	StatusObjDto<List<CouponInfo>> findAvailableCoupons(String customerId,Integer  type,Integer plate,String productCode,String productSpecification);

	/**
	 * 获取客户可用优惠券
	 * @param customerId
	 * @param type
	 * @param plate
	 * @param productCode
	 * @param productSpecification
	 * @param couponNeedSpecify 优惠券是否需要明确指定规格使用
	 * @return
	 */
	StatusObjDto<List<CouponInfo>> findAvailableCoupons(String customerId,Integer  type,Integer plate,String productCode,String productSpecification,Integer couponNeedSpecify);

	/**
	 *
	 * @param template
	 * @param customerId
	 * @param userId
	 * @return
	 */
	StatusObjDto<CouponInfo> receiveAvailableCoupon(String template,String customerId,String userId);

	/**
	 * 查询客户未使用用优惠券
	 * @param customerId
	 * @param plate
	 * @param productCode
	 * @param specification
	 * @return
	 */
	StatusObjDto<List<CouponInfo>> findNotUsedCoupons(String customerId,Integer plate,String productCode,String specification);

	/**
	 * 检查优惠券是否可用平台、产品和规格
	 * @param customerId
	 * @param code
	 * @param plate
	 * @param productCode
	 * @param specification
	 * @return
	 */
	StatusObjDto<CouponInfo> checkIsApplicable(String customerId,String code,Integer plate,String productCode,String specification);

	/**
	 * 使用优惠券
	 * @param customerId
	 * @param code
	 * @param plate
	 * @param productCode
	 * @param specification
	 * @return
	 */
	StatusObjDto<CouponInfo> useCoupon(String customerId,String code,Integer plate,String productCode,String specification);

	/**
	 * 使用优惠券
	 * @param customerId
	 * @param code
	 * @param plate
	 * @param productCode
	 * @param specification
	 * @param totalAmount 订单原始金额
	 * @return
	 */
	StatusObjDto<CouponInfo> useCoupon(String customerId,String code,Integer plate,String productCode,String specification,
									   Integer totalAmount);

	/**
	 *
	 * @param userId
	 * @param customerId
	 * @param code
	 * @param plate
	 * @param productCode
	 * @param specification
	 * @return
	 */
	StatusObjDto<CouponInfo> useCouponWithUserId(String userId, String customerId,String code, Integer plate, String productCode,
												 String specification);

	/**
	 *
	 * @param userId
	 * @param customerId
	 * @param code
	 * @param plate
	 * @param productCode
	 * @param specification
	 * @param totalAmount 订单原始金额
	 * @return
	 */
	StatusObjDto<CouponInfo> useCouponWithUserId(String userId, String customerId,String code, Integer plate, String productCode,
			String specification, Integer totalAmount);
	/**
	 * 退券
	 * @param customerId
	 * @param coupon
	 * @param reason
	 * @param deviceType
	 * @param clientIp
	 * @return
	 */
	StatusObjDto<CouponInfo> refundCoupon(String customerId,String  coupon,String reason);

	/**
	 * 查询优惠券（模板）信息
	 * @param template
	 * @param code
	 * @return
	 */
	StatusObjDto<CouponInfo> couponInfo(String template,String code);

	/**
	 * 查询优惠券（模板）信息
	 * @param template
	 * @param code
	 * @param totalAmount 订单原始金额
	 * @return
	 */
	StatusObjDto<CouponInfo> couponInfo(String template,String code, Integer totalAmount);

	/**
	 * 查询优惠券信息
	 * @param template
	 * @param code
	 * @return
	 */
	StatusObjDto<Map<String, Object>> couponEntityInfo(String code);

	/**
	 * 查找最近获取优惠券
	 * @param template
	 * @param code
	 * @param userId
	 * @param customerId
	 * @param recommendCode TODO
	 * @param status TODO
	 * @return
	 */
	StatusObjDto<Map<String, Object>> getLatelyCoupon(String template, String code, String userId,
			String customerId, String recommendCode, Integer status);

	/**
	 *
	 * @param redeemCode
	 * @param recommendCode
	 * @param time
	 * @return
	 */
	StatusDto delayCoupon(String redeemCode, String recommendCode, Long time);

}
