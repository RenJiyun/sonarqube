
package com.wlzq.remote.service.common.account;

import java.util.List;

import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;

/**
 *  PointBiz类
 * @author 
 * @version 1.0
 */
public interface PointBiz {	
	
	/**
	 * 添加积分
	 * @param userId
	 * @param point
	 * @param source 来源,1:猜涨跌
	 * @param flow  流向,0:减,1:增
	 * @param description 描述
	 * @param remark
	 * @return
	 */
	StatusDto addPoint(String userId,Long point,Integer source,Integer flow,String description,String remark);
	
	/**
	 * 查询总积分
	 * @param userId
	 * @param sources
	 * @return
	 */
	StatusObjDto<Long> getPoint(String userId,List<Integer> sources);
}
