package com.wlzq.remote.service.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:application.properties"}) 
@ConfigurationProperties(prefix="app")
public class AppConfig {

	public static final String ENV_TEST="test";
	public static final String ENV_PRODUCTION="production";
	public static final String MICRO_TYPE_SPRINGCLOUD="springcloud";
	public static final String MICRO_TYPE_DNS="dns";
	private String key;
	private String secret;
	private String env = "production";
	private String microType = "springcloud";
	private boolean saveRequest = false;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getSecret() {
		return secret;
	}
	public void setSecret(String secret) {
		this.secret = secret;
	}
	public String getEnv() {
		return env;
	}
	public void setEnv(String env) {
		this.env = env;
	}
	public String getMicroType() {
		return microType;
	}
	public void setMicroType(String microType) {
		this.microType = microType;
	}
	public boolean isSaveRequest() {
		return saveRequest;
	}
	public void setSaveRequest(boolean saveRequest) {
		this.saveRequest = saveRequest;
	}
	
}
