package com.wlzq.remote.service.common.base;

import com.wlzq.core.dto.StatusObjDto;

/**
 * ShortUrlBiz类
 * @author 
 * @version 1.0
 */
public interface ShortUrlBiz {	
	

	/**
	 * 短地址(新)
	 * @param url
	 * @return
	 */
	public StatusObjDto<String> shortenNew(String url);
	
	/**
	 * 还原原链接
	 * @param url
	 * @return
	 */
	public StatusObjDto<String> originalUrl(String url);
}
