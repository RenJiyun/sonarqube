package com.wlzq.remote.service.common.label.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author luohc
 * @date 2021/11/2 16:36
 */
@Data
@Accessors(chain = true)
public class TokenDto implements Serializable {
    private String token;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime t;
}
