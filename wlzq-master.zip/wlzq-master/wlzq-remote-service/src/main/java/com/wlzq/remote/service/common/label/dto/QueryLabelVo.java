package com.wlzq.remote.service.common.label.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author luohc
 * @date 2021/10/26 15:42
 */
@Data
@Accessors(chain = true)
public class QueryLabelVo implements Serializable {

    /** 账户id */
    private String accountId;
    /**  */
    private String label;


}
