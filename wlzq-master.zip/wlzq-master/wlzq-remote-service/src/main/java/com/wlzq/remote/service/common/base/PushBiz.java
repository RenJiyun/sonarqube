package com.wlzq.remote.service.common.base;

import com.wlzq.core.dto.StatusDto;
import com.wlzq.remote.service.common.base.dto.SmsSendDto;
import com.wlzq.remote.service.common.push.dto.SceneSendDto;

import java.util.List;

/**
 * PushBiz类
 * @author 
 * @version 1.0
 */
public interface PushBiz {	

	/**
	 *  推送消息
	 * @param templateCode 模板编码
	 * @param userId	用户id
	 * @param params 参数
	 * @return
	 */
	StatusDto push(String templateCode,String userId,List<Object> params);
	
	/**
	 * 发送短信
	 * @param templateCode
	 * @param mobile
	 * @param params
	 * @return
	 */
	@Deprecated
	StatusDto sendSms(String templateCode,String mobile,List<Object> params);

	/**
	 * 发送短信模板消息
	 */
	@Deprecated
	StatusDto sendSmsWithTmpl(String templateCode, String mobile, List<Object> params);

	/**
	 * 发送短信模板消息。支持发送，营销类或者生成类型的短信。
	 */
	StatusDto sendSmsWithTmpl(SmsSendDto smsSendDto);

	/**
	 * 发送短信
	 * @param mobile
	 * @param content
	 * @return
	 */
	StatusDto sendSms(String mobile,String content);
	
	/**
	 * 获取发送消息内容
	 * @param content
	 * @param params
	 * @return
	 */
	String getSendContent(String content,List<Object> params);


	/**
	 * 发送场景消息
	 * @param sendDto
	 * @return
	 */
	String sendSceneMessage(SceneSendDto sendDto);
}
