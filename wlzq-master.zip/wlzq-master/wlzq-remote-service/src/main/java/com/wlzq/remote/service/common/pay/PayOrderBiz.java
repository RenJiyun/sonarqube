package com.wlzq.remote.service.common.pay;

import com.wlzq.common.model.pay.PayOrderParam;
import com.wlzq.common.model.pay.PayOrderCreateResult;
import com.wlzq.core.dto.StatusObjDto;

/**
 * 订单接口
 * @author louie
 *
 */
public interface PayOrderBiz {

	/**
	 * 创建支付订单
	 * @param order
	 * @return 订单号
	 */
	public StatusObjDto<PayOrderCreateResult> createOrder(PayOrderParam order);
	
	/**
	 * 查询订单信息
	 * @param orderNo
	 * @param outTradeNo
	 * @return
	 */
	public PayOrderParam orderInfo(String orderNo,String outTradeNo);
}
