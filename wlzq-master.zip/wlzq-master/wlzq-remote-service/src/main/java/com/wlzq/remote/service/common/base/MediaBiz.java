package com.wlzq.remote.service.common.base;

import java.util.List;

import com.wlzq.common.model.base.MediaLibrary;
import com.wlzq.core.dto.StatusObjDto;

public interface MediaBiz {

	/**
	 *  推送消息
	 * @param templateCode 模板编码
	 * @param userId	用户id
	 * @param params 参数
	 * @return
	 */
	StatusObjDto<List<MediaLibrary>> findMediaByIds(String ids);
}
