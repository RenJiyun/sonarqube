package com.wlzq.remote.service.common.pay.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.wlzq.common.model.pay.PayAgreement;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.pay.PayAgreementBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

/**
 * 远程支付业务接口实现
 * @author louie
 *
 */
@Service
public class RemotePayAgreementBizImpl implements PayAgreementBiz {

	@Override
	public StatusObjDto<PayAgreement> createAgreement(PayAgreement agreement) {
		Map<String, Object> busparams = BeanUtils.beanToMap(agreement);
		ResultDto result =  RemoteUtils.call("pay.agreementcooperation.createagreement",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<PayAgreement>(false,result.getCode(),result.getMsg());
		}
		PayAgreement createResult = BeanUtils.mapToBean(result.getData(), PayAgreement.class);
		return new StatusObjDto<PayAgreement>(true,createResult,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<PayAgreement> unsignAgreement(String agreementNo) {
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("agreementNo", agreementNo);
		ResultDto result =  RemoteUtils.call("pay.agreementcooperation.unsignagreement",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<PayAgreement>(false,result.getCode(),result.getMsg());
		}
		PayAgreement createResult = BeanUtils.mapToBean(result.getData(), PayAgreement.class);
		return new StatusObjDto<PayAgreement>(true,createResult,StatusDto.SUCCESS,"");
	}
	
}
