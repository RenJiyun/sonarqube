
package com.wlzq.remote.service.common.account.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RegxUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.remote.service.common.account.BlacklistBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * BlacklistBiz实现类
 * @author 
 * @version 1.0
 */
@Service
public class RemoteBlacklistBizImpl  implements BlacklistBiz{

	@Override
	public StatusDto create(String userId, String mobile,Integer source, String remark) {
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("userId", userId);
    	busparams.put("mobile", mobile);
    	busparams.put("source", source);
    	busparams.put("remark", remark);
    	ResultDto result = RemoteUtils.call("account.blacklistcooperation.create",ApiServiceTypeEnum.COOPERATION, busparams,true);
		
    	boolean isOk = result.getCode().equals(StatusDto.SUCCESS);
		return new StatusDto(isOk,result.getCode(),result.getMsg());
	}

	@Override
	public StatusDto getByMobile(String mobile) {
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusDto(false,1,"手机号不能为空");
		}
		if(!RegxUtils.isMobile(mobile)) {
			return new StatusDto(false,1,"手机号无效");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("mobile", mobile);
    	ResultDto result = RemoteUtils.call("account.blacklistcooperation.getbymobile",ApiServiceTypeEnum.COOPERATION, busparams,true);
		
    	boolean isOk = result.getCode().equals(StatusDto.SUCCESS);
		return new StatusDto(isOk,result.getCode(),result.getMsg());
	}

	@Override
	public StatusDto getByUserId(String userId) {
		if(ObjectUtils.isEmptyOrNull(userId)) {
			return new StatusDto(false,1,"userId不能为空");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("userId", userId);
    	ResultDto result = RemoteUtils.call("account.blacklistcooperation.getbyuserid",ApiServiceTypeEnum.COOPERATION, busparams,true);
		
    	boolean isOk = result.getCode().equals(StatusDto.SUCCESS);
		return new StatusDto(isOk,result.getCode(),result.getMsg());
	}

}
