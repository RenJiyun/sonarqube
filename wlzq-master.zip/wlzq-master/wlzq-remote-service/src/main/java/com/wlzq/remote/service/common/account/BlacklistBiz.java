
package com.wlzq.remote.service.common.account;

import com.wlzq.core.dto.StatusDto;

/**
 *  BlacklistBiz类
 * @author 
 * @version 1.0
 */
public interface BlacklistBiz {	
	
	/**
	 * 创建黑名单
	 * @param userId
	 * @param mobile
	 * @param remark
	 * @return
	 */
	StatusDto create(String userId,String mobile,Integer source,String remark);
	
	/**
	 * 手机号查询黑名单
	 * @param mobile
	 * @return
	 */
	StatusDto getByMobile(String mobile);

	/**
	 * userId查询黑名单
	 * @param userId
	 * @return
	 */
	StatusDto getByUserId(String userId);
}
