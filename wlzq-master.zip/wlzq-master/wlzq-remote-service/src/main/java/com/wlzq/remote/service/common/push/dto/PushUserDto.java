package com.wlzq.remote.service.common.push.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Map;

/**
 * @author luohc
 * @date 2022/11/3 10:06
 */
@Data
@Accessors(chain = true)
public class PushUserDto {
    private String wxOpenid;

    private String mobile;

    private Map<String, Object> data;

}
