package com.wlzq.remote.service.common.label;

import com.wlzq.service.base.sys.RedisFacadeAbstract;

public class LabelRedis extends RedisFacadeAbstract {

	/**
	 * key: spring.application.name,
	 * value: token
	 * */
	public static final LabelRedis API_TOKEN = new LabelRedis("label.ths.api.token:",23*60*60);

	private String redisPrefix;
	private int timeoutSeconds;

	private LabelRedis(String redisPrefix) {
		this.redisPrefix = redisPrefix;
	}

	private LabelRedis(String redisPrefix, int timeoutSeconds) {
		this.redisPrefix = redisPrefix;
		this.timeoutSeconds = timeoutSeconds;
	}

	@Override
	protected String getRedisPrefix() {
		return redisPrefix;
	}
	
	@Override
	protected int getTimeoutSeconds() {
		return timeoutSeconds;
	}



}