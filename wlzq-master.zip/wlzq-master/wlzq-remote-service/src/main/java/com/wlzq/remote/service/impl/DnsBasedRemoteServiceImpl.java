package com.wlzq.remote.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.RequestParams;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.remote.service.RemoteService;
import com.wlzq.remote.service.config.DnsPlateformCompareConfig;
import com.wlzq.remote.service.config.DnsPlateformPortConfig;

import reactor.core.publisher.Mono;

@Component
public class DnsBasedRemoteServiceImpl implements RemoteService{

	private Logger logger = LoggerFactory.getLogger(DnsBasedRemoteServiceImpl.class);
	private WebClient webClient = WebClient.builder()
	        .defaultHeader(HttpHeaders.CONTENT_TYPE,"application/json;charset=UTF-8")
	        .build();
	
	@Override
	public ResultDto call(RequestParams param) {
		String plateForm = param.getService().substring(0,param.getService().indexOf("."));
		DnsPlateformCompareConfig plateformCompare = SpringApplicationContext.getBean(DnsPlateformCompareConfig.class);
		String finalPlate = plateformCompare.getPlateform(plateForm);
		plateForm = finalPlate == null?plateForm:finalPlate;
		DnsPlateformPortConfig plateForms = SpringApplicationContext.getBean(DnsPlateformPortConfig.class);
		String port = ObjectUtils.isEmptyOrNull(plateForms.getPort(plateForm))?"80":plateForms.getPort(plateForm);
		String url = "http://"+plateForm+":"+port+"/"+plateForm+"/call";
		try {
			Mono<ResultDto> result = webClient.post().uri(url).syncBody(BeanUtils.beanToMap(param)).retrieve().bodyToMono(ResultDto.class);
			return result.block();
		}catch(Exception ex) {
			logger.error("请求异常：" + url+","+ex.getMessage());
		}
		return new ResultDto(ResultDto.FAIL_COMMON,"网络异常");
	}

	@Override
	public String check(String plateForm) {
		DnsPlateformCompareConfig plateformCompare = SpringApplicationContext.getBean(DnsPlateformCompareConfig.class);
		String finalPlate = plateformCompare.getPlateform(plateForm);
		plateForm = finalPlate == null?plateForm:finalPlate;
		DnsPlateformPortConfig plateForms = SpringApplicationContext.getBean(DnsPlateformPortConfig.class);
		String port = ObjectUtils.isEmptyOrNull(plateForms.getPort(plateForm))?"80":plateForms.getPort(plateForm);
		String url = "http://"+plateForm+":"+port+"/"+plateForm+"/check";
		try {
			Map<String,Object> param = new HashMap<String,Object>();
			Mono<String> result = webClient.post().uri(url).syncBody(BeanUtils.beanToMap(param )).retrieve().bodyToMono(String.class);
			return result.block();
		}catch(Exception ex) {
			logger.error("请求异常：" + url+","+ex.getMessage());
		}
		return "error";
	}

}
