package com.wlzq.remote.service.common.push.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 场景推送对象
 * @author luohc
 * @date 2022/11/3 15:56
 */
@Data
@Accessors(chain = true)
public class SceneSendDto implements Serializable {
    private static final long serialVersionUID = 1L;

    private String sceneNo;
    private List<PushUserDto> users;
    /** 模板参数 */
    private Map<String, Object> templatePara;
    /** APP推送参数 */
    private AppParaDto appPara;

    /** 自定义流水号 */
    private String cid;
    /** 批次号 */
    private String batchCode;
    /** 批次名称 */
    private String batchName;
    /** 批次数量 */
    private Integer batchNum;
    /** 手机号。多个手机号英文逗号分割 */
    private String mobile;


    /** 可选，消息业务分类，（二级消息来源） */
    private String category ;
    /** 创建人 */
    private String owner ;
    /** 有效存活时间，单位为秒如果该值为空，则默认1天(1*86400) */
    private Integer liveTime;


}
