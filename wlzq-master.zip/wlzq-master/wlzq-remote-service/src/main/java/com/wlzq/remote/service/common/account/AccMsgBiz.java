package com.wlzq.remote.service.common.account;

import java.util.List;

import com.wlzq.common.model.account.AccMsg;
import com.wlzq.core.dto.StatusObjDto;

public interface AccMsgBiz {
	
	/**
	 * 查找消息
	 * @param userId
	 * @param customerId
	 * @param staffno
	 * @param buziType
	 * @param buziTag
	 * @param status
	 * @param page
	 * @return
	 */
	StatusObjDto<List<AccMsg>> msgList(String userId, String customerId, String staffno, Integer buziType,
			String buziTag, Integer status, Integer pageIndex, Integer pageSize);

	/**
	 * 读取消息
	 * @param serial
	 * @param userId
	 * @param customerId
	 * @param staffno
	 * @return
	 */
	StatusObjDto<AccMsg> readMsg(String serial, String userId, String customerId, String staffno);
	
	StatusObjDto<Integer> msgCount(String userId, String customerId, String staffno, Integer buziType,
			String buziTag, Integer status);
}
