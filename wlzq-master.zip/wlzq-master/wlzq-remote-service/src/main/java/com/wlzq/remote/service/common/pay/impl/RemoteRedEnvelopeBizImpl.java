package com.wlzq.remote.service.common.pay.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.model.pay.RedEnvelopeParam;
import com.wlzq.common.model.pay.RedEnvelopeCreateResult;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.pay.RedEnvelopeBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

/**
 * 远程红包业务接口实现
 * @author louie
 *
 */
@Service
public class RemoteRedEnvelopeBizImpl implements RedEnvelopeBiz {

	@Override
	public StatusObjDto<RedEnvelopeCreateResult> create(RedEnvelopeParam redEnvelope, boolean isNeedCheck) {
		Map<String, Object> busparams = BeanUtils.beanToMap(redEnvelope);
		Integer needCheck = isNeedCheck?1:0;
		busparams.put("isNeedCheck", needCheck);
		ResultDto result =  RemoteUtils.call("pay.redenvelopecooperation.createorder",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<RedEnvelopeCreateResult>(false,result.getCode(),result.getMsg());
		}
		RedEnvelopeCreateResult createResult = BeanUtils.mapToBean(result.getData(), RedEnvelopeCreateResult.class);
		return new StatusObjDto<RedEnvelopeCreateResult>(true,createResult,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusDto notify(String result) {
		// TODO Auto-generated method stub
		return null;
	} 
	
}
