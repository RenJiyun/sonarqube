/**
 * @author luohc
 * @date 2021/10/26 15:33
 */
package com.wlzq.remote.service.common.label;