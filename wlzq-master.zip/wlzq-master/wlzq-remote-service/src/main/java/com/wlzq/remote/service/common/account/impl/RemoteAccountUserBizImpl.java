
package com.wlzq.remote.service.common.account.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.constant.RegistSourceE;
import com.wlzq.common.constant.RegistTypeE;
import com.wlzq.common.constant.ThirdAccountTypeE;
import com.wlzq.common.model.account.AccUser;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RegxUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.account.AccountUserBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * 远程AccountUserBiz实现类
 * @author 
 * @version 1.0
 */
@Service
public class RemoteAccountUserBizImpl  implements AccountUserBiz{
	
	public StatusObjDto<String> createUser(String mobile,Integer isStaff,RegistTypeE regType,RegistSourceE regSource) {
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusObjDto<String>(false,201,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusObjDto<String>(false,202, "请输入正确的手机号"); 
		}
		if(ObjectUtils.isEmptyOrNull(regType)) {
			return new StatusObjDto<String>(false,203,"regType参数不能为空");
		}
		
		return  new StatusObjDto<String>(true,"userid",0,"");
	}

	public StatusObjDto<String> createUser(AccUser user) {
		if(ObjectUtils.isEmptyOrNull(user.getMobile())) {
			return new StatusObjDto<String>(false,201,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(user.getMobile())){
			return new StatusObjDto<String>(false,202, "请输入正确的手机号"); 
		}
		if(ObjectUtils.isEmptyOrNull(user.getRegType())) {
			return new StatusObjDto<String>(false,203,"regType参数不能为空");
		}
		Map<String, Object> busparams = BeanUtils.beanToMap(user);
		ResultDto result = RemoteUtils.call("account.usercooperation.createuser",ApiServiceTypeEnum.COOPERATION,busparams, true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return  new StatusObjDto<String>(false,result.getCode(),result.getMsg());
		}
		String userId = (String) result.getData().get("userId");
		return  new StatusObjDto<String>(true,userId,0,"");
	}
	
	public StatusObjDto<String> createThirdUser(String mobile, String thirdUid, ThirdAccountTypeE thirdType) {
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusObjDto<String>(false,204,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusObjDto<String>(false,205, "请输入正确的手机号"); 
		}
		if(ObjectUtils.isEmptyOrNull(thirdUid)) {
			return new StatusObjDto<String>(false,206,"thirdUid参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(thirdType)) {
			return new StatusObjDto<String>(false,207,"thirdType参数不能为空");
		}
		//创建用户
		RegistTypeE regType;
		RegistSourceE regSource;
		if(thirdType.equals(ThirdAccountTypeE.WECHAT)) {
			regType = RegistTypeE.AUTO_WECHAT;
			regSource = RegistSourceE.WECHAT;
		}else {
			return new StatusObjDto<String>(false,208,"未知的第三方账户类型");
		}
		StatusObjDto<String> createResult = createUser(mobile,0, regType, regSource);
		if(!createResult.isOk()) {
			return createResult;
		}
		return createResult;
	}
	
	public AccUser findByUserId(String userId) {
    	Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("userId", userId);
		AccUser user = RemoteUtils.callReturnEntity("account.usercooperation.findbyuserid",ApiServiceTypeEnum.COOPERATION,
				busparams, AccUser.class,true);
		return user;
	}

	public AccUser findByMobile(String mobile) {
    	Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("mobile", mobile);
		AccUser user =  RemoteUtils.callReturnEntity("account.usercooperation.findbymobile",ApiServiceTypeEnum.COOPERATION, 
				busparams, AccUser.class,true);
		return user;
	}

	@Override
	public AccUser findByOpenId(String openId) {
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("openId", openId);
		AccUser user =  RemoteUtils.callReturnEntity("account.usercooperation.findbyopenid",ApiServiceTypeEnum.COOPERATION,
				busparams, AccUser.class,true);
		return user;
	}

	public AccUser findByShareCode(String shareCode) {
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("shareCode", shareCode);
		AccUser user =  RemoteUtils.callReturnEntity("account.usercooperation.findbysharecode",ApiServiceTypeEnum.COOPERATION, 
				busparams, AccUser.class,true);
		return user;
	}

	@Override
	public StatusObjDto<Integer> wechatSubscribestatus(String openId) {
		// TODO Auto-generated method stub
		return null;
	}

}
