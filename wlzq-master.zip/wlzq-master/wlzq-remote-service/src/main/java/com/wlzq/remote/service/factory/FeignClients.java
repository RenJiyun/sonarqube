package com.wlzq.remote.service.factory;

import java.util.HashMap;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClientsConfiguration;
import org.springframework.context.annotation.Import;
import org.springframework.stereotype.Component;

import com.wlzq.remote.service.RemoteService;
import com.wlzq.remote.service.impl.RemoteTemplateService;

import feign.Client;
import feign.Contract;
import feign.Feign;
import feign.Retryer;
import feign.codec.Decoder;
import feign.codec.Encoder;

@Component
@Import(FeignClientsConfiguration.class)
public class FeignClients {
	private Map<String,RemoteService> clients = new HashMap<String,RemoteService>();
    private Feign.Builder builder;
	public FeignClients(Decoder decoder, Encoder encoder, Client client, Contract contract) {
	    this.builder = Feign.builder()
                            .client(client)
                            .encoder(encoder)
                            .decoder(decoder)
                            .contract(contract)
                            .retryer(Retryer.NEVER_RETRY);
	}   
	
	public  RemoteService target(String plate) {
		if(clients.containsKey(plate)) {
			return clients.get(plate);
		}
		RemoteTemplateService remoteService = this.builder.target(RemoteTemplateService.class, "http://" + plate+"/"+plate);
		clients.put(plate, remoteService);
		return remoteService;
	}
}
