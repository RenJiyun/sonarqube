package com.wlzq.remote.service.common.base.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.wlzq.common.model.base.AgreementBrief;
import com.wlzq.common.model.base.AgreementSignParam;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.base.AgreementBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

/**
 * AgreementBiz实现类
 * 
 * @author
 * @version 1.0
 */
@Service
public class RemoteAgreementBizImpl implements AgreementBiz {
	
	@Override
	public StatusObjDto<Map> findAgreement(String no, String version, AgreementSignParam params) {
		if(ObjectUtils.isEmptyOrNull(no)) {
			return new StatusObjDto<Map>(false,StatusDto.FAIL_COMMON,"no参数不能为空");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("no", no);
		busparams.put("version",version);
		busparams.put("params",params);
		
		ResultDto result = RemoteUtils.call("base.agreementcooperation.agreementinfo",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<Map>(false,result.getCode(),result.getMsg());
		}
		return new StatusObjDto<Map>(true,result.getData(),StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<String> sign(AgreementSignParam sign) {
		if(sign == null) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("签约信息为空");
		}
		if(ObjectUtils.isEmptyOrNull(sign.getType())) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("type");
		}
		if(ObjectUtils.isEmptyOrNull(sign.getAgreenmentNos())) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("agreenmentNo");
		}
		if(ObjectUtils.isEmptyOrNull(sign.getCustomerId())) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}
		if(ObjectUtils.isEmptyOrNull(sign.getFundAccount())) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("fundAccount");
		}
//		if(ObjectUtils.isEmptyOrNull(sign.getProductCode())) {
//			throw BizException.COMMON_PARAMS_NOT_NULL.format("productCode");
//		}
		
		Map<String, Object> busparams = BeanUtils.beanToMap(sign);
		
		ResultDto result = RemoteUtils.call("base.agreementcooperation.sign",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<String>(false,result.getCode(),result.getMsg());
		}
		
		return new StatusObjDto<String>(true,(String)result.getData().get("serialNo"),StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<List<AgreementBrief>> findAgreementBySerialNo(String serialNo) {
		if(ObjectUtils.isEmptyOrNull(serialNo)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("serialNo");
		}
		
		Map<String, Object> busparams = Maps.newConcurrentMap();
		busparams.put("serialNo", serialNo);
		
		ResultDto result = RemoteUtils.call("base.agreementcooperation.signedagreements",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<List<AgreementBrief>>(false,result.getCode(),result.getMsg());
		}
		List<Map> agreements = (List<Map>) result.getData().get("info");
		List<AgreementBrief> signedAgreements = BeanUtils.toBeanList(agreements, AgreementBrief.class);
		return new StatusObjDto<List<AgreementBrief>>(true,signedAgreements,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<Integer> hasSign(String customerId, String no) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}
		if(ObjectUtils.isEmptyOrNull(no)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("no");
		}
		
		Map<String, Object> busparams = Maps.newConcurrentMap();
		busparams.put("customerId", customerId);
		busparams.put("agreenmentNo", no);
		
		ResultDto result = RemoteUtils.call("base.agreementcooperation.hassign",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<Integer>(false,result.getCode(),result.getMsg());
		}
		Integer status = (Integer) result.getData().get("status");
		return new StatusObjDto<Integer>(true,status,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<Map> findAgreements(List<String> nos) {
		if(nos == null || nos.size() == 0) {
			return new StatusObjDto<Map>(false,StatusDto.FAIL_COMMON,"nos参数不能为空");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("nos", nos);
		ResultDto result = RemoteUtils.call("base.agreementcooperation.findagreements",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<Map>(false,result.getCode(),result.getMsg());
		}
		return new StatusObjDto<Map>(true,result.getData(),StatusDto.SUCCESS,"");
	}

	
}
