package com.wlzq.remote.service.common.push.executor;

import com.wlzq.core.dto.StatusDto;

/**
 * 推送Executor
 * @author luohc
 * @date 2021/6/21 14:53
 */
public interface IPushExecutor {
    /**
     * 带上参数
     */
    StatusDto run(String jsonData);
}
