package com.wlzq.remote.service.common.base.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.wlzq.common.model.base.CouponInfo;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.base.CouponBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

/**
 * CouponBiz实现类
 *
 * @author
 * @version 1.0
 */
@Service
public class RemoteCouponBizImpl implements CouponBiz {

	@Override
	public StatusObjDto<CouponInfo> receiveCoupon(String customerId,String userId, String code) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}
		if(ObjectUtils.isEmptyOrNull(code)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("code");
		}

		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("customerId", customerId);
		busparams.put("userId", userId);
		busparams.put("code", code);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.receivecoupon",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}
		CouponInfo coupon = BeanUtils.mapToBean(result.getData(), CouponInfo.class);

		return new StatusObjDto<CouponInfo>(true,coupon,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> receiveAvailableCoupon(String template, String customerId,String userId) {
		if(ObjectUtils.isEmptyOrNull(template)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("template");
		}
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}

		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("template", template);
		busparams.put("userId", userId);
		busparams.put("customerId", customerId);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.receiveavailablecoupon",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}
		CouponInfo coupon = BeanUtils.mapToBean(result.getData(), CouponInfo.class);

		return new StatusObjDto<CouponInfo>(true,coupon,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<List<CouponInfo>> findNotUsedCoupons(String customerId,Integer plate,String productCode,String specification) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}

		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("customerId", customerId);
		busparams.put("plate", plate);
		busparams.put("productCode", productCode);
		busparams.put("specification", specification);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.findnotusedcoupons",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<List<CouponInfo>>(false,result.getCode(),result.getMsg());
		}
		List<Map<String,Object>> couponsMap = (List<Map<String,Object>>) result.getData().get("info");
		List<CouponInfo> coupons = BeanUtils.toBeanList(couponsMap, CouponInfo.class);

		return new StatusObjDto<List<CouponInfo>>(true,coupons,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> checkIsApplicable(String customerId,String code, Integer plate, String productCode,
			String specification) {
		if(ObjectUtils.isEmptyOrNull(code)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("code");
		}

		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("customerId", customerId);
		busparams.put("code", code);
		busparams.put("plate", plate);
		busparams.put("productCode", productCode);
		busparams.put("specification", specification);
		String method = ObjectUtils.isNotEmptyOrNull(customerId)?"base.couponcooperation.checkisapplicable":"base.couponcooperation.checkisapplicablebycode";
		ResultDto result =  RemoteUtils.call(method,ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}
		CouponInfo coupon = BeanUtils.mapToBean(result.getData(), CouponInfo.class);

		return new StatusObjDto<CouponInfo>(true,coupon,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> useCoupon(String customerId,String code, Integer plate, String productCode,
			String specification, Integer totalAmount) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}
		if(ObjectUtils.isEmptyOrNull(code)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("code");
		}

		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("customerId", customerId);
		busparams.put("code", code);
		busparams.put("plate", plate);
		busparams.put("productCode", productCode);
		busparams.put("specification", specification);
		/*订单原始金额*/
		busparams.put("totalAmount", totalAmount);

		ResultDto result =  RemoteUtils.call("base.couponcooperation.usecoupon",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}
		CouponInfo coupon = BeanUtils.mapToBean(result.getData(), CouponInfo.class);

		return new StatusObjDto<CouponInfo>(true,coupon,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> useCoupon(String customerId,String code, Integer plate, String productCode, String specification) {

		return useCoupon(customerId, code, plate, productCode, specification, null);
	}

	@Override
	public StatusObjDto<CouponInfo> useCouponWithUserId(String userId, String customerId,String code, Integer plate, String productCode,
			String specification, Integer totalAmount) {
		if(ObjectUtils.isEmptyOrNull(userId) && ObjectUtils.isNotEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId && userId");
		}
		if(ObjectUtils.isEmptyOrNull(code)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("code");
		}

		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("customerId", customerId);
		busparams.put("userId", userId);
		busparams.put("code", code);
		busparams.put("plate", plate);
		busparams.put("productCode", productCode);
		busparams.put("specification", specification);
		/*订单原始金额*/
		busparams.put("totalAmount", totalAmount);

		ResultDto result =  RemoteUtils.call("base.couponcooperation.usecoupon",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}
		CouponInfo coupon = BeanUtils.mapToBean(result.getData(), CouponInfo.class);

		return new StatusObjDto<CouponInfo>(true,coupon,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> useCouponWithUserId(String userId, String customerId,String code, Integer plate, String productCode,
														String specification) {
		return useCouponWithUserId(userId, customerId, code, plate, productCode, specification, null);
	}

	@Override
	public StatusObjDto<List<CouponInfo>> findAvailableCoupons(String customerId, Integer type, Integer plate,
			String productCode, String productSpecification) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}

		Map<String, Object> busParams = Maps.newHashMap();
		busParams.put("customerId", customerId);
		busParams.put("type", type);
		busParams.put("plate", plate);
		busParams.put("productCode", productCode);
		busParams.put("specification", productSpecification);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.findavailablecoupons",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<List<CouponInfo>>(false,result.getCode(),result.getMsg());
		}

		List<Map<String,Object>> couponsMap = (List<Map<String,Object>>) result.getData().get("info");
		List<CouponInfo> coupons = BeanUtils.toBeanList(couponsMap, CouponInfo.class);
		return new  StatusObjDto<List<CouponInfo>>(true,coupons,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<List<CouponInfo>> findAvailableCoupons(String customerId, Integer type, Integer plate,
			String productCode, String productSpecification, Integer couponNeedSpecify) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}

		Map<String, Object> busParams = Maps.newHashMap();
		busParams.put("customerId", customerId);
		busParams.put("type", type);
		busParams.put("plate", plate);
		busParams.put("productCode", productCode);
		busParams.put("specification", productSpecification);
		busParams.put("couponNeedSpecify", couponNeedSpecify);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.findavailablecoupons",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<List<CouponInfo>>(false,result.getCode(),result.getMsg());
		}

		List<Map<String,Object>> couponsMap = (List<Map<String,Object>>) result.getData().get("info");
		List<CouponInfo> coupons = BeanUtils.toBeanList(couponsMap, CouponInfo.class);
		return new  StatusObjDto<List<CouponInfo>>(true,coupons,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> refundCoupon(String customerId, String coupon, String reason) {
		if(ObjectUtils.isEmptyOrNull(coupon)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("coupon");
		}
		Map<String, Object> busParams = Maps.newHashMap();
		/*busParams.put("customerId", customerId);*/
		busParams.put("code", coupon);
		busParams.put("reason", reason);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.refundcoupon",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}

		Map<String,Object> data = result.getData();
		CouponInfo couponInfo = BeanUtils.mapToBean(data, CouponInfo.class);
		return new  StatusObjDto<CouponInfo>(true,couponInfo,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> couponInfo(String template,String code, Integer totalAmount) {
		if(ObjectUtils.isEmptyOrNull(template) && ObjectUtils.isEmptyOrNull(code)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("template或code不能为空");
		}
		Map<String, Object> busParams = Maps.newHashMap();
		busParams.put("template", template);
		busParams.put("code", code);
		/*订单原始金额*/
		busParams.put("totalAmount", totalAmount);

		ResultDto result =  RemoteUtils.call("base.couponcooperation.couponinfo",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<CouponInfo>(false,result.getCode(),result.getMsg());
		}

		Map<String,Object> data = result.getData();
		CouponInfo couponInfo = BeanUtils.mapToBean(data, CouponInfo.class);
		return new  StatusObjDto<CouponInfo>(true,couponInfo,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<CouponInfo> couponInfo(String template,String code) {
		return couponInfo(template, code, null);
	}

	@Override
	public StatusObjDto<Map<String, Object>> couponEntityInfo(String code) {
		if(ObjectUtils.isEmptyOrNull(code)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("code不能为空");
		}
		Map<String, Object> busParams = Maps.newHashMap();
		busParams.put("code", code);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.findcouponbycode",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<Map<String, Object>>(false,result.getCode(),result.getMsg());
		}
		return new  StatusObjDto<Map<String, Object>>(true,result.getData(),StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<Map<String, Object>> getLatelyCoupon(String template, String code, String userId,
			String customerId, String recommendCode, Integer status) {
		if(ObjectUtils.isEmptyOrNull(code) && ObjectUtils.isEmptyOrNull(template)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("code和template不能同时为空");
		}
		if(ObjectUtils.isEmptyOrNull(userId) && ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("userId和customerId不能同时为空");
		}
		Map<String, Object> busParams = Maps.newHashMap();
		busParams.put("template", template);
		busParams.put("code", code);
		busParams.put("userId", userId);
		busParams.put("recommendCode", recommendCode);
		busParams.put("status", status);
		busParams.put("customerId", customerId);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.getlatelycoupon",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<Map<String, Object>>(false,result.getCode(),result.getMsg());
		}
		return new  StatusObjDto<Map<String, Object>>(true,result.getData(),StatusDto.SUCCESS,"");
	}

	@Override
	public StatusDto delayCoupon(String redeemCode, String recommendCode, Long time) {
		if(ObjectUtils.isEmptyOrNull(redeemCode)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("redeemCode");
		}
		if(ObjectUtils.isEmptyOrNull(recommendCode)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("recommendCode");
		}
		if(ObjectUtils.isEmptyOrNull(time)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("time");
		}
		Map<String, Object> busParams = Maps.newHashMap();
		busParams.put("code", redeemCode);
		busParams.put("recommendCode", recommendCode);
		busParams.put("sendTime", time);
		ResultDto result =  RemoteUtils.call("base.couponcooperation.delaycoupon",ApiServiceTypeEnum.COOPERATION,busParams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new  StatusDto(false, result.getCode(),result.getMsg());
		}
		return new  StatusDto(true, result.getCode(),result.getMsg());
	}


}
