
package com.wlzq.remote.service.common.account.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.wlzq.common.model.account.Staff;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.account.PointBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * PointBiz实现类
 * @author 
 * @version 1.0
 */
@Service
public class RemotePointBizImpl  implements PointBiz{

	@Override
	public StatusDto addPoint(String userId,Long point,Integer source,Integer flow,String description,String remark) {
		if(ObjectUtils.isEmptyOrNull(userId)) {
			return new StatusDto(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"userId参数不能为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(point)) {
			return new StatusDto(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"point参数不能为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(source)) {
			return new StatusDto(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"source参数不能为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(flow)) {
			return new StatusDto(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"flow参数不能为空"); 
		}
		if(flow < 0 || flow > 1) {
			return new StatusDto(false,BizException.COMMON_PARAMS_IS_ILLICIT.getCode(),"flow参数无效"); 
		}
		if(ObjectUtils.isEmptyOrNull(description)) {
			return new StatusDto(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"description参数不能为空"); 
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("userId", userId);
    	busparams.put("point", point);
    	busparams.put("source", source);
    	busparams.put("flow", flow);
    	busparams.put("description", description);
    	busparams.put("remark", remark);
    	ResultDto result = RemoteUtils.call("account.pointcooperation.addpoint",ApiServiceTypeEnum.COOPERATION, busparams,true);
		boolean isSuc = result.getCode().equals(ResultDto.SUCCESS)?true:false;

		return new StatusDto(isSuc,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<Long> getPoint(String userId, List<Integer> sources) {
		if(ObjectUtils.isEmptyOrNull(userId)) {
			return new StatusObjDto<Long>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"userId参数不能为空"); 
		}
		if(sources == null) {
			sources = Lists.newArrayList(); 
		}
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("userId", userId);
    	busparams.put("sources", sources);
    	ResultDto result = RemoteUtils.call("account.pointcooperation.point",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<Long>(false,result.getCode(),result.getMsg());
		}

		Long point = Long.valueOf(result.getData().get("point").toString());
		return new StatusObjDto<Long>(true,point,StatusDto.SUCCESS,"");
	}
}
