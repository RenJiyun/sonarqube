package com.wlzq.remote.service.common.pay;

import com.wlzq.common.model.pay.RedEnvelopeParam;
import com.wlzq.common.model.pay.RedEnvelopeCreateResult;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;

/**
 * 微信红包业务接口
 * @author louie
 *
 */
public interface RedEnvelopeBiz {

	/**
	 * 创建红包
	 * @param redEnvelope
	 * @return
	 */
	public StatusObjDto<RedEnvelopeCreateResult> create(RedEnvelopeParam redEnvelope,boolean isNeedCheck);
	
	/**
	 * 红包回调处理
	 * @param result 红包回调加密信息
	 * @return
	 */
	public StatusDto notify(String result);
}
