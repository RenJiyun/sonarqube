package com.wlzq.remote.service.common.base;

import java.util.List;
import java.util.Map;

import com.wlzq.common.model.base.AgreementBrief;
import com.wlzq.common.model.base.AgreementSignParam;
import com.wlzq.core.dto.StatusObjDto;

/**
 * AgreementBiz类
 * @author 
 * @version 1.0
 */
public interface AgreementBiz {	
	
	/**
	 * 查询协议
	 * @param no
	 * @param version
	 * @param params
	 * @return
	 */
	StatusObjDto<Map> findAgreement(String no,String version,AgreementSignParam params);

	/**
	 * 查询协议
	 * @param nos
	 * @return
	 */
	StatusObjDto<Map> findAgreements(List<String> nos);
	/**
	 * 协议签约
	 * @param sign
	 * @return
	 */
	StatusObjDto<String> sign(AgreementSignParam sign);
	
	/**
	 * 根据签署流水号查询协议
	 * @param serialNo
	 * @return
	 */
	StatusObjDto<List<AgreementBrief>> findAgreementBySerialNo(String serialNo);
	
	/**
	 * 查询是否签署协议
	 * @param customerId
	 * @param no
	 * @return
	 */
	StatusObjDto<Integer> hasSign(String customerId,String  no);
}
