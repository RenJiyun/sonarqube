package com.wlzq.remote.service.common.account;

import java.util.Date;

import com.wlzq.common.model.account.WCustomer;
import com.wlzq.core.dto.StatusObjDto;

/**
 * PersonBiz 类
 * @author 
 * @version 1.0
 */
public interface CustomerBiz {	

	/**
	 * 更新风险等级信息
	 * @param customerId
	 * @param riskLevel
	 * @param riskLevelTxt
	 * @return
	 */
	StatusObjDto<Integer> updateRiskLevel(String customerId,Integer riskLevel,String riskLevelTxt);
	
	/**
	 * 更新实名用户风险等级信息
	 * @param customerId
	 * @param riskLevel
	 * @param riskLevelTxt
	 * @param riskBeginDate
	 * @param riskEndDate
	 * @return
	 */
	StatusObjDto<Integer> updateUserRiskLevel(String userId,Integer riskLevel,String riskLevelTxt,Date riskBeginDate,Date riskEndDate);
	
	/**
	 * 根据客户号查询客户
	 * @param customerId
	 * @return
	 */
	StatusObjDto<WCustomer> findByCustomerId(String customerId);

	/**
	 * 客户信息
	 * @param customerId
	 * @param fundAccount
	 * @return
	 */
	WCustomer clientInfo(String customerId,String fundAccount);
}
