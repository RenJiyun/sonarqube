package com.wlzq.remote.service.common.account;

import com.wlzq.common.model.account.Staff;
import com.wlzq.core.dto.StatusObjDto;

/**
 * PersonBiz 类
 * @author 
 * @version 1.0
 */
public interface StaffBiz {	
	/**
	 * 手机号查询员工信息
	 * @param mobile
	 * @return
	 */
	StatusObjDto<Staff> infoByMobile(String mobile);
	
	/**
	 * 分享码查询员工信息
	 * @param shareCode
	 * @return
	 */
	StatusObjDto<Staff> infoByShareCode(String shareCode);
}
