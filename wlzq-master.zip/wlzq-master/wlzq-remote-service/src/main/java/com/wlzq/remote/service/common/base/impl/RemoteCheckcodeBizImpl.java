
package com.wlzq.remote.service.common.base.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.constant.CheckcodeTypeE;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RegxUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.remote.service.common.base.CheckcodeBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * CheckcodeBiz实现类
 * @author 
 * @version 1.0
 */
@Service("remoteCheckcodeBiz")
public class RemoteCheckcodeBizImpl implements CheckcodeBiz{
	
	public StatusDto  sendCheckcode(String templateCode,CheckcodeTypeE type,String mobile,String deviceId) {
		if(ObjectUtils.isEmptyOrNull(templateCode)) {
			return new StatusDto(false,201,"templateCode参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(type)){
			return new StatusDto(false,202, "type类型为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusDto(false,203,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusDto(false,204, "请输入正确的手机号"); 
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("mobile", mobile);
		busparams.put("templateCode",templateCode);
		busparams.put("type",type.getValue());
		busparams.put("deviceId","");
		
		ResultDto result = RemoteUtils.call("base.checkcodecooperation.sendcheckcode",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusDto(false,result.getCode(),result.getMsg());
		}
		return new StatusDto(true,"");
	}

	public StatusDto verifyCheckcode(CheckcodeTypeE type, String mobile, String checkcode, String deviceId) {
		
		if(ObjectUtils.isEmptyOrNull(type)){
			return new StatusDto(false, "type类型为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusDto(false,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusDto(false, "请输入正确的手机号"); 
		}
		if(ObjectUtils.isEmptyOrNull(checkcode)) {
			return new StatusDto(false,"checkcode参数不能为空");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("mobile", mobile);
		busparams.put("checkcode",checkcode);
		busparams.put("type",type.getValue());
		busparams.put("deviceId","");
		
		ResultDto result = RemoteUtils.call("base.checkcodecooperation.verifycheckcode",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusDto(false,result.getCode(),result.getMsg());
		}
		return new StatusDto(true,"");
	}

	@Override
	public StatusDto verityImageCheckcode(CheckcodeTypeE type, String wlzqstatId, String imageCheckcode,
			String deviceId) {
		if(ObjectUtils.isEmptyOrNull(type)){
			return new StatusDto(false, "type类型为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(wlzqstatId)) {
			return new StatusDto(false,"wlzqstatId参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(imageCheckcode)){
			return new StatusDto(false, "请输入图片验证码"); 
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("type", type.getValue());
		busparams.put("checkCode",imageCheckcode);
		busparams.put("wlzqstatId",wlzqstatId);
		busparams.put("deviceId","");
		
		ResultDto result = RemoteUtils.call("base.imagecooperation.verifycheckcode",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusDto(false,result.getCode(),result.getMsg());
		}
		return new StatusDto(true,"");
	}

}
