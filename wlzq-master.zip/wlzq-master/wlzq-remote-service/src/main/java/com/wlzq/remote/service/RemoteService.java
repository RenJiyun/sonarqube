package com.wlzq.remote.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.wlzq.core.RequestParams;
import com.wlzq.core.dto.ResultDto;


public interface RemoteService {
    ResultDto call(@RequestBody RequestParams param);
    String check(String plate);
}
