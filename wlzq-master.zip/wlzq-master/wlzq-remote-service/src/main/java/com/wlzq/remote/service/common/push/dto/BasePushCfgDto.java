package com.wlzq.remote.service.common.push.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author luohc
 * @date 2021/6/17 17:13
 */
@Data
public class BasePushCfgDto implements Serializable {

    private String msgThemeCode;

    /** 获取完数据，是否立即发送。1是0否 */
    private Integer sendNowFlag;

    private String taskClassName;

    private String findDataInterface;
    /**
     * 参考push_task.task_name 类似 聚利宝28天期新客(28XJLB)新客理财开售提醒任务
     */
    private String taskName;

}
