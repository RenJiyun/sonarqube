package com.wlzq.remote.service.common.account.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.model.account.WCustomer;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.account.CustomerBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * 远程StaffBiz实现类
 * @author 
 * @version 1.0
 */
@Service
public class RemoteCustomerBizImpl  implements CustomerBiz{

	public StatusObjDto<Integer> updateRiskLevel(String customerId,Integer riskLevel,String riskLevelTxt) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			return new StatusObjDto<Integer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"customerId参数不能为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(riskLevel)) {
			return new StatusObjDto<Integer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"riskLevel参数不能为空");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("customerId", customerId);
    	busparams.put("riskLevel", riskLevel);
    	busparams.put("riskLevelTxt", riskLevelTxt);
    	ResultDto result = RemoteUtils.call("account.customercooperation.updaterisklevel",ApiServiceTypeEnum.COOPERATION, busparams,false);
		int count = (int) result.getData().get("total");
		return new StatusObjDto<Integer>(true, count, 0, ""); 
	}

	@Override
	public StatusObjDto<Integer> updateUserRiskLevel(String userId, Integer riskLevel, String riskLevelTxt,Date riskBeginDate,Date riskEndDate) {
		if(ObjectUtils.isEmptyOrNull(userId)) {
			return new StatusObjDto<Integer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"userId参数不能为空"); 
		}
		if(ObjectUtils.isEmptyOrNull(riskLevel)) {
			return new StatusObjDto<Integer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"riskLevel参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(riskBeginDate)) {
			return new StatusObjDto<Integer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"riskBeginDate参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(riskEndDate)) {
			return new StatusObjDto<Integer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"riskEndDate参数不能为空");
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("userId", userId);
    	busparams.put("riskLevel", riskLevel);
    	busparams.put("riskLevelTxt", riskLevelTxt);
    	busparams.put("riskBeginDate", riskBeginDate.getTime());
    	busparams.put("riskEndDate", riskEndDate.getTime());
    	ResultDto result = RemoteUtils.call("account.fortunecooperation.updateuserrisklevel",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!ResultDto.SUCCESS.equals(result.getCode())){
			return new StatusObjDto<Integer>(false, result.getCode(),result.getMsg());
		}
    	int count = (int) result.getData().get("total");
		return new StatusObjDto<Integer>(true, count, 0, "");
	}
	
	@Override
	public StatusObjDto<WCustomer> findByCustomerId(String customerId) {
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			return new StatusObjDto<WCustomer>(false,BizException.COMMON_PARAMS_NOT_NULL.getCode(),"customerId参数不能为空"); 
		}
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("customerId", customerId);
    	ResultDto result = RemoteUtils.call("account.customercooperation.findcustomerbyid",ApiServiceTypeEnum.COOPERATION, busparams,true);
    	if (!StatusDto.SUCCESS.equals(result.getCode())) {
			return new StatusObjDto<>(false, result.getCode(), result.getMsg());
		}
    	WCustomer customer = BeanUtils.mapToBean(result.getData(), WCustomer.class);
		return new StatusObjDto<WCustomer>(true, customer, 0, ""); 
	}

	public WCustomer clientInfo(String customerId,String fundAccount) {
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("customerId", customerId);
    	busparams.put("fundAccount", fundAccount);
    	WCustomer customer = RemoteUtils.callReturnEntity("account.customercooperation.clientinfo",ApiServiceTypeEnum.COOPERATION, busparams,WCustomer.class,true);
		return customer; 
	}

}
