package com.wlzq.remote.service.common.push.dto;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * @author luohc
 * @date 2022/11/3 16:08
 */
@Data
@Accessors(chain = true)
public class WxParaDto {
    private String value;
    /***
     * 默认黑色
     */
    private String color = "#000000";
}
