package com.wlzq.remote.service.common.pay.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.model.pay.PayOrderParam;
import com.google.common.collect.Maps;
import com.wlzq.common.model.pay.PayOrderCreateResult;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.pay.PayOrderBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

/**
 * 远程支付业务接口实现
 * @author louie
 *
 */
@Service
public class RemotePayOrderBizImpl implements PayOrderBiz {

	@Override
	public StatusObjDto<PayOrderCreateResult> createOrder(PayOrderParam order) {
		Map<String, Object> busparams = BeanUtils.beanToMap(order);
		ResultDto result =  RemoteUtils.call("pay.ordercooperation.createorder",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<PayOrderCreateResult>(false,result.getCode(),result.getMsg());
		}
		PayOrderCreateResult createResult = BeanUtils.mapToBean(result.getData(), PayOrderCreateResult.class);
		return new StatusObjDto<PayOrderCreateResult>(true,createResult,StatusDto.SUCCESS,"");
	}

	@Override
	public PayOrderParam orderInfo(String orderNo,String outTradeNo) {
		if(ObjectUtils.isEmptyOrNull(orderNo) && ObjectUtils.isEmptyOrNull(outTradeNo)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("orderNo与outTradeNo参数都不能为空");
		}
		
		Map<String, Object> busparams = Maps.newHashMap();
		if(ObjectUtils.isNotEmptyOrNull(orderNo)) {
			busparams.put("orderNo", orderNo);
		}
		if(ObjectUtils.isNotEmptyOrNull(outTradeNo)) {
			busparams.put("outTradeNo", outTradeNo);
		}
		
		PayOrderParam payOrder =  RemoteUtils.callReturnEntity("pay.ordercooperation.orderinfo",ApiServiceTypeEnum.COOPERATION,
				busparams,PayOrderParam.class,true);
		return payOrder;
	} 
	
}
