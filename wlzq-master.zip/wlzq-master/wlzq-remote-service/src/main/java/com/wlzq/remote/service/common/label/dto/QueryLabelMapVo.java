package com.wlzq.remote.service.common.label.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author luohc
 * @date 2021/10/26 15:42
 */
@Data
@Accessors(chain = true)
public class QueryLabelMapVo implements Serializable {

    /** 账户id */
    private String accountId;
    /** 可支持的参数：everyDay - 每日、everyWeek - 每周、everyMonth - 每月、everyYear - 每年 */
    private String apiType;
    /** 格式 20200109 */
    private String pDate;


}
