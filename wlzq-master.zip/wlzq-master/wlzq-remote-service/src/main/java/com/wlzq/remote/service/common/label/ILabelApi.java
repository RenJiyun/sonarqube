package com.wlzq.remote.service.common.label;

import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.label.dto.QueryLabelDto;
import com.wlzq.remote.service.common.label.dto.QueryLabelVo;

import java.util.Map;

/**
 * @author luohc
 * @date 2021/10/26 15:34
 */
public interface ILabelApi {

    default void init(){};

    StatusObjDto<String> generateToken();

    /**
     * 查询单个标签
     * @param queryLabelVo
     * @return
     */
    StatusObjDto<QueryLabelDto> queryLabel(QueryLabelVo queryLabelVo);

    /**
     * 查询标签列表
     * @param accountId
     * @return
     */
    StatusObjDto<Map<String,Object>> queryLabelList(String accountId);
    
    StatusObjDto<String> generateToken(Integer accountType);
    
    /**
     * 查询历史标签列表
     * @param accountType 1：手机号 2：客户号
     * @param accountId
     * @param apiType	everyDay - 每日、everyWeek - 每周、everyMonth - 每月、everyYear - 每年。
     * @param dateString  20200109
     * @return
     */
    StatusObjDto<Map<String,Object>> queryHistoryLabelList(Integer accountType, String accountId, String apiType, String dateString);
}
