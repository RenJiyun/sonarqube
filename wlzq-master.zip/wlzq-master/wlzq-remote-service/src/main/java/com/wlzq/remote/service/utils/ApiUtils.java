package com.wlzq.remote.service.utils;

import java.io.IOException;
import java.util.Map;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.FrontDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.signature.AppSignatureMd5;
import com.wlzq.remote.service.config.ApiConfig;
import com.wlzq.remote.service.config.AppConfig;
import com.wlzq.service.base.sys.utils.AppConfigUtils;

public class ApiUtils { 
	private static ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
	
	/**
	 * api调用
	 * @param serviceType 调用类型
	 * @param params  参数
	 * @param needSign 是否需要签名
	 * @return
	 */
	public static FrontDto call(ApiServiceTypeEnum serviceType,Map<String,String> params,boolean needSign) {
		if(serviceType == null) {
			return new FrontDto(1,"服务类型未指定");
		}
		AppConfig config = SpringApplicationContext.getBean(AppConfig.class);
		if(config == null || config.getKey() == null || config.getSecret() == null) {
			return new FrontDto(1,"未配置应用程序");
		}
//		ApiConfig apiConfig = SpringApplicationContext.getBean(ApiConfig.class);
//		if(config == null || config.getKey() == null || config.getSecret() == null) {
//			return new FrontDto(1,"未配置请求地址");
//		}
//		String url = apiConfig.getUrl();
		String gatewayUrl = AppConfigUtils.get("SYS_GATEWAY_URL");
		//String gatewayUrl = "http://58.248.13.197:10510/api/";
		gatewayUrl = serviceType.equals(ApiServiceTypeEnum.COOPERATION)?gatewayUrl+"cooperate.do":gatewayUrl+"excute.do";
		return call(gatewayUrl,config.getKey(),config.getSecret(),params,needSign,ApiServiceTypeEnum.APP);
	}
	
	private static FrontDto call(String url,String appKey,String secret,Map<String,String> params,boolean needSign,ApiServiceTypeEnum serviceType) {
		if(needSign) {
			AppSignatureMd5 sign = new AppSignatureMd5(secret, params);
			sign.addIgnoreSignParam("nickname");
			sign.addIgnoreSignParam("k");
	        sign.addIgnoreSignParam("callbackparam");
			String signResult = sign.sign();
			params.put("noncestr", signResult);
		}
		params.put("k", appKey);
		String result = HttpClientUtils.doPost(url, params);
		 try {
			 FrontDto resultDto = null;
			 if(!serviceType.equals(ApiServiceTypeEnum.CALLBACK)) {
				 resultDto = mapper.readValue(result, FrontDto.class);
			 }else {
				 resultDto = new FrontDto(StatusDto.SUCCESS);
				 resultDto.setMsg(result);
			 }
			 return resultDto;
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new FrontDto(1,"json转bean异常");
	}
}
