package com.wlzq.remote.service.common.base.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wlzq.common.model.base.MediaLibrary;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.base.MediaBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

@Service
public class RemoteMediaBizImpl implements MediaBiz {

	
	@Override
	public StatusObjDto<List<MediaLibrary>> findMediaByIds(String ids) {
		if(ObjectUtils.isEmptyOrNull(ids)) {
			return new StatusObjDto<>(true,Lists.newArrayList(),StatusDto.SUCCESS,"");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("ids", ids);
		ResultDto result =  RemoteUtils.call("base.mediacooperation.findmediabyids",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<>(false,result.getCode(),result.getMsg());
		}
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> maps = (List<Map<String, Object>>)result.getData().get("info");
		List<MediaLibrary> mediaList = BeanUtils.toBeanList(maps, MediaLibrary.class);
		return new StatusObjDto<>(true,mediaList,StatusDto.SUCCESS,"");
	}

}
