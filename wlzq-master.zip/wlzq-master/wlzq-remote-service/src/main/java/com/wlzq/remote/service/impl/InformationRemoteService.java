package com.wlzq.remote.service.impl;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.wlzq.core.RequestParams;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.remote.service.RemoteService;
import com.wlzq.remote.service.ServiceFallback;

@FeignClient(value = "information", fallback = ServiceFallback.class)
public interface InformationRemoteService extends RemoteService{
	@RequestMapping(value = "/information/call", method = RequestMethod.POST)
    ResultDto call(@RequestBody RequestParams param);
}
