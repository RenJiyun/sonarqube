package com.wlzq.remote.service.common.pay;

import com.wlzq.common.model.pay.PayAgreement;
import com.wlzq.core.dto.StatusObjDto;

/**
 * 支付协议接口
 * @author zhaozx
 *
 */
public interface PayAgreementBiz {

	/**
	 * 创建支付协议
	 * @param order
	 * @return 订单号
	 */
	public StatusObjDto<PayAgreement> createAgreement(PayAgreement agreement);
	
	/**
	 * 解约
	 * @param agreementNo
	 * @return
	 */
	StatusObjDto<PayAgreement> unsignAgreement(String agreementNo);
	
}
