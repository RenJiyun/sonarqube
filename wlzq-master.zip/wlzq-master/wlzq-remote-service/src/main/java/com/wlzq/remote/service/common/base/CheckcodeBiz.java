package com.wlzq.remote.service.common.base;

import com.wlzq.common.constant.CheckcodeTypeE;
import com.wlzq.core.dto.StatusDto;

/**
 * CheckcodeBiz类
 * @author 
 * @version 1.0
 */
public interface CheckcodeBiz {	
	/**
	 * 校验图片验证码是否正确
	 * @param type
	 * @param wlzqstatId
	 * @param imageCheckcode
	 * @param deviceId
	 * @return
	 */
	StatusDto verityImageCheckcode(CheckcodeTypeE type,String wlzqstatId,String imageCheckcode,String deviceId);
	
	/**
	 * 发送短信验证码
	 * @param templateCode
	 * @param type,1:微信绑定验证码
	 * @param mobile
	 * @param params
	 * @return
	 */
	StatusDto sendCheckcode(String templateCode,CheckcodeTypeE type,String mobile,String deviceId);
	
	/**
	 * 检验验证码
	 * @param type,1:微信绑定验证码
	 * @param mobile
	 * @param checkcode
	 * @return
	 */
	StatusDto verifyCheckcode(CheckcodeTypeE type,String mobile,String checkcode,String deviceId);
}
