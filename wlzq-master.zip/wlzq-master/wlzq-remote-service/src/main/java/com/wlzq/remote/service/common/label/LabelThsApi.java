package com.wlzq.remote.service.common.label;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.label.dto.QueryLabelDto;
import com.wlzq.remote.service.common.label.dto.QueryLabelVo;
import com.wlzq.remote.service.common.label.dto.TokenDto;
import com.wlzq.service.base.sys.utils.AppConfigUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.message.BasicHeader;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author luohc
 * @date 2021/10/26 15:35
 */
@Service
@Slf4j
@Lazy
public class LabelThsApi implements ILabelApi{

    private static final String API_KEY = "label.ths.api.key";

    //http://172.19.0.84:8881/yyzt-web/openAPI/generateToken?apiKey=B549AB1080931A0EE44A56226C2D6BC7
    private static final String GENERATE_TOKEN_URL = "label.ths.generate.token.url";
    
    private static final String GENERATE_TOKEN_URL_MOBILE = "label.ths.generate.token.mobile.url";
    private static final String GENERATE_TOKEN_URL_CUSTOMER = "label.ths.generate.token.customer.url";

    //http://172.19.0.84:8881/yyzt-web/openAPI/apiForNonStoreHistory
    private static final String QUERY_NON_STORE_HISTORY_URL = "label.ths.query.non.store.history.url";
    
    private static final String QUERY_FOR_STORE_HISTORY_URL = "label.ths.query.for.store.history.url";

    private static final Integer SUCCESS_CODE=200;
    private static final Integer TOKEN_EXP_CODE =401;

    @Value("${spring.application.name}")
    private String applicationName;


    @Override
    public StatusObjDto<String> generateToken() {
        //缓存23h
        String tokenDtoStr = (String)LabelRedis.API_TOKEN.get(applicationName);
        if (StringUtils.isNotBlank(tokenDtoStr)) {
            TokenDto tokenDto = JSON.parseObject(tokenDtoStr, TokenDto.class);
            if (tokenDto != null) {
                String token = tokenDto.getToken();
                if (StringUtils.isNotBlank(token)) {
                    StatusObjDto<String> statusObjDto = StatusObjDto.newInstant(token);
                    return statusObjDto;
                }
            }
        }
        return refreshToken();
    }


    public StatusObjDto<String> refreshToken() {
        StatusObjDto<String> statusObjDto;
        String url = AppConfigUtils.get(GENERATE_TOKEN_URL);
        String httpResult = HttpClientUtils.doGet(url, null);

        String errMsg = "";
        String token = "";
        if (StringUtils.isNotBlank(httpResult)) {
            JSONObject jsonObject = JSON.parseObject(httpResult);
            Integer code = jsonObject.getInteger("code");
            String data = jsonObject.getString("data");
            if (SUCCESS_CODE.equals(code)) {
                token = data;
            }else{
                errMsg = code + "," + data;
            }
        }
        if (StringUtils.isNotBlank(token)) {
            statusObjDto = StatusObjDto.newInstant(token);
            TokenDto tokenDto = new TokenDto().setToken(token).setT(LocalDateTime.now());
            LabelRedis.API_TOKEN.set(applicationName,JSON.toJSONString(tokenDto));
        }else{
            statusObjDto = new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,errMsg);
        }
        return statusObjDto;
    }


    @Override
    public StatusObjDto<QueryLabelDto> queryLabel(QueryLabelVo queryLabelVo) {
        StatusObjDto<QueryLabelDto> statusObjDto ;
        if (queryLabelVo == null || queryLabelVo.getAccountId() == null) {
            statusObjDto = new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"参数错误");
            return statusObjDto;
        }

        StatusObjDto<Map<String, Object>> map = doQueryLabel(queryLabelVo.getAccountId(), true,null);
        String label = queryLabelVo.getLabel();
        QueryLabelDto queryLabelDto = new QueryLabelDto()
                .setLabelName(label)
                .setValue((String) map.getObj().get(label));
        return StatusObjDto.newInstant(queryLabelDto);
    }


    @Override
    public StatusObjDto<Map<String,Object>> queryLabelList(String accountId) {
        return doQueryLabel(accountId,true,null);
    }

    private StatusObjDto<Map<String, Object>> doQueryLabel(String accountId,boolean needAgain,String token) {
        String url = AppConfigUtils.get(QUERY_NON_STORE_HISTORY_URL);

        if (token == null) {
            StatusObjDto<String> tokenStatusObj = generateToken();
            if (tokenStatusObj.isOk()) {
                token = tokenStatusObj.getObj();
            }else{
                log.info("generateToken 异常");
                return new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"generateToken 异常");
            }
        }

        StatusObjDto<Map<String, Object>> statusObjDto = null;
        List<Header> headers = new ArrayList<>();
        Header header = new BasicHeader("Authorization","Bearer " + token);
        headers.add(header);
        String httpResult = HttpClientUtils.doGet(url + "?accountId=" + accountId, null,headers);
        //例子：{"code":200,"msg":"调用 OPEN API 接口成功！","data":{"wl00101":"雷楚群","wl00102":"男","wl00103":"白云分公司","wl00104":"50"},"success":true}

//        httpResult = "{\"code\":200,\"msg\":\"调用 OPEN API 接口成功！\",\"data\":{\"wl00101\":\"雷楚群\",\"wl00102\":\"男\",\"wl00103\":\"白云分公司\",\"wl00104\":1},\"success\":true}";
        String errMsg = "";
        Map<String,Object> dataMap;
        if (StringUtils.isNotBlank(httpResult)) {
            Map<String,Object> map = JsonUtils.jsonToMap(httpResult);
            Integer code = (Integer) map.get("code");
            dataMap = (Map<String, Object>) map.get("data");
            if (SUCCESS_CODE.equals(code)) {
                statusObjDto = StatusObjDto.newInstant(dataMap);
            }else if(TOKEN_EXP_CODE.equals(code) && needAgain){
//                //token失效的时候，再请求一次
                StatusObjDto<String> tokenDto = refreshToken();
                if (tokenDto.isOk()) {
                    statusObjDto = doQueryLabel(accountId,false,tokenDto.getObj());
                }else{
                    log.info("refreshToken 异常");
                    return new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"refreshToken 异常");
                }
            }else{
                errMsg = code!=null ? code.toString() + map.get("msg") : (String) map.get("msg");
            }
        }
        if (statusObjDto == null) {
            statusObjDto = new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,errMsg);
        }
        return statusObjDto;
    }
    
    private StatusObjDto<Map<String, Object>> doQueryLabel(Integer accountType, String accountId,boolean needAgain,String token) {
        String url = AppConfigUtils.get(QUERY_NON_STORE_HISTORY_URL);

        if (token == null) {
            StatusObjDto<String> tokenStatusObj = generateToken(accountType);
            if (tokenStatusObj.isOk()) {
                token = tokenStatusObj.getObj();
            }else{
                log.info("generateToken 异常");
                return new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"generateToken 异常");
            }
        }

        StatusObjDto<Map<String, Object>> statusObjDto = null;
        List<Header> headers = new ArrayList<>();
        Header header = new BasicHeader("Authorization","Bearer " + token);
        headers.add(header);
        String httpResult = HttpClientUtils.doGet(url + "?accountId=" + accountId, null,headers);
        //例子：{"code":200,"msg":"调用 OPEN API 接口成功！","data":{"wl00101":"雷楚群","wl00102":"男","wl00103":"白云分公司","wl00104":"50"},"success":true}

//        httpResult = "{\"code\":200,\"msg\":\"调用 OPEN API 接口成功！\",\"data\":{\"wl00101\":\"雷楚群\",\"wl00102\":\"男\",\"wl00103\":\"白云分公司\",\"wl00104\":1},\"success\":true}";
        String errMsg = "";
        Map<String,Object> dataMap;
        if (StringUtils.isNotBlank(httpResult)) {
            Map<String,Object> map = JsonUtils.jsonToMap(httpResult);
            Integer code = (Integer) map.get("code");
            dataMap = (Map<String, Object>) map.get("data");
            if (SUCCESS_CODE.equals(code)) {
                statusObjDto = StatusObjDto.newInstant(dataMap);
            }else if(TOKEN_EXP_CODE.equals(code) && needAgain){
//                //token失效的时候，再请求一次
                StatusObjDto<String> tokenDto = refreshToken(accountType);
                if (tokenDto.isOk()) {
                    statusObjDto = doQueryLabel(accountType,accountId,false,tokenDto.getObj());
                }else{
                    log.info("refreshToken 异常");
                    return new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"refreshToken 异常");
                }
            }else{
                errMsg = code!=null ? code.toString() + map.get("msg") : (String) map.get("msg");
            }
        }
        if (statusObjDto == null) {
            statusObjDto = new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,errMsg);
        }
        return statusObjDto;
    }

    public StatusObjDto<Map<String, Object>> doQueryHistoryLabelList(Integer accountType, String accountId, String apiType, String dateString,boolean needAgain,String token) {
        String url = AppConfigUtils.get(QUERY_FOR_STORE_HISTORY_URL);

        //按日期查询且入参没有指定日期，则查询最新的标签
        if("everyDay".equals(apiType) && StringUtils.isBlank(dateString)) {
            return doQueryLabel(accountType,accountId,true,null);
        }

        if (token == null) {
            StatusObjDto<String> tokenStatusObj = generateToken(accountType);
            if (tokenStatusObj.isOk()) {
                token = tokenStatusObj.getObj();
            }else{
                log.info("generateToken 异常");
                return new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"generateToken 异常");
            }
        }

        StatusObjDto<Map<String, Object>> statusObjDto = null;
        List<Header> headers = new ArrayList<>();
        Header header = new BasicHeader("Authorization","Bearer " + token);
        headers.add(header);
        String httpResult = HttpClientUtils.doGet(url + "?accountId=" + accountId + "&apiType="+ apiType +"&pDate=" + dateString , null,headers);
        //例子：{"code":200,"msg":"调用 OPEN API 接口成功！","data":{"wl00101":"雷楚群","wl00102":"男","wl00103":"白云分公司","wl00104":"50"},"success":true}

//        httpResult = "{\"code\":200,\"msg\":\"调用 OPEN API 接口成功！\",\"data\":{\"wl00101\":\"雷楚群\",\"wl00102\":\"男\",\"wl00103\":\"白云分公司\",\"wl00104\":1},\"success\":true}";
        String errMsg = "";
        Map<String,Object> dataMap;
        if (StringUtils.isNotBlank(httpResult)) {
            Map<String,Object> map = JsonUtils.jsonToMap(httpResult);
            Integer code = (Integer) map.get("code");
            dataMap = (Map<String, Object>) map.get("data");
            if (SUCCESS_CODE.equals(code)) {
                statusObjDto = StatusObjDto.newInstant(dataMap);
            }else if(TOKEN_EXP_CODE.equals(code) && needAgain){
//                //token失效的时候，再请求一次
                StatusObjDto<String> tokenDto = refreshToken(accountType);
                if (tokenDto.isOk()) {
                    statusObjDto = doQueryHistoryLabelList(accountType,accountId, apiType, dateString,false,tokenDto.getObj());
                }else{
                    log.info("refreshToken 异常");
                    return new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,"refreshToken 异常");
                }
            }else{
                errMsg = code!=null ? code.toString() + map.get("msg") : (String) map.get("msg");
            }
        }
        if (statusObjDto == null) {
            statusObjDto = new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,errMsg);
        }
        return statusObjDto;
    }

	@Override
	public StatusObjDto<Map<String, Object>> queryHistoryLabelList(Integer accountType, String accountId, String apiType, String dateString) {
		return doQueryHistoryLabelList(accountType, accountId, apiType, dateString, true,null);
	}


	@Override
	public StatusObjDto<String> generateToken(Integer accountType) {
		String key = applicationName + accountType.toString();
		//缓存23h
        String tokenDtoStr = (String)LabelRedis.API_TOKEN.get(key);
        if (StringUtils.isNotBlank(tokenDtoStr)) {
            TokenDto tokenDto = JSON.parseObject(tokenDtoStr, TokenDto.class);
            if (tokenDto != null) {
                String token = tokenDto.getToken();
                if (StringUtils.isNotBlank(token)) {
                    StatusObjDto<String> statusObjDto = StatusObjDto.newInstant(token);
                    return statusObjDto;
                }
            }
        }
        return refreshToken(accountType);
	}
	
	public StatusObjDto<String> refreshToken(Integer accountType) {
		String url = "";
		if(accountType.equals(1)) {
			url = AppConfigUtils.get(GENERATE_TOKEN_URL_MOBILE);
		}
		if(accountType.equals(2)) {
			url = AppConfigUtils.get(GENERATE_TOKEN_URL_CUSTOMER);
		}
		
		String key = applicationName + accountType.toString();
        StatusObjDto<String> statusObjDto;
        String httpResult = HttpClientUtils.doGet(url, null);

        String errMsg = "";
        String token = "";
        if (StringUtils.isNotBlank(httpResult)) {
            JSONObject jsonObject = JSON.parseObject(httpResult);
            Integer code = jsonObject.getInteger("code");
            String data = jsonObject.getString("data");
            if (SUCCESS_CODE.equals(code)) {
                token = data;
            }else{
                errMsg = code + "," + data;
            }
        }
        if (StringUtils.isNotBlank(token)) {
            statusObjDto = StatusObjDto.newInstant(token);
            TokenDto tokenDto = new TokenDto().setToken(token).setT(LocalDateTime.now());
            LabelRedis.API_TOKEN.set(key,JSON.toJSONString(tokenDto));
        }else{
            statusObjDto = new StatusObjDto<>(false,StatusObjDto.FAIL_COMMON,errMsg);
        }
        return statusObjDto;
    }

}
