
package com.wlzq.remote.service.common.account;

import com.wlzq.common.constant.RegistSourceE;
import com.wlzq.common.constant.RegistTypeE;
import com.wlzq.common.constant.ThirdAccountTypeE;
import com.wlzq.common.model.account.AccUser;
import com.wlzq.core.dto.StatusObjDto;

/**
 *  AccountUserBiz类
 * @author 
 * @version 1.0
 */
public interface AccountUserBiz {	
	
	AccUser findByUserId(String userId);

	AccUser findByMobile(String mobile);
	
	AccUser findByOpenId(String openId);
	
	AccUser findByShareCode(String shareCode);
	
	/**
	 * 创建账户用户信息
	 * @param mobile
	 * @return
	 */
	StatusObjDto<String> createUser(String mobile,Integer isStaff,RegistTypeE regType,RegistSourceE regSource);

	/**
	 * 创建账户用户信息
	 * @param mobile
	 * @return
	 */
	StatusObjDto<String> createUser(AccUser user);
	/**
	 * 创建第三方账户用户信息
	 * @param mobile
	 * @param thirdUid 第三方uid
	 * @param thirdType 第三方类型 ，1：公众号
	 * @return
	 */
	StatusObjDto<String> createThirdUser(String mobile, String thirdUid, ThirdAccountTypeE thirdType) ;
	
	/**
	 * 微信关注状态
	 * @param openId
	 * @return
	 */
	StatusObjDto<Integer> wechatSubscribestatus(String openId);
}
