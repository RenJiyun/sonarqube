package com.wlzq.remote.service.common.push.executor;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.wlzq.common.utils.DateUtils;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.remote.service.common.push.dto.BasePushBo;
import com.wlzq.remote.service.common.push.dto.BasePushCfgDto;
import com.wlzq.remote.service.utils.RemoteUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.GenericTypeResolver;
import org.springframework.util.ClassUtils;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 推送Executor
 * @author luohc
 * @date 2021/6/21 14:53
 */
@Slf4j
public abstract class PushExecutorAbs<C extends BasePushCfgDto,T extends BasePushBo> implements IPushExecutor {
	protected Class<C> configClass = currentConfigClass();
	protected Class<T> modelClass = currentModelClass();

	protected Class<C> currentConfigClass() {
		return (Class<C>) getSuperClassGenericType(this.getClass(), PushExecutorAbs.class, 0);
	}

	protected Class<T> currentModelClass() {
		return (Class<T>) getSuperClassGenericType(this.getClass(), PushExecutorAbs.class, 1);
	}

	public static Class<?> getSuperClassGenericType(final Class<?> clazz, final Class<?> genericIfc, final int index) {
		Class<?>[] typeArguments = GenericTypeResolver.resolveTypeArguments(ClassUtils.getUserClass(clazz), genericIfc);
		return null == typeArguments ? null : typeArguments[index];
	}


	/**
	 * 创建一个推送批次
	 */
	public String newBatch() {
		String a = "" + (Math.random() * 9000);
		a = a.substring(1, 4);
		a  = a.replace(".", "0");
		return DateUtils.formate(new Date(System.currentTimeMillis()), "yyyyMMddHHmmssSSS") + a;
	}

	/**
	 * 发送单个推送消息
	 */
	public ResultDto sendSingleMsg(String msgThemeCode, String batch, int size, int order, Map<String, Object> busParams) {
		Map<String, Object> params = Maps.newHashMap();
		params.put("msgThemeCode", msgThemeCode);
		params.put("batch", batch);
		params.put("number", size);
		params.put("order", order);
		params.put("busParams", JsonUtils.object2JSON(busParams));
		ResultDto result = RemoteUtils.call("push.msgthemepushcooperation.sendsinglemsg", ApiServiceTypeEnum.COOPERATION, params, true);
		return result;
	}


	protected ResultDto genSingle(String msgThemeCode, Integer taskId, String batch, int size, int order, Map<String, Object> busParams) {
		Map<String, Object> params = Maps.newHashMap();
		params.put("msgThemeCode", msgThemeCode);
		params.put("taskId", taskId);
		params.put("batch", batch);
		params.put("number", size);
		params.put("order", order);
		params.put("busParams", JsonUtils.object2JSON(busParams));
		ResultDto result = RemoteUtils.call("push.msgthemepushcooperation.gensinglemsg", ApiServiceTypeEnum.COOPERATION, params, true);
		return result;
	}


	protected Map<String, Object> genOrGetTask(String msgThemeCode, String taskName, String taskTime, String batch, Integer isTemp, String taskKey, Integer num) {
		Map<String, Object> params = Maps.newHashMap();
		params.put("msgThemeCode", msgThemeCode);
		params.put("taskName", taskName);
		params.put("taskTime", taskTime);
		params.put("batch", batch);
		params.put("isTemp", isTemp);
		params.put("taskKey", taskKey);
		params.put("planPushNum", num);
		ResultDto result = RemoteUtils.call("push.msgthemepushcooperation.gettask", ApiServiceTypeEnum.COOPERATION, params, true);
		if (result != null && result.getCode() != null && result.getCode().intValue() == 0) {
			if (result.getData() != null) {
				Map<String, Object> m = result.getData();
				@SuppressWarnings("unchecked")
				Map<String, Object> taskInfos = (Map<String, Object>) m.get("taskInfos");
				return taskInfos;
			}
		}
		return null;
	}


	/**
	 * 生成pushtask
	 */
	protected Integer genPushTask(BasePushCfgDto pushDto, int size, String batchCode) {
		Integer taskId = null;
		Date date = new Date();
		String taskDate = DateUtils.formate(date, "yyyy-MM-dd");
		String taskTime = taskDate + " 00:00:00";
		String taskKey = "T|" + taskDate;//llll 后面哪里会用到这个

		Map<String, Object> taskInfos = genOrGetTask(pushDto.getMsgThemeCode(), pushDto.getTaskName(), taskTime,
				batchCode, 1, taskKey, size);

		if (taskInfos != null) {
			if (taskInfos.get("isOk") != null) {
				if (taskInfos.get("isOk").equals(1)) {
					taskId = (Integer) taskInfos.get("taskId");
					if (!(taskId != null && taskId > 0)) {
						taskId = null;
					}
				} else if (taskInfos.get("isOk").equals(2)) {
					log.info("<|>" + "生成获取推送任务" + "<|>" +
							"batch:" + batchCode + "<|>" +
							"taskName:" + pushDto.getTaskName() + "<|>" +
							"生成任务状态:当日无需生成推送任务");
				}
			}
		}

		if (taskId ==null) {
			log.info("<|>" + "生成获取推送任务" + "<|>" +
					"batch:" + batchCode + "<|>" +
					"taskName:" + pushDto.getTaskName() + "<|>" +
					"生成任务状态:失败");
		}
		return taskId;
	}

	@Override
	public StatusDto run(String data) {
		log.info("push task read data start");
		if (StringUtils.isBlank(data)) {
			return new StatusDto(true, "任务配置信息不能为空。");
		}
		//参数转换
		C cfgDto = JSON.parseObject(data, configClass);

		//查找数据 - 子类实现！
		List<T> bos = findData(cfgDto);
		if (CollectionUtils.isEmpty(bos)) {
			return new StatusDto(true, "没有符合条件的数据，无需执行");
		}
		int dataSize = bos.size();
		log.info("push task read data, total:[{}] ", dataSize);

		//批次号生成
		String batchCode = newBatch();

		//调用数据的生成。
		if (Objects.equals(1, cfgDto.getSendNowFlag())) {
			genDataAndSendNow(cfgDto, bos, batchCode,dataSize);
		} else {
			genData(cfgDto, bos, batchCode,dataSize);
		}

		log.info("push task read data end");
		return new StatusDto(true, StatusDto.SUCCESS, "");
	}

	protected void genData(BasePushCfgDto cfgDto, List<T> bos, String batchCode,int dataSize) {
		Integer taskId = genPushTask(cfgDto, dataSize, batchCode);
		if (taskId != null) {
			genPushRecords(cfgDto, bos, batchCode, taskId,dataSize);
		}
	}

	protected void genPushRecords(BasePushCfgDto cfgDto, List<T> bos, String batchCode, Integer taskId,int dataSize) {
		String msgThemeCode = cfgDto.getMsgThemeCode();
		String dateTimeStr = DateUtils.formate(new Date(System.currentTimeMillis()), "yyyyMMdd");

		for (int i = 0; i < dataSize; i++) {
			T item = bos.get(i);
			Map<String, Object> busParams = beanToMap(item,dateTimeStr);
			if (busParams!=null) {
				genSingle(msgThemeCode, taskId, batchCode, dataSize, i, busParams);
			}
		}
	}


	/**
	 * 立即发送的情况
	 */
	protected void genDataAndSendNow(BasePushCfgDto cfgDto, List<T> bos, String batchCode,int dataSize) {
		String dateTimeStr = DateUtils.formate(new Date(System.currentTimeMillis()), "yyyyMMdd");
		for (int i = 0; i < dataSize; i++) {
			T item = bos.get(i);
			Map<String, Object> busParams = beanToMap(item,dateTimeStr);
			if (busParams!=null) {
				sendSingleMsg(cfgDto.getMsgThemeCode(), batchCode, dataSize, i, busParams);
			}
		}
	}

	abstract protected List<T> findData(C cfgDto);

	abstract protected Map<String, Object> beanToMap(T t,String dateTimeStr);


}
