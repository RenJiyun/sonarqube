package com.wlzq.remote.service.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:dnsplat.properties"}) 
@ConfigurationProperties(prefix="compare")
public class DnsPlateformCompareConfig {
	/**
	 * 平台配置，key:平台名,value:对照平台名
	 */
    private Map<String, String> service = new HashMap<String,String>(); //接收plateform里面的属性值  
	
	public Map<String, String> getService() {
		return service;
	}

	public void setService(Map<String, String> service) {
		this.service = service;
	}

	public String getPlateform(String name) {
		return this.service.get(name);
	}
}
