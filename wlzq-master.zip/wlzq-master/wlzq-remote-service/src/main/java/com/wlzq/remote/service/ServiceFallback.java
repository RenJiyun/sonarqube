package com.wlzq.remote.service;

import com.wlzq.remote.service.impl.*;
import org.springframework.stereotype.Component;

import com.wlzq.core.RequestParams;
import com.wlzq.core.dto.ResultDto;

@Component
public class ServiceFallback implements PayRemoteService,AccountRemoteService,BaseRemoteService,ActivityRemoteService,
	ServiceRemoteService,UploadRemoteService,T2GatewayRemoteService,DataRemoteService,BehaviorMysqlRemoteService,BehaviorRemoteService,
	BusinessRemoteService,FinancingRemoteService,InformationRemoteService,SaleRemoteService,WebsiteRemoteService,WechatSdRemoteService,
	PushRemoteService,DbNotifyRemoteService,FinDataRemoteService,ChinaClearRemoteService,FinCalRemoteService,MonitorRemoteService, PmessageRemoteService {
	public ResultDto call(RequestParams param) {
		return new ResultDto(1,param.getService()+"."+param.getMethod()+"调用异常，检查服务是否正常");
	}

	@Override
	public String check(String plateForm) {
		return "error";
	}
}
