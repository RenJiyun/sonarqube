package com.wlzq.remote.service.common.base;

import java.util.List;
import java.util.Map;

import com.wlzq.common.model.account.AccAccountOpeninfo;
import com.wlzq.core.dto.StatusObjDto;

public interface FsdpBiz {

	/**
	 * 人员信息
	 * @param crmno
	 * @return
	 */
	StatusObjDto<Map<String, Object>> ryxx(String crmno);
	
	/**
	 * 职业资格信息
	 * @param crmno
	 * @return
	 */
	StatusObjDto<List<Map<String, Object>>> zyzgxx(String crmno);
	
	/**
	 * 人员开户二维码
	 * @param crmno
	 * @return
	 */
	StatusObjDto<Map<String, Object>> rykhewm(String crmno);
	
	/**
	 * 客户日均资产
	 * @param customerId
	 * @return
	 */
	StatusObjDto<Map<String, Object>> khrjzc(String customerId);
	
	/**
	 * 员工考试成绩
	 * @param crmno
	 * @return
	 */
	StatusObjDto<List<Map<String, Object>>> ygkscjxx(String crmno);	
	
	/**
	 * 根据客户号获取开发员工
	 * @param customerId
	 * @return
	 */
	StatusObjDto<List<Map<String, Object>>> khgxxx(String customerId);
	
	/**
	 * 查询ekp账号信息
	 * @param ekpAccount
	 * @return
	 */
	StatusObjDto<Map<String, Object>> ekptxlygxx(String ekpAccount);
	
	/**
	 * 客户开户信息查询
	 * @param crmno
	 * @return
	 */
	StatusObjDto<List<AccAccountOpeninfo>> khkhxx(String customerId, String customerName, String customerMobile);	
	
	/**
	 * 客户开户信息查询
	 * @param identityNumber 证件编号
	 * @param customerName 姓名
	 * @return
	 */
	StatusObjDto<List<AccAccountOpeninfo>> khkhxx(String identityNumber, String customerName);	
}
