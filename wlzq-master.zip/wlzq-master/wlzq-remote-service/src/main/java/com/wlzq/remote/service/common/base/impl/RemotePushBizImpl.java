package com.wlzq.remote.service.common.base.impl;

import com.alibaba.fastjson.JSON;
import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RegxUtils;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.remote.service.common.base.PushBiz;
import com.wlzq.remote.service.common.base.dto.SmsSendDto;
import com.wlzq.remote.service.common.push.dto.SceneSendDto;
import com.wlzq.remote.service.config.AppConfig;
import com.wlzq.remote.service.utils.RemoteUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * PushBiz实现类
 * @author 
 * @version 1.0
 */
@Service("remotePushBiz")
public class RemotePushBizImpl  implements PushBiz{


	@Autowired
	private AppConfig appConfig ;

	@Override
	public StatusDto  push(String templateCode, String userId, List<Object> params) {
		if(ObjectUtils.isEmptyOrNull(templateCode)) {
			return new StatusDto(false,"templateCode参数不能为空");
		}
		
		return new StatusDto(false,"un implement");
	}

	@Override
	public StatusDto sendSms(String templateCode, String mobile, List<Object> params) {
		if(ObjectUtils.isEmptyOrNull(templateCode)) {
			return new StatusDto(false,201,"templateCode参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusDto(false,203,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusDto(false,204, "请输入正确的手机号"); 
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("mobile", mobile);
		busparams.put("templateCode",templateCode);
		busparams.put("params",params);
		
		ResultDto result = RemoteUtils.call("base.pushcooperation.sendshortmessage",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusDto(false,result.getCode(),result.getMsg());
		}
		return new StatusDto(true,"");
	}


	@Deprecated
	@Override
	public StatusDto sendSmsWithTmpl(String templateCode, String mobile, List<Object> params) {
		if(ObjectUtils.isEmptyOrNull(templateCode)) {
			return new StatusDto(false,201,"templateCode参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusDto(false,203,"mobile参数不能为空");
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusDto(false,204, "请输入正确的手机号");
		}

		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("mobile", mobile);
		busparams.put("templateCode",templateCode);
		busparams.put("params",params);
		busparams.put("msgCategory",1);

		ResultDto result = RemoteUtils.call("push.pushcooperation.sendshortmessage",ApiServiceTypeEnum.COOPERATION, busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusDto(false,result.getCode(),result.getMsg());
		}
		return new StatusDto(true,"");
	}

	@Override
	public StatusDto sendSmsWithTmpl(SmsSendDto smsSendDto) {
		String mobile = smsSendDto.getMobile();
		String templateCode = smsSendDto.getTemplateCode();
		Integer msgCategory = smsSendDto.getMsgCategory();
		if(ObjectUtils.isEmptyOrNull(templateCode)) {
			return new StatusDto(false,201,"templateCode参数不能为空");
		}
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusDto(false,203,"mobile参数不能为空");
		}

		Map<String, Object> map = new HashMap<>();
		map.put("mobile", mobile);
		map.put("templateCode",templateCode);
		map.put("msgCategory", msgCategory);
		map.put("jsonParam",smsSendDto.getJsonParam());

		//todo try catch
		ResultDto result = RemoteUtils.call("push.pushcooperation.sendshortmessage",ApiServiceTypeEnum.COOPERATION, map,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusDto(false,result.getCode(),result.getMsg());
		}
		return new StatusDto(true,"");
	}



	@Override
	public StatusDto sendSms(String mobile, String content) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getSendContent(String content, List<Object> params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String sendSceneMessage(SceneSendDto sendDto) {
		return httpGet("upush.scenecooperation.send", sendDto);
	}


	private String httpGet(String method, Object obj){
		String json;
		if(obj instanceof String){
			json = (String) obj;
		}else{
			json = JSON.toJSONString(obj);
		}

		String gatewayUrl = System.getProperty("gateway.url");
		if (StringUtils.isBlank(gatewayUrl)) {
			String activeProfile = SpringApplicationContext.getActiveProfile();
			if ("production".equals(activeProfile) || activeProfile.contains("production")) {
				gatewayUrl = "http://172.16.25.56:8081/upush";
			}else if ("propre".equals(activeProfile) || activeProfile.contains("propre")) {
				gatewayUrl = "http://172.19.1.205:8081/api";
			}else if ("test".equals(activeProfile) || activeProfile.contains("test")) {
				gatewayUrl = "http://172.19.1.96:10510/gateway";
			}else {
				gatewayUrl = "http://127.0.0.1:8081/api";
			}
		}

		String url = gatewayUrl + "/cooperate" ;
		Map<String, String> params = new HashMap<>();
		params.put("method",method);
		params.put("params",json);
		params.put("k",appConfig.getKey());
		return HttpClientUtils.doPost(url, params);
	}

}
