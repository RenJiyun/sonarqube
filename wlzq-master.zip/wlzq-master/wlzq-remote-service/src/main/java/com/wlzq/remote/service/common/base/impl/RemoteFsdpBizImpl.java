package com.wlzq.remote.service.common.base.impl;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wlzq.common.model.account.AccAccountOpeninfo;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.base.FsdpBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

@Service
public class RemoteFsdpBizImpl implements FsdpBiz {
	
	private Logger logger = LoggerFactory.getLogger(FsdpBiz.class);

	@Override
	public StatusObjDto<Map<String, Object>> ryxx(String crmno) {
		if (ObjectUtils.isEmptyOrNull(crmno)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("crmno");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.ryxx");
		Map<String, Object> params = Maps.newHashMap();
		params.put("I_N_RYBH", crmno);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToMap(resultDto), StatusDto.SUCCESS, "");
	}

	@Override
	public StatusObjDto<List<Map<String, Object>>> zyzgxx(String crmno) {
		if (ObjectUtils.isEmptyOrNull(crmno)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("crmno");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.zyzgxx");
		Map<String, Object> params = Maps.newHashMap();
		params.put("I_N_RYBH", crmno);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToList(resultDto), StatusDto.SUCCESS, "");
	}

	@Override
	public StatusObjDto<Map<String, Object>> rykhewm(String crmno) {
		if (ObjectUtils.isEmptyOrNull(crmno)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("crmno");
		}
		Map<String, Object> userIdParam = Maps.newHashMap();
		userIdParam.put("crmId", crmno);
		ResultDto userIdDto = RemoteUtils.call("base.fsdp.gettuserid", ApiServiceTypeEnum.APP, userIdParam, true);
		if (!ResultDto.SUCCESS.equals(userIdDto.getCode()) || userIdDto.getData() == null || userIdDto.getData().isEmpty()) {
			return new StatusObjDto<>(false, userIdDto.getCode(), userIdDto.getMsg());
		}
		if (ObjectUtils.isEmptyOrNull(userIdDto.getData().get("tuserid"))) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("tuserid");
		}
		String tuserid = String.valueOf(userIdDto.getData().get("tuserid"));
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.rykhewm");
		Map<String, Object> params = Maps.newHashMap();
		params.put("I_N_USERID", tuserid);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToMap(resultDto), StatusDto.SUCCESS, "");
	}

	@Override
	public StatusObjDto<Map<String, Object>> khrjzc(String customerId) {
		if (ObjectUtils.isEmptyOrNull(customerId)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.khrjzc");
		Map<String, Object> params = Maps.newHashMap();
		params.put("I_KHH", customerId);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToMap(resultDto), StatusDto.SUCCESS, "");
	}

	@Override
	public StatusObjDto<List<Map<String, Object>>> ygkscjxx(String crmno) {
		if (ObjectUtils.isEmptyOrNull(crmno)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("crmno");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.sjzx.YGKSCJXX");
		Map<String, Object> params = Maps.newHashMap();
		params.put("V_RYBH", crmno);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToList(resultDto), StatusDto.SUCCESS, "");
	}
	
	private Map<String, Object> parseToMap(ResultDto resultDto) {
		Map<String, Object> result = Maps.newHashMap();
		try {
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> list = (List<Map<String, Object>>)resultDto.getData().get("O_RESULT");
			result = list.get(0);
		} catch (Exception e) {
			logger.error("parseMap error: " + e.getMessage());
		}
		return result;
	}
	
	private List<Map<String, Object>> parseToList(ResultDto resultDto) {
		try {
			@SuppressWarnings("unchecked")
			List<Map<String, Object>> result = (List<Map<String, Object>>)resultDto.getData().get("O_RESULT");
			return result;
		} catch (Exception e) {
			logger.error("parseMap error: " + e.getMessage());
		}
		return Lists.newArrayList();
	}

	@Override
	public StatusObjDto<List<Map<String, Object>>> khgxxx(String customerId) {
		if (ObjectUtils.isEmptyOrNull(customerId)) {
			return new StatusObjDto<>(true, Lists.newArrayList(), StatusDto.SUCCESS, "");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.KHGXXX");
		Map<String, Object> params = Maps.newHashMap();
		params.put("I_KHH", customerId);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToList(resultDto), StatusDto.SUCCESS, "");
	}

	@Override
	public StatusObjDto<Map<String, Object>> ekptxlygxx(String ekpAccount) {
		if (ObjectUtils.isEmptyOrNull(ekpAccount)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("ekpAccount");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.sjzx.ekptxlygxx");
		Map<String, Object> params = Maps.newHashMap();
		params.put("I_CODE", ekpAccount);
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		return new StatusObjDto<>(true, parseToMap(resultDto), StatusDto.SUCCESS, "");
	}

	@Override
	public StatusObjDto<List<AccAccountOpeninfo>> khkhxx(String customerId, String customerName, String customerMobile) {
		
		if (ObjectUtils.isEmptyOrNull(customerId) && ObjectUtils.isEmptyOrNull(customerName) && ObjectUtils.isEmptyOrNull(customerMobile)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("customerId | customerName | customerMobile");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.KHKHXX");
		Map<String, Object> params = Maps.newHashMap();
		params.put("V_KHH", customerId);
		try {
			if (ObjectUtils.isNotEmptyOrNull(customerName)) {
				params.put("V_KHXM", new String(customerName.getBytes(), "GBK"));
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		params.put("V_SJH", customerMobile);
		
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> result = (List<Map<String, Object>>)resultDto.getData().get("O_RESULT");
		List<AccAccountOpeninfo> list = Lists.newArrayList();
		for (Map<String, Object> map : result) {
			AccAccountOpeninfo info = AccAccountOpeninfo.parseFromFsdpMap(map);
			if (info != null) {
				list.add(info);
			}
		}
		return new StatusObjDto<>(true, list, StatusDto.SUCCESS, "");
	}
	
	@Override
	public StatusObjDto<List<AccAccountOpeninfo>> khkhxx(String identityNumber, String customerName) {
		
		if (ObjectUtils.isEmptyOrNull(identityNumber) && ObjectUtils.isEmptyOrNull(customerName)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("identityNumber | customerName");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		String serviceId = new String("ext.crm.dspt.KHKHXX");
		Map<String, Object> params = Maps.newHashMap();
		params.put("V_ZJBH", identityNumber);
		try {
			if (ObjectUtils.isNotEmptyOrNull(customerName)) {
				params.put("V_KHXM", new String(customerName.getBytes(), "GBK"));
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		busparams.put("serviceId", serviceId);
		busparams.put("isNeedLogin", 1);
		busparams.put("params", JsonUtils.map2Json(params));
		ResultDto resultDto = RemoteUtils.call("base.fsdpcoopration.callservice", ApiServiceTypeEnum.COOPERATION, busparams, false);
		if (!ResultDto.SUCCESS.equals(resultDto.getCode()) || resultDto.getData() == null || resultDto.getData().isEmpty() || resultDto.getData().get("O_RESULT") == null) {
			return new StatusObjDto<>(false, resultDto.getCode(), resultDto.getMsg());
		}
		@SuppressWarnings("unchecked")
		List<Map<String, Object>> result = (List<Map<String, Object>>)resultDto.getData().get("O_RESULT");
		List<AccAccountOpeninfo> list = Lists.newArrayList();
		for (Map<String, Object> map : result) {
			AccAccountOpeninfo info = AccAccountOpeninfo.parseFromFsdpMap(map);
			if (info != null) {
				list.add(info);
			}
		}
		return new StatusObjDto<>(true, list, StatusDto.SUCCESS, "");
	}
}
