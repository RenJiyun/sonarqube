package com.wlzq.remote.service.common.push.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * @author luohc
 * @date 2022/6/15 14:31
 */
@Data
@Accessors(chain = true)
public class AppParaDto implements Serializable {


    private static final long serialVersionUID = -5585173458965834060L;
    /** APP推送展示方式。 1:全部展示方式， 2：消息盒子 */
    private Integer showType;

    /** 推送平台设置，取值："android","ios"，需发送所有平台时设为“all” 。默认是all */
    private String platform;

}
