package com.wlzq.remote.service.factory;

import com.wlzq.core.SpringApplicationContext;
import com.wlzq.remote.service.RemoteService;
import com.wlzq.remote.service.config.AppConfig;
import com.wlzq.remote.service.config.DnsPlateformCompareConfig;
import com.wlzq.remote.service.impl.DnsBasedRemoteServiceImpl;

public class RemoteServiceFactory {
	public static RemoteService getRemoteService(String service) {
		AppConfig appConfig = SpringApplicationContext.getBean(AppConfig.class);
		//返回基于dns解析的远程服务类
		if(appConfig != null && appConfig.getMicroType().equals(AppConfig.MICRO_TYPE_DNS)){
			RemoteService  remoteService = SpringApplicationContext.getBean(DnsBasedRemoteServiceImpl.class);
			return remoteService;
		}
//		PlateForms plateForms = SpringApplicationContext.getBean(PlateForms.class);
//		if(plateForms == null) return null;
//		String plateFormClass = plateForms.getPlateForm(service);
//		if(plateFormClass == null) return null;
//		RemoteService remoteService = null;
//		try {
//			remoteService = (RemoteService) SpringApplicationContext.getBean(Class.forName(plateFormClass));
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		RemoteService remoteService = getRemoteTemplateService( service);
    	return remoteService;
	}

	public static RemoteService getRemoteTemplateService(String service) {
		FeignClients feignClients = SpringApplicationContext.getBean(FeignClients.class);
		DnsPlateformCompareConfig plateformCompare = SpringApplicationContext.getBean(DnsPlateformCompareConfig.class);
		String finalPlate = plateformCompare.getPlateform(service);
		service = finalPlate == null?service:finalPlate;
		RemoteService remoteService = feignClients.target(service);
    	return remoteService;
	}
	
}
