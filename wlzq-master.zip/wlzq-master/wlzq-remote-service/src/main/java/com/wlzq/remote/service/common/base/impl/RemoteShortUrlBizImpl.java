package com.wlzq.remote.service.common.base.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.base.ShortUrlBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

@Service
public class RemoteShortUrlBizImpl implements ShortUrlBiz {


	@Override
	public StatusObjDto<String> shortenNew(String url) {
		if(ObjectUtils.isEmptyOrNull(url)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("url");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("url", url);
		ResultDto result =  RemoteUtils.call("base.shortcooperation.shortennew",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<String>(false,result.getCode(),result.getMsg());
		}
		String urlShort = String.valueOf(result.getData().get("urlShort"));
		return new StatusObjDto<String>(true,urlShort,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<String> originalUrl(String url) {
		if(ObjectUtils.isEmptyOrNull(url)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("url");
		}
		
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("url", url);
		ResultDto result =  RemoteUtils.call("base.shortcooperation.originalurl",ApiServiceTypeEnum.COOPERATION,busparams,true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return new StatusObjDto<String>(false,result.getCode(),result.getMsg());
		}
		String originalUrl = String.valueOf(result.getData().get("originalUrl"));		
		return new StatusObjDto<String>(true,originalUrl,StatusDto.SUCCESS,"");
	}

}
