package com.wlzq.remote.service.common.account.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.model.account.Staff;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RegxUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.remote.service.common.account.StaffBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * 远程StaffBiz实现类
 * @author 
 * @version 1.0
 */
@Service
public class RemoteStaffBizImpl  implements StaffBiz{

	public StatusObjDto<Staff> infoByMobile(String mobile) {
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return new StatusObjDto<Staff>(false,1,"mobile参数不能为空"); 
		}
		if(!RegxUtils.isMobile(mobile)){
			return new StatusObjDto<Staff>(false, 1,"请输入正确的手机号"); 
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("mobile", mobile);
    	Staff staff = RemoteUtils.callReturnEntity("account.staffcooperation.findbymobile",ApiServiceTypeEnum.COOPERATION, 
    			busparams, Staff.class,false);
		if(staff == null) {
			return new StatusObjDto<Staff>(false, "员工不存在");
		}
		
		return new StatusObjDto<Staff>(true, staff,0, ""); 
	}

	public StatusObjDto<Staff> infoByShareCode(String shareCode) {
		if(ObjectUtils.isEmptyOrNull(shareCode)) {
			return new StatusObjDto<Staff>(false,1,"mobile参数不能为空"); 
		}
		
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("shareCode", shareCode);
    	Staff staff = RemoteUtils.callReturnEntity("account.staffcooperation.findbysharecode",ApiServiceTypeEnum.COOPERATION, 
    			busparams, Staff.class,false);
		if(staff == null) {
			return new StatusObjDto<Staff>(false, "员工不存在");
		}
		
		return new StatusObjDto<Staff>(true, staff,0, ""); 
	}
	
}
