package com.wlzq.remote.service.common.label;

import lombok.Getter;

/**
 *         "wl00103": "所属营业部名称",
 *         "wl00102": "客户性别",
 *         "wl00101": "客户名称",
 *         "wl00104": "年龄"
 * @author luohc
 * @date 2021/10/26 15:47
 */
@Getter
public enum LabelEnum {
    CUSTOMER_NAME("wl00101","客户名称"),
    CUSTOMER_GENDER("wl00102","客户性别"),
    CUSTOMER_OPEN_DATE("x2010002","客户开户日期"),

    ;

    String labelName;
    String labelDesc;

    LabelEnum(String labelName,String labelDesc) {
        this.labelName = labelName;
        this.labelDesc = labelDesc;
    }




}
