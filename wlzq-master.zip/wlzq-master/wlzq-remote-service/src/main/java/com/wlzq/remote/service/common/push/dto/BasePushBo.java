package com.wlzq.remote.service.common.push.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author luohc
 * @date 2021/6/28 14:08
 */
@Data
public class BasePushBo implements Serializable {
    /** 日期时间 */
    private String dateTimeStr;
}
