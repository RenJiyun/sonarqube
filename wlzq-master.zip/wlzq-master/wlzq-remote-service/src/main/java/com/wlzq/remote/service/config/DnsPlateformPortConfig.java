package com.wlzq.remote.service.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource(value= {"file:${E:/dnsplat/dnsplatport.properties}"}, ignoreResourceNotFound=true)
@ConfigurationProperties(prefix="plat")
public class DnsPlateformPortConfig {
	/**
	 * 平台配置，key:平台名,value:端口 
	 */
    private Map<String, String> port = new HashMap<String,String>(); //接收plateform里面的属性  

	public Map<String, String> getPort() {
		return port;
	}

	public void setPort(Map<String, String> port) {
		this.port = port;
	}

	public String getPort(String name) {
		return this.port.get(name);
	}
}
