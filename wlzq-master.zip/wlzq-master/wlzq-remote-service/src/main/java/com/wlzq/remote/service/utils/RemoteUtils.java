package com.wlzq.remote.service.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import com.wlzq.common.RequestId;
import com.wlzq.common.model.chinaclear.ChinaClearRequest;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.RequestParams;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.core.global.ThreadGlobal;
import com.wlzq.core.signature.AppSignatureMd5;
import com.wlzq.remote.service.RemoteService;
import com.wlzq.remote.service.config.AppConfig;
import com.wlzq.remote.service.factory.RemoteServiceFactory;
import com.wlzq.service.base.sys.utils.TerminalUtils;

public class RemoteUtils {
	/**
	 * 微服务间调用
	 * @param method
	 * @param serviceType
	 * @param busparams 
	 * @param resultClass
	 * @param needSign
	 * @return
	 */
	public static <T> T  callReturnEntity(String method,ApiServiceTypeEnum serviceType,Map<String, Object> busparams,Class<T> resultClass,boolean needSign) {
    	String plateform = method.substring(0,method.indexOf("."));
    	String service = method.substring(0,method.lastIndexOf("."));
    	String methodCall = method.substring(method.lastIndexOf(".")+1);
		RemoteService remoteService = RemoteServiceFactory.getRemoteService(plateform);
    	if(remoteService == null) {
    		throw BizException.SERVICE_NONE_EXIST;
    	}
    	AppConfig config = SpringApplicationContext.getBean(AppConfig.class);
    	RequestParams params = new RequestParams();
    	params.setKey(config.getKey());
    	params.setMethod(methodCall);
    	params.setPlateform(plateform);
    	params.setService(service);
		params.setParams(busparams);
		params.setServiceType(serviceType);
		String clientIp = busparams.get("clientIp") == null?"":(String)busparams.get("clientIp");
		params.setClientIp(clientIp);
    	RequestId requestId =  ThreadGlobal.reqestId.get();
    	if(requestId != null) {
    		params.setRequestId(requestId.getRequestId());
    		params.setRequestOrder(requestId.getRequestOrder());
    		params.setClientIp(requestId.getClientIp());
    		params.setClietPort(requestId.getClientPort());
    		params.setToken(requestId.getToken());
    		params.setCustToken(requestId.getCustToken());
    	}
		if(needSign) {
			Map<String,Object> sysParams = BeanUtils.beanToMap(params);
			sysParams.put("params", JsonUtils.map2Json(busparams));
			params.setSysParams(sysParams);
			Map<String,String> signParams = BeanUtils.beanToStrMap(sysParams);
			
			AppSignatureMd5 md5 = new AppSignatureMd5(config.getSecret(),signParams);
			md5.addIgnoreSignParam("nickname");
			md5.addIgnoreSignParam("k");
			md5.addIgnoreSignParam("device");
			md5.addIgnoreSignParam("custtoken");
			String sign = md5.sign();
			params.setNoncestr(sign);
		}
    	
		ResultDto result = remoteService.call(params); 
		if(!result.getCode().equals(0)) {
			return null;
		}
		T returnObj = BeanUtils.mapToBean(result.getData(), resultClass);
		return returnObj;
	}
	
	/**
	 * 微服务间调用
	 * @param method
	 * @param serviceType
	 * @param busparams  
	 * @param needSign
	 * @return
	 */
	public static ResultDto  call(String method,ApiServiceTypeEnum serviceType,Map<String, Object> busparams,boolean needSign) {
    	String plateform = method.substring(0,method.indexOf("."));
    	String service = method.substring(0,method.lastIndexOf("."));
    	String methodCall = method.substring(method.lastIndexOf(".")+1);
		RemoteService remoteService = RemoteServiceFactory.getRemoteService(plateform);
    	if(remoteService == null) {
    		throw BizException.SERVICE_NONE_EXIST;
    	}

    	AppConfig config = SpringApplicationContext.getBean(AppConfig.class);
    	RequestParams params = new RequestParams();
    	params.setKey(config.getKey());
    	params.setMethod(methodCall);
    	params.setPlateform(plateform);
    	params.setService(service);
		params.setParams(busparams);
		params.setServiceType(serviceType);
		//容器环境下获取宿主机IP
		params.setServerClientIp(System.getenv("HOST_IP"));
		//若容器环境下获取不到宿主机IP
    	if(ObjectUtils.isEmptyOrNull(params.getServerClientIp())) {
    		try {
    			InetAddress address = InetAddress.getLocalHost();
    			params.setServerClientIp(address.getHostAddress());
    		} catch (UnknownHostException e) {
    		}
    	}
		String clientIp = busparams.get("clientIp") == null?"":(String)busparams.get("clientIp");
		params.setClientIp(clientIp);
    	RequestId requestId = ThreadGlobal.reqestId.get();
    	if(requestId != null) {
    		params.setRequestId(requestId.getRequestId());
    		params.setRequestOrder(requestId.getRequestOrder());
    		params.setClientIp(requestId.getClientIp());   
    		params.setClietPort(requestId.getClientPort());
    		params.setToken(requestId.getToken());
    		params.setCustToken(requestId.getCustToken());
    	}
		if(needSign) {
			Map<String,Object> sysParams = BeanUtils.beanToMap(params);
			sysParams.put("params", JsonUtils.map2Json(busparams));
			params.setSysParams(sysParams);
			Map<String,String> signParams = BeanUtils.beanToStrMap(sysParams);
			
			AppSignatureMd5 md5 = new AppSignatureMd5(config.getSecret(),signParams);
			md5.addIgnoreSignParam("nickname");
			md5.addIgnoreSignParam("k");
			md5.addIgnoreSignParam("device");
			md5.addIgnoreSignParam("custtoken");
			String sign = md5.sign();
			params.setNoncestr(sign);
		}
		
		ResultDto result = remoteService.call(params); 
		
		return result;
	}
	
	/**
	 * T2网关调用
	 * @param busparams  
	 * @param needSign
	 * @return
	 */
	public static ResultDto  t2call(Map<String, Object> busparams) {
		String method = "t2gateway.function.request";
		if(ObjectUtils.isEmptyOrNull(busparams.get("op_station"))) {
			String opStation = TerminalUtils.getOpStation();
			busparams.put("op_station", opStation);
		}
		return call(method,ApiServiceTypeEnum.COOPERATION,busparams,true);
	}

	/**
	 * 中登网关调用
	 * @param busparams  
	 * @param needSign
	 * @return
	 */
	public static ResultDto  chinaClearCall(ChinaClearRequest chnclrRequest) {
		if(chnclrRequest == null || ObjectUtils.isEmptyOrNull(chnclrRequest.getServiceName()) ||
				ObjectUtils.isEmptyOrNull(chnclrRequest.getServiceType())) {
			return new ResultDto(StatusDto.FAIL_COMMON,"参数缺失");
		}
		String method = "chinaclear.service.request";
		Map<String, Object> params = new HashMap<String,Object>();
		params.put("method", method);
		Map<String, Object> busparams = new HashMap<String, Object>();
		busparams.put("request", chnclrRequest);
		params.put("params", JsonUtils.map2Json(busparams));

		return call(method,ApiServiceTypeEnum.COOPERATION,busparams,true);
	}
	
	/**
	 * 微服务间调用
	 * @param method
	 * @param serviceType
	 * @param busparams  
	 * @param attachSysParams 
	 * @param needSign
	 * @return
	 */
	public static ResultDto  call(String method,ApiServiceTypeEnum serviceType,Map<String, Object> busparams,Map<String, Object> attachSysParams,boolean needSign) {
    	String plateform = method.substring(0,method.indexOf("."));
    	String service = method.substring(0,method.lastIndexOf("."));
    	String methodCall = method.substring(method.lastIndexOf(".")+1);
		RemoteService remoteService = RemoteServiceFactory.getRemoteService(plateform);
    	if(remoteService == null) {
    		throw BizException.SERVICE_NONE_EXIST;
    	}

    	AppConfig config = SpringApplicationContext.getBean(AppConfig.class);
    	RequestParams params = new RequestParams();
    	params.setKey(config.getKey());
    	params.setMethod(methodCall);
    	params.setPlateform(plateform);
    	params.setService(service);
		params.setParams(busparams);
		params.setServiceType(serviceType);
    	RequestId requestId = ThreadGlobal.reqestId.get();
    	if(requestId != null) {
    		params.setRequestId(requestId.getRequestId());
    		params.setRequestOrder(requestId.getRequestOrder());
    		params.setClientIp(requestId.getClientIp());
    		params.setClietPort(requestId.getClientPort());
    		params.setToken(requestId.getToken());
    		params.setCustToken(requestId.getCustToken());
    	}
		if(needSign) {
			Map<String,Object> sysParams = BeanUtils.beanToMap(params);
			if(attachSysParams != null) {
				sysParams.putAll(attachSysParams);
			}
			sysParams.put("params", JsonUtils.map2Json(busparams));
			params.setSysParams(sysParams);
			if(ObjectUtils.isEmptyOrNull(params.getClientIp())) {
				String clientIp = sysParams.get("clientIp") == null?"":(String)sysParams.get("clientIp");
				params.setClientIp(clientIp);
			}
			Map<String,String> signParams = BeanUtils.beanToStrMap(sysParams);
			
			AppSignatureMd5 md5 = new AppSignatureMd5(config.getSecret(),signParams);
			md5.addIgnoreSignParam("nickname");
			md5.addIgnoreSignParam("k");
			md5.addIgnoreSignParam("device");
			md5.addIgnoreSignParam("custtoken");
			String sign = md5.sign();
			params.setNoncestr(sign);
		}
		
		ResultDto result = remoteService.call(params); 
		
		return result;
	}


	public static class ParamsBuilder {
		private final Map<String, Object> params = new HashMap<String, Object>();
		public ParamsBuilder put(String paramName, Object paramValue) {
			params.put(paramName, paramValue);
			return this;
		}

		public Map<String, Object> build() {
			return params;
		}
	}

	public static ParamsBuilder newParamsBuilder() {
		return new ParamsBuilder();
	}

}
