package com.wlzq.remote.service.common.account.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.google.common.collect.Maps;
import com.wlzq.common.model.account.AccMsg;
import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.remote.service.common.account.AccMsgBiz;
import com.wlzq.remote.service.utils.RemoteUtils;

@Service
public class RemoteAccMsgBizImpl implements AccMsgBiz {

	@Override
	public StatusObjDto<List<AccMsg>> msgList(String userId, String customerId, String staffno, Integer buziType,
			String buziTag, Integer status, Integer pageIndex, Integer pageSize) {
		if (ObjectUtils.isEmptyOrNull(buziType)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format(buziType);
		}
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("userId", userId);
		busparams.put("customerId", customerId);
		busparams.put("staffno", staffno);
		busparams.put("buziTag", buziTag);
		busparams.put("status", status);
		busparams.put("buziType", buziType);
		busparams.put("pageIndex", pageIndex);
		busparams.put("pageSize", pageSize);
		ResultDto result = RemoteUtils.call("account.msgcooperation.msglist",ApiServiceTypeEnum.COOPERATION,busparams, true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return  new StatusObjDto<>(false,result.getCode(),result.getMsg());
		}
		@SuppressWarnings("unchecked")
		List<Map<String,Object>> resultMap = (List<Map<String,Object>>) result.getData().get("info");
		List<AccMsg> dto = BeanUtils.toBeanList(resultMap, AccMsg.class);
		return new  StatusObjDto<>(true,dto,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<AccMsg> readMsg(String serial, String userId, String customerId, String staffno) {
		if (ObjectUtils.isEmptyOrNull(serial)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format("serial");
		}
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("serial", serial);
		busparams.put("userId", userId);
		busparams.put("customerId", customerId);
		busparams.put("staffno", staffno);
		ResultDto result = RemoteUtils.call("account.msgcooperation.readmsg",ApiServiceTypeEnum.COOPERATION,busparams, true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return  new StatusObjDto<>(false,result.getCode(),result.getMsg());
		}
		AccMsg dto = BeanUtils.mapToBean(result.getData(), AccMsg.class);
		return new  StatusObjDto<>(true,dto,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<Integer> msgCount(String userId, String customerId, String staffno, Integer buziType,
			String buziTag, Integer status) {
		if (ObjectUtils.isEmptyOrNull(buziType)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format(buziType);
		}
		Map<String, Object> busparams = Maps.newHashMap();
		busparams.put("userId", userId);
		busparams.put("customerId", customerId);
		busparams.put("staffno", staffno);
		busparams.put("buziTag", buziTag);
		busparams.put("status", status);
		busparams.put("buziType", buziType);
		ResultDto result = RemoteUtils.call("account.msgcooperation.msgcount",ApiServiceTypeEnum.COOPERATION,busparams, true);
		if(!result.getCode().equals(ResultDto.SUCCESS)) {
			return  new StatusObjDto<>(false,result.getCode(),result.getMsg());
		}
		Map<String,Object> resultMap = (Map<String,Object>) result.getData();
		Integer count = (Integer)resultMap.get("msgCount");
		return new  StatusObjDto<>(true,count,StatusDto.SUCCESS,"");
	}

}
