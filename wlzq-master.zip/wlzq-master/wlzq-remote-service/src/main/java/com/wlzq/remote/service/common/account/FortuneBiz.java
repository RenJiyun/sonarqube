
package com.wlzq.remote.service.common.account;

import com.wlzq.common.model.account.FortuneInfo;

/**
 *  FortuneBiz类
 * @author 
 * @version 1.0
 */
public interface FortuneBiz {	
	
	/**
	 * 授权财富账号信息
	 * @param busKey 应用key
	 * @param authToken 授权token
	 * @return
	 */
	FortuneInfo fortuneInfoByAuth(String busKey,String authToken);

}
