package com.wlzq.remote.service.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.common.utils.MD5Util;
import org.apache.commons.lang3.StringUtils;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/**
 * @author luohc
 * @date 2021/8/4 15:14
 */
public class TestUtil {

    //环境切换
    public static String host = "http://127.0.0.1:8081/api/cooperate?";

    //js，测试前端接口APP的时候用这个 , 这个不要配置具体的方法。
    static String k = "js6rFh3MYMnyE8IF9E";
    static String secret = "mkjhO3kZgZAf2VYlFgic7ezXfjNvn1BF5lmRMi3d";

    //外部，例如给同花顺的那些接口
//    static String k = "flkti1ud10zabkurpz";
//    static String secret = "1m7tmhj4xbyusi6rbeg575h8ahapj67bd3uasdqz";

    //外部绩牛
//    static String k = "1cyd61ya7zw2nh6npc";
//    static String secret = "cd7g0n482e0kfdfre3bcbf3mjq1wsc67lq61r0rg";


    public static String test(String method, Object obj){
        return test(method, obj,"","");
    }
    public static String test(String method, Object obj, String token){
        return test(method, obj,token,"");
    }
    public static String test(String method, Object obj, String token, String custtoken){
        if (obj instanceof JSONObject) {
            return doTest(method,((JSONObject)obj).toJSONString(),token,custtoken);
        }else if(obj instanceof String){
            return doTest(method,(String)obj,token,custtoken);
        }else{
            return doTest(method, JSON.toJSONString(obj),token,custtoken);
        }
    }

    private static String doTest(String method, String json, String token, String custtoken){
        String encodeJson;
        try {
            encodeJson = URLEncoder.encode(json, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }

        String md5 = "method=" + method + "&params="+json;
        String url = host + "method=" + method + "&params="+encodeJson + "&k="+ k ;

        if (StringUtils.isNotBlank(token)) {
            url = url +"&token="+token;
            md5 = md5 +"&token="+token;
        }
        if (StringUtils.isNotBlank(custtoken)) {
            url = url+"&custtoken="+custtoken;
//            要看看有没有 custtoken不参与签名标志配置。
//            md5 = md5 +"&custtoken="+token;
        }

        String noncestr = MD5Util.md5(md5+secret);
        url = url + "&noncestr="+ noncestr;

        String s = HttpClientUtils.doGet(url, null);
        System.out.println(s);
        return s;
    }



}
