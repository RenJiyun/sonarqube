package com.wlzq.remote.service.factory;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:plat.properties"}) 
@ConfigurationProperties(prefix="plateform")
public class PlateForms {
	public final static String ACCOUNT = "account";
	public final static String BASE = "base";
	/**
	 * 平台配置，key:平台名,value:类 
	 */
    private Map<String, String> service = new HashMap<String,String>(); //接收plateform里面的属性值  
	
	public Map<String, String> getService() {
		return service;
	}

	public void setService(Map<String, String> service) {
		this.service = service;
	}

	public String getPlateForm(String name) {
		return this.service.get(name);
	}
}
