package com.wlzq.remote.service.common.account.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.model.account.FortuneInfo;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.remote.service.common.account.FortuneBiz;
import com.wlzq.remote.service.utils.RemoteUtils;
/**
 * 远程FortuneBiz实现类
 * @author 	
 * @version 1.0
 */
@Service
public class RemoteFortuneBizImpl  implements FortuneBiz{
	
	@Override
	public FortuneInfo fortuneInfoByAuth(String busKey, String authToken) {
		if(ObjectUtils.isEmptyOrNull(busKey)) {
			return null; 
		}
		if(ObjectUtils.isEmptyOrNull(authToken)) {
			return null; 
		}
		Map<String, Object> busparams = new HashMap<String, Object>();
    	busparams.put("busKey", busKey);
    	busparams.put("authToken", authToken);
    	FortuneInfo fortuneAccount = RemoteUtils.callReturnEntity("account.authcooperation.fortuneinfobyauthtoken",ApiServiceTypeEnum.COOPERATION, busparams,FortuneInfo.class,true);
		return fortuneAccount;
	}

}
