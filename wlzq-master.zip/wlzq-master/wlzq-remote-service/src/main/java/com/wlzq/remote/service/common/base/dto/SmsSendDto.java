package com.wlzq.remote.service.common.base.dto;

import lombok.Data;
import lombok.experimental.Accessors;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * 
 * @author luohc
 * @date 2021/12/3 17:20
 */
@Data
@Accessors(chain = true)
public class SmsSendDto implements Serializable {
    /** 短信类型 1 生产类型（如短信验证码）  2营销类型 */
    public static final Integer MSG_CATEGORY_PRODUCT = 1;
    public static final Integer MSG_CATEGORY_SALE = 2;


    /** 短信模板编码 */
    @NotBlank
    private String templateCode;

    /** 支持多个手机号,英文逗号分割 */
    @NotBlank
    private String mobile;

    /** 短信模板字符串的参数。 如 {"productName":"万山红","couponName":"7天免单券"} */
    private String jsonParam;


    /** 非必填 ，短信类型 1 生产类型（如短信验证码） 2营销类型 */
    private Integer msgCategory;
    /** 非必填 ，是否异步发送。 1是 0 否 */
    private Integer async;


}
