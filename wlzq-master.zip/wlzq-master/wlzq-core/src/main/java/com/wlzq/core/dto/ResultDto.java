package com.wlzq.core.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wlzq.common.model.sys.Cookiee;

/**
 * 返回前端dto
 * 
 * @author 
 * @date 2017年8月4日
 * @version 
 */
public class ResultDto implements Serializable {
	public static Integer OUTPUT_JSON = 1; //输出json
	public static Integer OUTPUT_TEXT = 2; //输出文本
	public static Integer OUTPUT_IMAGE = 3; //输出图片
	public static Integer OUTPUT_REDIRECT = 4; //跳转
	
	private static final long serialVersionUID = 384046422772205122L;
	public static Integer SUCCESS = 0;
	public static Integer FAIL_COMMON = 1;
	/** 结果编码  0:成功，其它：失败*/
	private Integer code;
	/** 数据 */
	private Map<String,Object> data;
	/** 结果文本提示 */
	private String msg;
	
	/** http响应头内容 */
	private Map<String, String> responseHeaders = new HashMap<String, String>();
	
	/** 输出内容 ，1：json,2:文字，3：图片*/
	private Integer outPutType = 1;
	
	private byte[] imageBytes;
	
	private String outputText;
	
	private Map<String,String> cookies;
	private List<Cookiee> cookiees;
	
	private String userId;

	private String mobile;
	
	private String customerId;
	
	private int spend;  //处理耗时（ms）
	
	public ResultDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResultDto(Integer code) {
		this(code, new HashMap<String,Object>(), "");
	}
	
	public ResultDto(Integer code, String msg) {
		this(code,  new HashMap<String,Object>(), msg);
	}
	
	public ResultDto(Integer code,Map<String,Object> data, String msg) {
		this.code = code;
		this.data = data;
		this.msg = msg;
	}

	/** 结果编码 */
	public Integer getCode() {
		return code;
	}

	/** 结果编码 */
	public void setCode(Integer code) {
		this.code = code;
	}
	
	public Map<String,Object> getData() {
		return data;
	}

	public void setData(Map<String,Object> data) {
		this.data = data;
	}

	/** 结果文本提示 */
	public String getMsg() {
		return msg;
	}

	/** 结果文本提示 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Map<String, String> getResponseHeaders() {
		return responseHeaders;
	}

	public void setResponseHeaders(Map<String, String> responseHeaders) {
		this.responseHeaders = responseHeaders;
	}

	public String getOutputText() {
		return outputText;
	}

	public void setOutputText(String outputText) {
		this.outputText = outputText;
	}

	public Integer getOutPutType() {
		return outPutType;
	}

	public void setOutPutType(Integer outPutType) {
		this.outPutType = outPutType;
	}

	public byte[] getImageBytes() {
		return imageBytes;
	}

	public void setImageBytes(byte[] imageBytes) {
		this.imageBytes = imageBytes;
	}

	public Map<String, String> getCookies() {
		return cookies;
	}

	public void setCookies(Map<String, String> cookies) {
		this.cookies = cookies;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public List<Cookiee> getCookiees() {
		return cookiees;
	}

	public void setCookiees(List<Cookiee> cookiees) {
		this.cookiees = cookiees;
	}

	public int getSpend() {
		return spend;
	}

	public void setSpend(int spend) {
		this.spend = spend;
	}

}
