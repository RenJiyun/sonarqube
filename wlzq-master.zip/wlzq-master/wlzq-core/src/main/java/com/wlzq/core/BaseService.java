package com.wlzq.core;

import com.wlzq.common.constant.ClientTypeConstant;
import com.wlzq.common.constant.DeviceTypeConstant;
import com.wlzq.common.utils.ObjectUtils;

public class BaseService {
	
	public int[] buildPage(RequestParams params) {
		Integer pageIndex = ObjectUtils.isEmptyOrNull(params.getString("pageIndex")) ? 1 : Integer.valueOf(params.getString("pageIndex"));
		Integer pageSize = ObjectUtils.isEmptyOrNull(params.getString("pageSize")) ? 5 : Integer.valueOf(params.getString("pageSize"));
		int[] page = buildPage(pageIndex,pageSize);
		return page;
	}

	public Page buildPageNew(RequestParams params) {
		Integer pageIndex = ObjectUtils.isEmptyOrNull(params.getString("pageIndex")) ? 1 : Integer.valueOf(params.getString("pageIndex"));
		Integer pageSize = ObjectUtils.isEmptyOrNull(params.getString("pageSize")) ? 5 : Integer.valueOf(params.getString("pageSize"));
		int[] page = buildPage(pageIndex,pageSize);
		Page pageInfo = new Page(page[0],page[1]);
		if(pageIndex != null) {
			pageInfo.setPageIndex(pageIndex);
		}
		if(pageSize != null) {
			pageInfo.setPageSize(pageSize);
		}
		
		return pageInfo;
	}
	
    public  int[] buildPage(Integer pageIndex, Integer pageSize) {
		pageIndex = pageIndex == null || pageIndex <= 0 ? 1 : pageIndex;
		pageSize = pageSize == null || pageSize <= 0 ? 5 : pageSize;

		int rowStart = (pageIndex - 1) * pageSize;

		int rowEnd = 1;
		if (rowStart == 0) {
			if (pageSize - Integer.MAX_VALUE == 0) {
				rowEnd = pageSize;
			} else {
				rowEnd = pageSize;
			}

		} else {
			rowEnd = rowStart + pageSize;
		}

		return new int[] { rowStart, rowEnd };
	}

    /**
     * 通过客户的agent来判断是微信用户还是app用户
     * @param params
     * @return
     */
    public Integer getCientType(RequestParams params) {
		Integer deviceType = params.getDeviceType();
    	Integer visibleType = null;
    	if (deviceType != null && deviceType.equals(DeviceTypeConstant.WX)) {
    		visibleType = ClientTypeConstant.WECHAT;
		} else if (deviceType != null && (deviceType.equals(DeviceTypeConstant.IOS) || deviceType.equals(DeviceTypeConstant.APK))) {
			visibleType = ClientTypeConstant.APP;
		}else {
			visibleType = ClientTypeConstant.H5;
		}
    	return visibleType;
    }
}

