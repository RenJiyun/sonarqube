package com.wlzq.core.exception;

import java.lang.reflect.Constructor;
import java.text.MessageFormat;

/**
 * 业务异常
 * 用途：用于在处理业务时，向框架抛出异常，框架将该异常作为错误信息进行输出。
 * 
 *
 * code rule：{2}{2}{4}
 *            |  |  |  
 *           plate |  |
 *            module|
 *                error
 * 如：[10020001]前四位数为平台+模块编号，后4位为错误代码
 * 10 - 账户平台
 * 20 - 基础平台
 * 30 - 活动平台
 * 40 - 微信平台
 * 50 - 支付平台
 * 60 - 投顾平台
 * 70 - 理财平台
 * 71 - 理财数据平台
 * 72 - 基金投顾平台
 * 80 - 业务办理
 * 90 - 营销平台
 * 91 - 资讯平台
 * 92 - 消息弹框
 * 62 - 增值服务
 * 9999 - 系统、框架级异常
 * 
 * @author 
 * @date 
 */
public class BizException extends RuntimeException {
	private static final long serialVersionUID = 3254766587686L;
	/** 未登录 */
	public static final BizException NOT_LOGIN_ERROR = new BizException(1000001, "未登录");
	/** 思迪未登录 */
	public static final BizException SD_NOT_LOGIN_ERROR = new BizException(1000002, "客户未登录");
	/** 未登录 */
	public static final BizException CUSTOMER_NOT_LOGIN_ERROR = new BizException(1000002, "客户未登录");
	/** 未绑定手机号  */
	public static final BizException USER_NOT_BIND_MOBILE = new BizException(10000003,"未绑定手机号");
	/** 未登录 */
	public static final BizException STAFF_NOT_LOGIN_ERROR = new BizException(1000003, "员工未登录");
	/** 微信未授权登录  */
	public static final BizException WECHAT_NOT_AUTO_LOGIN = new BizException(10000004,"微信未授权登录");
	/** 用户未实名  */
	public static final BizException USER_NOT_IDENTIFIED = new BizException(10000005,"用户未实名");
	
	/** 机构户或产品户*/
	public static final BizException CUSTOMER_NOT_PERSON = new BizException(1000033, "非个人客户暂不参与");
	/** 风险测评已过期*/
	public static final BizException CUSTOMER_RISK_LEVEL_EXPIRE = new BizException(1000003, "风险测评已过期");
	/** 风险测评不匹配*/
	public static final BizException CUSTOMER_RISK_LEVEL_NOT_MATCH = new BizException(1000004, "风险测评不匹配");
	/** 身份证已过期*/
	public static final BizException CUSTOMER_ID_IS_EXPIRE = new BizException(1000005, "身份证已过期");
	/** 签名失败 */
	public static final BizException SIGN_ERROR = new BizException(99990001, "");
	/** 公共自定义异常提示 */
	public static final BizException COMMON_CUSTOMIZE_ERROR = new BizException(99990002, "{0}");
	/** 无权限 */
	public static final BizException NO_AUTH = new BizException(99990003, "无权限");
	/**  服务不存在*/
	public static final BizException SERVICE_NONE_EXIST = new BizException(99990004, "服务不存在");
	/** 应用不存在 */
	public static final BizException APP_NONE_EXIST = new BizException(99990005, "应用不存在");
	/** 非法访问 */
	public static final BizException ILLEGAL_ACCESS = new BizException(99990006, "非法访问");
	/** 参数为空异常 */
	public static final BizException COMMON_PARAMS_NOT_NULL = new BizException(99990007, "参数{0}不能为空");
	/** 参数非法 */
	public static final BizException COMMON_PARAMS_IS_ILLICIT = new BizException(99990008, "参数{0}非法");
	/** 网络异常 */
	public static final BizException NETWORK_ERROR = new BizException(99990009, "网络异常");
	/** 创建业务异常新实例失败 */
	public static final BizException NEW_EXCEPTION_INSTANCE_FAILED = new BizException(99990010, "网络异常");
	/** 验证码错误 */
	public static final BizException COMMON_VERIFY_CODE_WRONG = new BizException(99990011, "验证码错误");
	/** 流水号对应签约记录不存在 */
	public static final BizException AGREEMENT_SIGNRECORD_NOT_EXIT = new BizException(99990012, "签约记录不存在");
	protected int code;
	protected String msg;

	/***
	 * 以后请不是使用该方法。
	 * 
	 * @param code
	 * @param msg
	 */
	protected BizException(int code, String msg) {
		this(code, msg, code != 0);
	}

	protected BizException(int code, String msg, boolean isRollback) {
		super(msg);
		this.code = code;
		this.msg = msg == null ? "" : msg;
	}

	/***
	 * 格式话消息.
	 * 
	 * @param args
	 * @return
	 */
	public BizException format(Object... args) {
		return this.newInstance( MessageFormat.format(this.msg, args));
	}

	public BizException newInstance(String msg) {
		try {
			Class<?> clazz = this.getClass();
			Constructor<?> constructor;
			constructor = clazz.getDeclaredConstructor(new Class[] { int.class, String.class });
			constructor.setAccessible(true);
			BizException be;
			be = (BizException) constructor.newInstance(this.code, msg);
			return be;
		} catch (Exception e) {
			throw BizException.NEW_EXCEPTION_INSTANCE_FAILED.newInstance("创建业务异常新实例失败" + e.toString());
		}
	}

	/**
	 * 获取状态吗
	 * 
	 * @return
	 */
	public int getCode() {
		return code;
	}

	/**
	 * 获取中文信息
	 * 
	 * @return
	 */
	public String getMsg() {
		return this.msg;
	}

	@Override
	public String toString() {
		return String.format("业务异常=%s, code=%s, msg=%s", this.getClass().getSimpleName(), this.code,
				this.msg);
	}
}
