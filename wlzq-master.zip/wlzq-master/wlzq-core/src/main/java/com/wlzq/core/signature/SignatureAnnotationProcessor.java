package com.wlzq.core.signature;

import java.lang.reflect.Method;

import com.wlzq.core.annotation.Signature;
import com.wlzq.core.annotation.TokenIgnoreSignature;

/**
 * 
 * @author 
 *
 */
public class SignatureAnnotationProcessor {

	private Object service;
	private Method method;

	public SignatureAnnotationProcessor(Object service, Method method) {
		this.service = service;
		this.method = method;
	}

	public boolean mustSign() {
		if (service == null || method == null) {
			throw new RuntimeException("请求错误");
		}
		Signature signAnnotation = getSignatureAnnotation();
		if (signAnnotation == null) {
			return false;
		}
		return signAnnotation.value();
	}

	public boolean tokenIgnoreSign() {
		if (service == null || method == null) {
			throw new RuntimeException("请求错误");
		}
		TokenIgnoreSignature tokenIgnoreAnnotation = getSignatureTokenIgnoreAnnotation();
		if (tokenIgnoreAnnotation == null) {
			return false;
		}
		return tokenIgnoreAnnotation.value();
	}
	
	private Signature getSignatureAnnotation() {
		Signature result = null;
		if (method != null) {
			result = method.getAnnotation(Signature.class);
		}
		if (result == null) {
			result = service.getClass().getAnnotation(Signature.class);
		}
		return result;
	}

	private TokenIgnoreSignature getSignatureTokenIgnoreAnnotation() {
		TokenIgnoreSignature result = null;
		if (method != null) {
			result = method.getAnnotation(TokenIgnoreSignature.class);
		}
		if (result == null) {
			result = service.getClass().getAnnotation(TokenIgnoreSignature.class);
		}
		return result;
	}
}
