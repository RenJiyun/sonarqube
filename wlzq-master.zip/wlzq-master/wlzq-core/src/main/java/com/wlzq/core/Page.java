package com.wlzq.core;

import com.wlzq.common.utils.ObjectUtils;

public class Page {
	private int pageSize;
	private int pageIndex;
	private int start;
	private int end;
	
	public Page(int start, int end) {
		super();
		this.start = start;
		this.end = end;
	}
	
	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageIndex() {
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}

	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getEnd() {
		return end;
	}
	public void setEnd(int end) {
		this.end = end;
	}

	public static Page buildPageNew(Integer pageIndex,Integer pageSize) {
		pageIndex = ObjectUtils.isEmptyOrNull(pageIndex) ? 1 : Integer.valueOf(pageIndex);
		pageSize = ObjectUtils.isEmptyOrNull(pageSize) ? 5 : Integer.valueOf(pageSize);
		int[] page = buildPage(pageIndex,pageSize);
		Page pageInfo = new Page(page[0],page[1]);
		if(pageIndex != null) {
			pageInfo.setPageIndex(pageIndex);
		}
		if(pageSize != null) {
			pageInfo.setPageSize(pageSize);
		}
		
		return pageInfo;
	}
	
	public static  int[] buildPage(Integer pageIndex, Integer pageSize) {
		pageIndex = pageIndex == null || pageIndex <= 0 ? 1 : pageIndex;
		pageSize = pageSize == null || pageSize <= 0 ? 5 : pageSize;

		int rowStart = (pageIndex - 1) * pageSize;

		int rowEnd = 1;
		if (rowStart == 0) {
			if (pageSize - Integer.MAX_VALUE == 0) {
				rowEnd = pageSize;
			} else {
				rowEnd = pageSize;
			}

		} else {
			rowEnd = rowStart + pageSize;
		}

		return new int[] { rowStart, rowEnd };
	}
}
