package com.wlzq.core.exception;

import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RegxUtils;

public class BizAssert {
	public static void isEmptyOrNull(Object value,String name) {
		if(ObjectUtils.isEmptyOrNull(value)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format(name);
		}
	}
	
	public static void isMobile(String value,String name) {
		if(ObjectUtils.isEmptyOrNull(value)) {
			throw BizException.COMMON_PARAMS_NOT_NULL.format(name);
		}
		if(!RegxUtils.isMobile(value)) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("手机号非法");
		}
	}
}
