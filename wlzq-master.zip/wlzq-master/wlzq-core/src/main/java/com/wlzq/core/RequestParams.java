package com.wlzq.core;

import java.util.HashMap;
import java.util.Map;

import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.annotation.ApiServiceTypeEnum;

public class RequestParams implements Cloneable {
	//请求ID，标识一次请求
	private String requestId;
	//请求顺序
	private Integer requestOrder;
	
	private String service;
	
	private String method;
	
	private String plateform;
	
	private ApiServiceTypeEnum serviceType;
	
	private String key;
	
	private String noncestr; //签名串
	
	private String clientIp; //前端IP
	private Integer clietPort; //前端端口


	private String serverClientIp; //内部调用客户端IP
	
	private byte[] inputBytes;
	
	private Map<String,Object> params;

	private Map<String,String> cookieParams;
	
	private Map<String,Object> sysParams;

	private Integer deviceType; //设备类型，1：IOS,2: 安卓，3： 微信，4：pc

	private String device; //手机型号+"||"+序列号

	private Integer system; //系统类型，1：IOS，2：安卓

	private String version; //客户端版本号
	
	private String token; //用户token
	
	private String custToken; //客户token
	
	private String wlzqstatId; //
	
	/** 其他自定义参数 */
	private Map<String, Object> otherParams;
	
	public RequestParams() {
		params = new HashMap<String,Object>();
	}
	
	public RequestParams(String service,String method,Map<String,Object> params) {
		this.service = service;
		this.method = method;
		this.params = params;
	}
	
	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public Integer getRequestOrder() {
		return requestOrder;
	}

	public void setRequestOrder(Integer requestOrder) {
		this.requestOrder = requestOrder;
	}

	public Object get(String param) {
		return params.get(param);
	}
	
	public String getString(String param) {
		Object value = params.get(param);
		if(ObjectUtils.isNotEmptyOrNull(value)) {
			return value.toString();
		}
		return null;
	}

	public Integer getInt(String param) {
		Object value = params.get(param);
		if(ObjectUtils.isNotEmptyOrNull(value)) {
			return Integer.valueOf(value.toString());
		}
		return null;
	}

	public Long getLong(String param) {
		Object value = params.get(param);
		if(ObjectUtils.isNotEmptyOrNull(value)) {
			return Long.valueOf(value.toString());
		}
		return null;
	}

	public Double getDouble(String param) {
		Object value = params.get(param);
		if(ObjectUtils.isNotEmptyOrNull(value)) {
			return Double.valueOf(value.toString());
		}
		return null;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public Map<String, Object> getParams() {
		return params;
	}

	public void setParams(Map<String, Object> params) {
		this.params = params;
	}

	public Map<String, Object> getSysParams() {
		if(sysParams == null) {
			sysParams = new HashMap<String, Object>();
		}
		return sysParams;
	}

	public void setSysParams(Map<String, Object> sysParams) {
		this.sysParams = sysParams;
	}

	public String getSysString(String param) {
		Object value = sysParams.get(param);
		if(ObjectUtils.isNotEmptyOrNull(value)) {
			return value.toString();
		}
		return null;
	}

	public Integer getSysInt(String param) {
		Object value = sysParams.get(param);
		if(ObjectUtils.isNotEmptyOrNull(value)) {
			return Integer.valueOf(value.toString());
		}
		return null;
	}
	
	public String getCookie(String param) {
		String value = cookieParams.get(param);
		return value;
	}

	public Map<String, String> getCookieParams() {
		return cookieParams;
	}

	public void setCookieParams(Map<String, String> cookieParams) {
		if(cookieParams == null) {
			cookieParams = new HashMap<String,String>();
		}
		this.cookieParams = cookieParams;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public Integer getClietPort() {
		return clietPort;
	}

	public void setClietPort(Integer clietPort) {
		this.clietPort = clietPort;
	}

	public byte[] getInputBytes() {
		return inputBytes;
	}

	public void setInputBytes(byte[] inputBytes) {
		this.inputBytes = inputBytes;
	}

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public String getPlateform() {
		return plateform;
	}

	public void setPlateform(String plateform) {
		this.plateform = plateform;
	}

	public ApiServiceTypeEnum getServiceType() {
		return serviceType;
	}

	public void setServiceType(ApiServiceTypeEnum serviceType) {
		this.serviceType = serviceType;
	}

	public String getNoncestr() {
		return noncestr;
	}

	public void setNoncestr(String noncestr) {
		this.noncestr = noncestr;
	}

	public Map<String, Object> getOtherParams() {
		return otherParams;
	}

	public void setOtherParams(Map<String, Object> otherParams) {
		this.otherParams = otherParams;
	}

	public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	public Integer getSystem() {
		return system;
	}

	public void setSystem(Integer system) {
		this.system = system;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getCustToken() {
		return custToken;
	}

	public void setCustToken(String custToken) {
		this.custToken = custToken;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}  
	
	public String getServerClientIp() {
		return serverClientIp;
	}

	public void setServerClientIp(String serverClientIp) {
		this.serverClientIp = serverClientIp;
	}


	public String getWlzqstatId() {
		return wlzqstatId;
	}

	public void setWlzqstatId(String wlzqstatId) {
		this.wlzqstatId = wlzqstatId;
	}

	@Override  
    public Object clone() {  
		RequestParams requestParams = null;  
        try{  
        	requestParams = (RequestParams)super.clone();  
        	HashMap<String,Object> cloneParmas = new HashMap<String,Object>();
        	if(params != null) {
        		cloneParmas.putAll(params);
        		requestParams.params = cloneParmas;
        	}
        	HashMap<String,Object> cloneSysParmas = new HashMap<String,Object>();
        	if(sysParams != null) {
        		cloneSysParmas.putAll(sysParams);
        		requestParams.sysParams = cloneSysParmas;
        	}
        	HashMap<String,String> cloneCookieParmas = new HashMap<String,String>();
        	if(cookieParams != null) {
        		cloneCookieParmas.putAll(cookieParams);
        		requestParams.cookieParams = cloneCookieParmas;
        	}
        	HashMap<String,Object> cloneOtherParams = new HashMap<String,Object>();
        	if(otherParams != null) {
        		cloneOtherParams.putAll(otherParams);
        		requestParams.otherParams = cloneOtherParams;
        	}
        }catch(CloneNotSupportedException e) {  
            e.printStackTrace();  
        }  
        return requestParams;  
    }

}
