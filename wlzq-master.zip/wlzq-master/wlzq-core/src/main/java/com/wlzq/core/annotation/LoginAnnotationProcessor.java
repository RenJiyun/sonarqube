package com.wlzq.core.annotation;

import java.lang.reflect.Method;

/**
 * 
 * @author 
 *
 */
public class LoginAnnotationProcessor {

	private Object service;
	private Method method;

	public LoginAnnotationProcessor(Object service, Method method) {
		this.service = service;
		this.method = method;
	}

	public boolean mustLogin() {
		if (service == null || method == null) {
			throw new RuntimeException("请求错误");
		}
		MustLogin mustLoginAnnotation = getMustLoginAnnotation();
		if (mustLoginAnnotation == null) {
			return false;
		}
		return mustLoginAnnotation.value();
	}

	public boolean mustIdentified() {
		if (service == null || method == null) {
			throw new RuntimeException("请求错误");
		}
		MustIdentified mustIdentifiedAnnotation = getMustIdentifiedAnnotation();
		if (mustIdentifiedAnnotation == null) {
			return false;
		}
		return mustIdentifiedAnnotation.value();
	}

	public boolean customerMustLogin() {
		if (service == null || method == null) {
			throw new RuntimeException("请求错误");
		}
		CustomerMustLogin customerMustLoginAnnotation = getCustomerMustLoginAnnotation();
		if (customerMustLoginAnnotation == null) {
			return false;
		}
		return customerMustLoginAnnotation.value();
	}

	private MustIdentified getMustIdentifiedAnnotation() {
		MustIdentified result = null;
		if (method != null) {
			result = method.getAnnotation(MustIdentified.class);
		}
		if (result == null) {
			result = service.getClass().getAnnotation(MustIdentified.class);
		}
		return result;
	}

	private MustLogin getMustLoginAnnotation() {
		MustLogin result = null;
		if (method != null) {
			result = method.getAnnotation(MustLogin.class);
		}
		if (result == null) {
			result = service.getClass().getAnnotation(MustLogin.class);
		}
		return result;
	}
	
	private CustomerMustLogin getCustomerMustLoginAnnotation() {
		CustomerMustLogin result = null;
		if (method != null) {
			result = method.getAnnotation(CustomerMustLogin.class);
		}
		if (result == null) {
			result = service.getClass().getAnnotation(CustomerMustLogin.class);
		}
		return result;
	}
	
}
