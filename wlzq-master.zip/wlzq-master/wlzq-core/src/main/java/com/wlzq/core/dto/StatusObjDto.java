package com.wlzq.core.dto;

/***
 * 成功失败结果返回对象。
 * 
 * @author 
 * @date 2017年8月4日
 * @version 
 */
public class StatusObjDto<T> extends StatusDto{
	private static final long serialVersionUID = 2394264057095595199L;

	/***
	 * 返回的对象
	 */
	private T obj;
	
	public StatusObjDto(boolean isOk) {
		this(isOk, FAIL_COMMON, "");
	}
	
	public StatusObjDto(boolean isOk, T obj) {
		this(isOk, FAIL_COMMON, "");
		this.obj = obj;
	}
	
	public StatusObjDto(boolean isOk, String msg) {
		this(isOk, FAIL_COMMON, msg);
	}
	
	public StatusObjDto(boolean isOk, Integer code) {
		this(isOk, code, "");
	}
	
	public StatusObjDto(boolean isOk, Integer code, String msg) {
		super(isOk, code, msg);
	}
	
	public StatusObjDto(boolean isOk, T obj, Integer code, String msg) {
		super(isOk, code, msg);
		this.obj = obj;
	}

	public static <T> StatusObjDto<T> newInstant(T obj){
		StatusObjDto<T> statusObjDto = new StatusObjDto<>(true, obj);
		statusObjDto.setCode(StatusObjDto.SUCCESS);
		return statusObjDto;
	}

	public static <T> StatusObjDto<T> newInstant(boolean isOk,T obj){
		StatusObjDto<T> statusObjDto = new StatusObjDto<>(isOk, obj);
		if (isOk) {
			statusObjDto.setCode(StatusObjDto.SUCCESS);
		}else{
			statusObjDto.setCode(StatusObjDto.FAIL_COMMON);
		}
		return statusObjDto;
	}


	public T getObj() {
		return obj;
	}

	public void setObj(T obj) {
		this.obj = obj;
	}
	
	public void setCode(Integer code, String msg) {
		this.setCode(code);
		this.setMsg(msg);
	}
	
	public StatusObjDto<T> set(boolean isOk, T obj, Integer code, String msg) {
		this.setOk(isOk);
		this.setCode(code);
		this.setMsg(msg);
		this.obj = obj;
		return this;
	}
}
