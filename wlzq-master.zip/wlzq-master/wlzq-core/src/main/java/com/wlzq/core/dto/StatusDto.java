package com.wlzq.core.dto;

import java.io.Serializable;

/***
 * 成功失败结果返回对象。
 * 
 * @author 
 * @date 2017年8月4日
 * @version 
 */
public class StatusDto implements Serializable {
	private static final long serialVersionUID = 3843704642277205122L;
	public static final Integer SUCCESS = 0;
	public static final Integer FAIL_COMMON = 1;

	/** 结果：成功 - true, 失败 - false */
	private boolean isOk;
	/** 执行结果编码 */
	private Integer code;
	/** 执行结果文本提示 */
	private String msg;

	public StatusDto(boolean isOk) {
		this(isOk, null, "");
	}
	
	public StatusDto(boolean isOk, String msg) {
		this(isOk, null, msg);
	}
	
	public StatusDto(boolean isOk, Integer code) {
		this(isOk, code, "");
	}
	
	public StatusDto(boolean isOk, Integer code, String msg) {
		this.isOk = isOk;
		if(code == null) {
			code = isOk?SUCCESS:FAIL_COMMON;
		}
		this.code = code;
		this.msg = msg;
	}
	
	/** 结果：成功 - true, 失败 - false */
	public boolean isOk() {
		return isOk;
	}

	/** 结果：成功 - true, 失败 - false */
	public void setOk(boolean isOk) {
		this.isOk = isOk;
	}

	/** 执行结果编码 */
	public Integer getCode() {
		return code;
	}

	/** 执行结果编码 */
	public void setCode(Integer code) {
		this.code = code;
	}

	/** 执行结果文本提示 */
	public String getMsg() {
		return msg;
	}

	/** 执行结果文本提示 */
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
