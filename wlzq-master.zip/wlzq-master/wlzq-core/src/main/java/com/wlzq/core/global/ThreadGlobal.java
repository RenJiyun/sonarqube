package com.wlzq.core.global;

import com.wlzq.common.RequestId;

/**
 * 线程全局变量
 * @author Administrator
 *
 */
public class ThreadGlobal {
	public static ThreadLocal<RequestId>  reqestId= new ThreadLocal<RequestId>();
}
