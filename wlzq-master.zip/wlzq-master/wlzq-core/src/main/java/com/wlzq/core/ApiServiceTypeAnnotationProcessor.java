package com.wlzq.core;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import com.wlzq.core.annotation.ApiServiceType;
import com.wlzq.core.annotation.ApiServiceTypeEnum;

/**
 * 
 * @author
 *
 */
public class ApiServiceTypeAnnotationProcessor {
	

	private Object service;

	public ApiServiceTypeAnnotationProcessor(Object service) {
		this.service = service;
	}

	private Method getMethod(Object obj, String methodName) {
		Method[] mothods = obj.getClass().getMethods();

		for (Method method : mothods) {
			if (method.getName().equals(methodName)) {
				return method;
			}
		}
		return null;
	}

	public boolean checkAccess(ApiServiceTypeEnum serviceType) {
		if (service == null) {
			return false;
		}
		ApiServiceTypeEnum[] types = getApiRequestTypes();
		if (types.length == 0) {
			if (serviceType.equals(ApiServiceTypeEnum.APP)) {
				return true;
			} else {
				return false;
			}
		}

		return inTypes(serviceType, types);
	}

	private ApiServiceTypeEnum[] getApiRequestTypes() {

		Class<ApiServiceType> clazz = ApiServiceType.class;
		List<ApiServiceTypeEnum> serviceTyptes = new ArrayList<ApiServiceTypeEnum>();

		ApiServiceType serviceType = service.getClass().getAnnotation(clazz);
		if (serviceType != null) {
			for (ApiServiceTypeEnum apiRequestType : serviceType.value()) {
				serviceTyptes.add(apiRequestType);
			}
		}

		return (ApiServiceTypeEnum[]) serviceTyptes.toArray(new ApiServiceTypeEnum[serviceTyptes.size()]);
	}

	private boolean inTypes(ApiServiceTypeEnum type, ApiServiceTypeEnum[] types) {
		if (types == null) {
			return false;
		}
		for (ApiServiceTypeEnum t : types) {
			if (t == type) {
				return true;
			}
		}
		return false;
	}

}
