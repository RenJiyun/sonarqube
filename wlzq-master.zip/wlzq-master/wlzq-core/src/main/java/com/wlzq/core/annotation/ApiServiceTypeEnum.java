package com.wlzq.core.annotation;

/**
 * API 服务类型
 * @author louie
 *
 */
public enum ApiServiceTypeEnum {
	/** 前端调用的接口 */
	APP,
	
	/** 后台服务调用接口. 平台子系统之间的调用或者第三方接入的调用 */
	COOPERATION,
	
	/** 其他应用回调接口.  */
	CALLBACK,
}
