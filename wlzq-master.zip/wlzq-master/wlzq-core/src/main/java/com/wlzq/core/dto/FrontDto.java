package com.wlzq.core.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 返回前端dto
 * 
 * @author 
 * @date 2017年8月4日
 * @version 
 */
public class FrontDto implements Serializable {
	private static final long serialVersionUID = 3840462772205122L;
	/** 结果编码  0:成功，其它：失败*/
	private Integer code;
	/** 数据 */
	private Map<String,Object> data;
	/** 结果文本提示 */
	private String msg;
	
	public FrontDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FrontDto(Integer code) {
		this(code, new HashMap<String,Object>(), "");
	}
	
	public FrontDto(Integer code, String msg) {
		this(code,  new HashMap<String,Object>(), msg);
	}
	
	public FrontDto(Integer code,Map<String,Object> data, String msg) {
		this.code = code;
		this.data = data;
		this.msg = msg;
	}

	/** 结果编码 */
	public Integer getCode() {
		return code;
	}

	/** 结果编码 */
	public void setCode(Integer code) {
		this.code = code;
	}
	
	public Map<String,Object> getData() {
		return data;
	}

	public void setData(Map<String,Object> data) {
		this.data = data;
	}

	/** 结果文本提示 */
	public String getMsg() {
		return msg;
	}

	/** 结果文本提示 */
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
