package com.wlzq.service.base.sys.dao;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.model.SysNDict;

/**
 * 配置管理2DAO接口
 * @author zhaozx
 * @version 2019-06-21
 */
@MybatisScan
public interface SysNDictDao extends CrudDao<SysNDict> {
	
	
}