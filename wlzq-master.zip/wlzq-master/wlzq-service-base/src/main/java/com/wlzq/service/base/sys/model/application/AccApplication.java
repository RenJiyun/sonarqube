package com.wlzq.service.base.sys.model.application;

import java.io.Serializable;

/**
 * 应用信息Entity
 * @author louie
 * @version 2017-09-28
 */
public class AccApplication  implements Serializable{
	
	private static final long serialVersionUID = 190787567889L;
	private String name;		// 名称
	private Integer type;		// 类型，1：内部应用,2:外部应用
	private String key;		// key
	private String secret;		// 秘钥
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}
}