package com.wlzq.service.base.sys.dao;

import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.model.Dictionaries;

/**
 * Dictionaries DAO类
 * @author 2017-8-16 16:08:08
 * @version 1.0
 */
@MybatisScan
public interface DictionariesDao {
	
	Dictionaries findByCode(String code);
}
