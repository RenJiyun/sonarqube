package com.wlzq.service.base.mq;

import java.util.Map;

import com.google.common.collect.Maps;
import com.wlzq.service.base.mq.consumer.MessageConsumer;

public class MessageConsumerHandlers {

   	public static Map<String,MessageConsumer> handlers = Maps.newHashMap();

   	/**
	 * 注册消息消费处理
	 * @param tags
	 * @param messageConsumer
	 */
	public static void registHandler(String tags,MessageConsumer messageConsumer) {
		handlers.put(tags, messageConsumer);
	}
	
	public static MessageConsumer getHandler(String tags) {
		return handlers.get(tags);
	}
}
