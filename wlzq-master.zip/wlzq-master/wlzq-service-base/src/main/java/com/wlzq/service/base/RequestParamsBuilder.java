package com.wlzq.service.base;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.google.common.collect.Maps;
import com.wlzq.common.constant.DeviceTypeConstant;
import com.wlzq.common.constant.SysConstant;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.RequestParams;

public class RequestParamsBuilder {
	private static final String BEHAVIOR = "behavior";
	private HttpServletRequest request;
	public RequestParamsBuilder(HttpServletRequest request) {
		this.request = request;
	}

	public RequestParams build() {
		String method = request.getParameter("method");
    	String params = request.getParameter("params");
    	//业务参数
    	Map<String,Object> paramsMap = JsonUtils.json2Map(params);
    	paramsMap = paramsMap == null?new HashMap<String,Object>():paramsMap;
    	//若为行为平台调用，添加user-agent参数
    	if(ObjectUtils.isNotEmptyOrNull(method) && method.startsWith(BEHAVIOR) && !paramsMap.containsKey("user-agent")) {
    		paramsMap.put("user-agent", request.getHeader("user-agent"));
    	}
    	String service = null;
    	String methodCall = null;
    	if(ObjectUtils.isNotEmptyOrNull(method)) {
    		service = method.substring(0,method.lastIndexOf("."));
    		methodCall = method.substring(method.lastIndexOf(".")+1);
    	}
    	RequestParams requestParams = new RequestParams(service,methodCall,paramsMap);
    	//系统参数
    	Map<String, Object> sysParams = new HashMap<String,Object>();
    	Map<String, String[]> ps = request.getParameterMap();
    	for(String key: ps.keySet()) {
    		if(key.equals("_")) {
    			continue;
    		}
    		if(key.equals("k")) {
    			requestParams.setKey(ps.get(key)[0]);
    		}
    		sysParams.put(key, ps.get(key)[0]);
    	}
		requestParams.setSysParams(sysParams);
		
		//cookie参数
		Cookie[] cookies = request.getCookies();
		Map<String, String> cookieParams = new HashMap<String,String>();
    	if(cookies != null) {
    		for(Cookie cookie:cookies) {
    			cookieParams.put(cookie.getName(),cookie.getValue());
    			if("wlzqstat_id".equals(cookie.getName())) {
    				requestParams.setWlzqstatId(cookie.getValue());
    			}
        	}
    	}
    	requestParams.setCookieParams(cookieParams);
    	String ip = request.getHeader("x-real-ip");
		ip = ObjectUtils.isEmptyOrNull(ip) ? request.getHeader("x-forwarded-for") : ip;//有代理时取得客户端IP信息
		ip = ObjectUtils.isEmptyOrNull(ip) ? request.getHeader("x-forward-for") : ip;//有代理时取得客户端IP信息
		ip = ObjectUtils.isEmptyOrNull(ip) ? request.getRemoteAddr() : ip;
    	requestParams.setClientIp(ip);
    	requestParams.setClietPort(request.getRemotePort());
    	if(ObjectUtils.isEmptyOrNull(sysParams.get("clientIp"))) {
	    	requestParams.setClientIp(ip);
    	}else {
    		requestParams.setClientIp(sysParams.get("clientIp").toString());
    		requestParams.setServerClientIp(ip);
    	}
    	if(ObjectUtils.isEmptyOrNull(sysParams.get("deviceType"))) {
    		requestParams.setDeviceType(getPlatform(request));
    	}else {
    		requestParams.setDeviceType(Integer.valueOf(sysParams.get("deviceType").toString()));
    	}
    	requestParams.setDevice((String)sysParams.get("device"));
    	requestParams.setVersion((String)sysParams.get("ver"));
    	String systemString = (String)sysParams.get("system");
    	if(ObjectUtils.isNotEmptyOrNull(systemString)) {
    		Pattern pattern = Pattern.compile("[0-9]*");
    	    if(pattern.matcher(systemString).matches()){
    	    	requestParams.setSystem(Integer.valueOf(systemString));
    	    } 
    	}
    	//设置requestid
    	String requestId = (String)sysParams.get("requestId");
    	requestId = ObjectUtils.isEmptyOrNull(requestId)?UUID.randomUUID().toString().replaceAll("-", ""):requestId;
    	requestParams.setRequestId(requestId);
    	try {
			// 请求流
    		requestParams.setInputBytes(streamToBytes(request.getInputStream()));
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	String token = getToken(requestParams);
    	String customerToken = getCustomerToken(requestParams);
    	requestParams.setToken(token);
    	requestParams.setCustToken(customerToken);
    	
    	if(requestParams.getParams() == null) {
    		requestParams.setParams(Maps.newHashMap());
    	}
    	if(requestParams.getCookieParams() == null) {
    		requestParams.setCookieParams(Maps.newHashMap());
    	}
    	if(requestParams.getSysParams() == null) {
    		requestParams.setSysParams(Maps.newHashMap());
    	}
    	if(requestParams.getOtherParams() == null) {
    		requestParams.setOtherParams(Maps.newHashMap());
    	}
    	return requestParams;
	}

    private String getToken(RequestParams params ) {
    	String token = params.getSysString(SysConstant.TOKEN_NAME);
    	if(ObjectUtils.isEmptyOrNull(token)) {
    		token = params.getCookie(SysConstant.TOKEN_NAME);
    	}
    	return token;
    }

    private String getCustomerToken(RequestParams params) {
    	String token = params.getSysString(SysConstant.CUSTOMER_TOKEN_NAME);
    	if(ObjectUtils.isEmptyOrNull(token)) {
    		token = params.getCookie(SysConstant.CUSTOMER_TOKEN_NAME);
    	}
    	return token;
    }
    
	private byte[] streamToBytes(InputStream inStream) {
		try {
			int readSize = 1024;
			ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
			byte[] buff = new byte[readSize]; // buff用于存放循环读取的临时数据
			int rc = 0;
			while ((rc = inStream.read(buff, 0, readSize)) > 0) {
				swapStream.write(buff, 0, rc);
			}
			return swapStream.toByteArray();
		} catch (IOException e) {
			e.printStackTrace();
			return new byte[0];
		}
	}
	
	/**获取客户端*/
	private Integer getPlatform(HttpServletRequest request){
		/**User Agent中文名为用户代理，简称 UA，它是一个特殊字符串头，使得服务器
	    能够识别客户使用的操作系统及版本、CPU 类型、浏览器及版本、浏览器渲染引擎、浏览器语言、浏览器插件等*/  
	    String agent= request.getHeader("user-agent");
	    if(ObjectUtils.isEmptyOrNull(agent)) return 5;
	    //客户端类型常量
	    Integer type;
	    if(agent.indexOf("MicroMessenger") > 0){ 
	        type = DeviceTypeConstant.WX;//"wx";
	    }else if(agent.contains("iPhone")||agent.contains("iPod")||agent.contains("iPad")){  
	        type = DeviceTypeConstant.IOS;// "ios";
	    } else if(agent.contains("Android") || agent.contains("Linux")) { 
	        type = DeviceTypeConstant.APK;// "apk";
	    } else {
	        type = DeviceTypeConstant.PC;//"pc";
	    }
	    return type;
	}
}
