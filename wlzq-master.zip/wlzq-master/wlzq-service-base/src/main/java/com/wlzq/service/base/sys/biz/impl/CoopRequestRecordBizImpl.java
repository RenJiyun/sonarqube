package com.wlzq.service.base.sys.biz.impl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wlzq.service.base.sys.biz.CoopRequestRecordBiz;
import com.wlzq.service.base.sys.dao.CoopRequestRecordDao;
import com.wlzq.service.base.sys.model.CoopRequestRecord;

/**
 * AccApplicationBiz接口实现
 * @author louie
 *
 */
@Service
public class CoopRequestRecordBizImpl implements CoopRequestRecordBiz {
	private ExecutorService saveThreadPool = Executors.newFixedThreadPool(10);
	@Autowired
	private CoopRequestRecordDao requestRecordDao;

	@Override
	public void save(final CoopRequestRecord record) {
		saveThreadPool.execute(new Runnable() {  
		    public void run() {  
		    	requestRecordDao.insert(record);
		    }
		});
	}
}
