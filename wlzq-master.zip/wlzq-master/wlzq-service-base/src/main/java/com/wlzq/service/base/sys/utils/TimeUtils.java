package com.wlzq.service.base.sys.utils;

import java.util.Date;

import com.wlzq.common.utils.DateUtils;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.service.base.sys.holiday.biz.HolidayBiz;
import com.wlzq.service.base.sys.holiday.model.Holiday;


public class TimeUtils {

	/**
	 * 是否中登业务时间
	 * @param date
	 * @return
	 */
	public static boolean isChinaClearBusTime(Date date) {
		if(date == null) return false;
		String busBeginTimeStr = DateUtils.formate(date,"yyyy-MM-dd ")+"09:00";
		String busEndTimeStr = DateUtils.formate(date,"yyyy-MM-dd ")+"16:00";
		Date busBeginTime = DateUtils.parseDate(busBeginTimeStr, "yyyy-MM-dd HH:mm");
		Date busEndTime = DateUtils.parseDate(busEndTimeStr, "yyyy-MM-dd HH:mm");
		if(DateUtils.isWeekend(date)) return false;
		HolidayBiz holidayBiz =  SpringApplicationContext.getBean(HolidayBiz.class);
		Holiday holiday = holidayBiz.getHolidayFromDate(date);
		if(holiday != null) return false;
		if(date.getTime() >= busBeginTime.getTime() && date.getTime() <= busEndTime.getTime()) {
			return true;
		}
		return false;
	}
}
