package com.wlzq.service.base.sys.dto;

import java.io.Serializable;
import java.util.List;

import com.wlzq.service.base.sys.model.SysNDict;

public class DictsDto  implements Serializable {

	private static final long serialVersionUID = 1142323L;
	private List<SysNDict>  dicts;
	public List<SysNDict> getDicts() {
		return dicts;
	}
	public void setDicts(List<SysNDict> dicts) {
		this.dicts = dicts;
	}
	
}
