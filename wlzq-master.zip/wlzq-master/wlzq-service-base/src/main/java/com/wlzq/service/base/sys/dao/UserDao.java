package com.wlzq.service.base.sys.dao;

import java.util.Date;

import org.apache.ibatis.annotations.Param;

import com.wlzq.common.model.account.AccTokenUser;
import com.wlzq.common.model.account.Customer;
import com.wlzq.common.model.account.User;
import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;

/**
 * 用户管理DAO接口
 * @author louie
 * @version 2017-09-15
 */
@MybatisScan
public interface UserDao extends CrudDao<User> {
	
	/**
	 * token查询用户信息
	 * @param token
	 * @param expireTime
	 * @return
	 */
	AccTokenUser findByToken(@Param("token")String token,@Param("expireTime")Date expireTime);
	
	/**
	 * 登录信息查找客户
	 * @param token
	 * @param expireTime 登录过期时间
	 * @return
	 */
	Customer findCustomerByToken(@Param("token")String custToken,@Param("expireTime")Date expireTime);
	
	/**
	 * 客户号查找客户
	 * @param customerId 客户号
	 * @return
	 */
	Customer findCustomerByCustomerId(@Param("customerId")String customerId);
	
	/**
	 * 手机号查询用户
	 * @param mobile
	 * @return
	 */
	AccTokenUser findByMobile(String mobile);
	
	/**
	 * 查找绑定信息
	 * @param thirdUid
	 * @param type
	 * @return
	 */
	String findThirdUidBindValue(@Param("thirdUid")String thirdUid, @Param("type")Integer type);
	
	/**
	 * 查找thirdUid
	 * @param value
	 * @param type
	 * @return
	 */
	String findThirdUidByValue(@Param("value")String value, @Param("type")Integer type);
}