package com.wlzq.service.base.sd.common;

public enum SDServiceType {
	// 利用构造函数传参
    WECHAT (1),STORE (2),ONLINEHALL(3),MARKET(4);

    // 定义私有变量
    private int value ;

    // 构造函数，枚举类型只能为私有
    private SDServiceType( int value) {
        this . value = value;
    }
    public int getValue(){
    	return this . value ;
    }  
}
