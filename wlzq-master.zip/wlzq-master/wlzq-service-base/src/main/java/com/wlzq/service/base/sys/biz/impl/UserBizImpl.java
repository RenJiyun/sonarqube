package com.wlzq.service.base.sys.biz.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wlzq.common.constant.SysConstant;
import com.wlzq.common.constant.ThirdBindTypeE;
import com.wlzq.common.model.account.AccTokenCustomer;
import com.wlzq.common.model.account.AccTokenUser;
import com.wlzq.common.model.account.Customer;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.service.base.redis.UserRedis;
import com.wlzq.service.base.sys.biz.UserBiz;
import com.wlzq.service.base.sys.dao.UserDao;
/**
 * AccountUserBiz实现类
 * @author 
 * @version 1.0
 */
@Service
public class UserBizImpl  implements UserBiz{

	@Autowired
	private	UserDao userDao;
	
	@Value("${spring.application.name}")
    private String application;
	
	public StatusObjDto<AccTokenUser> findUserByToken(String token,boolean onlyFromCache) {
		if(ObjectUtils.isEmptyOrNull(token)) {
			return new StatusObjDto<AccTokenUser>(false,104,"token参数为空");
		}
		AccTokenUser user = (AccTokenUser) UserRedis.TOKEN_INFO.get(token);
		if(user != null || onlyFromCache) {
			return new StatusObjDto<AccTokenUser>(true,user,0,"");
		}else{ //若为空，从数据库查询
    		user = userDao.findByToken(token,new Date());
    		if(user == null) {
    			return new StatusObjDto<AccTokenUser>(false,102,"未登录");
    		}
    		if(ObjectUtils.isNotEmptyOrNull(user.getThirdType()) && user.getThirdType().equals(AccTokenUser.THIRDTYPE_WECHAT)) {
    			user.setOpenid(user.getThirdUid());
    			user.setUnionid(user.getUnionid());
    		}
    		
    		/**若thirdUid为空，通过手机号查找thirUid**/
    		if (ObjectUtils.isEmptyOrNull(user.getThirdUid()) && ObjectUtils.isNotEmptyOrNull(user.getMobile())) {
				String thirdUid = userDao.findThirdUidByValue(user.getMobile(), ThirdBindTypeE.MOBILE.getValue());
				user.setThirdUid(thirdUid);
			}
			/**增加ekp账号信息**/
			String ekpAccount = null;
			if (ObjectUtils.isNotEmptyOrNull(user.getThirdUid())) {
				ekpAccount = userDao.findThirdUidBindValue(user.getThirdUid(), 2);
				user.setEkpAccount(ekpAccount);
			}
			/**若crm账号为空，且有thirdUid，设置crm账号**/
			String staffno = null;
			if (ObjectUtils.isNotEmptyOrNull(user.getThirdUid())) {
				staffno = userDao.findThirdUidBindValue(user.getThirdUid(), 3);
				user.setStaffNo(staffno);
			}
			UserRedis.TOKEN_INFO.set(token, user,SysConstant.TOKEN_TIMEOUT_DAY*24*3600);
    		return new StatusObjDto<AccTokenUser>(true,user,0,"");
		}
	}

	@Override
	public StatusObjDto<Customer> findCustomerByToken(String custToken,boolean onlyFromCache) {
		if(ObjectUtils.isEmptyOrNull(custToken)) {
			return new  StatusObjDto<Customer>(false,StatusDto.FAIL_COMMON,"客户未登录");
		}
		Customer customer = null;
		AccTokenCustomer tokenCustomer = (AccTokenCustomer) UserRedis.ACCESS_CUSTOMER_INFO.get(custToken);
		if(tokenCustomer != null) {
			customer = (Customer) UserRedis.CUSTOMER_INFO.get(tokenCustomer.getCustomerId());
		}
		
		if(onlyFromCache) {
			return new StatusObjDto<Customer>(true,customer,StatusDto.SUCCESS,"");
		}
		
		//不为空时，若非业务办理平台或为业务办理平台且财人汇登录信息不为空，则返回
		if(customer != null) {
			return new StatusObjDto<Customer>(true,customer,StatusDto.SUCCESS,"");
		}
		
		//数据库查询
		customer = userDao.findCustomerByToken(custToken, new Date());
		if(customer == null) {
			return new  StatusObjDto<Customer>(false,StatusDto.FAIL_COMMON,"客户未登录");
		}
		AccTokenCustomer token = new AccTokenCustomer();
		token.setCustomerId(customer.getCustomerId());
		token.setFundAccount(customer.getFundAccount());
		token.setType(customer.getLoginBizType());
		Long expireTime = (customer.getLoginExpireTime().getTime() - new Date().getTime())/1000;
		UserRedis.ACCESS_CUSTOMER_INFO.set(custToken, token,expireTime.intValue());
		UserRedis.CUSTOMER_INFO.set(customer.getFundAccount(), customer,2*24*3600);
		
		return new StatusObjDto<Customer>(true,customer,StatusDto.SUCCESS,"");
	}

	@Override
	public StatusObjDto<Customer> findCustomerByCustomerId(String customerId){
		if(ObjectUtils.isEmptyOrNull(customerId)) {
			return new  StatusObjDto<Customer>(false,StatusDto.FAIL_COMMON,"customerId参数为空");
		}
		
		Customer customer = (Customer) UserRedis.CUSTOMER_INFO.get(customerId);
		if( customer != null) {
			return new StatusObjDto<Customer>(true,customer,StatusDto.SUCCESS,"");
		}
		
		//数据库查询
		customer = userDao.findCustomerByCustomerId(customerId);
		if(customer == null) {
			return new  StatusObjDto<Customer>(false,StatusDto.FAIL_COMMON,"客户不存在");
		}
		
		UserRedis.CUSTOMER_INFO.set(customerId, customer,2*24*3600);
		
		return new StatusObjDto<Customer>(true,customer,StatusDto.SUCCESS,"");
	}

	@Override
	public AccTokenUser findUserByMobile(String mobile) {
		if(ObjectUtils.isEmptyOrNull(mobile)) {
			return null;
		}
		AccTokenUser user = (AccTokenUser) UserRedis.USER_INFO_BY_MOBILE.get(mobile);
		if(user != null) {
			return user;
		}else { //若为空，从数据库查询
    		user = userDao.findByMobile(mobile);
    		if(user != null) {
    			UserRedis.USER_INFO_BY_MOBILE.set(mobile,user);
    		}
    		return user;
		}
	}

}
