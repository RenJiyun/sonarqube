/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.service.base.sys.dao;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.model.ApiExternalRequest;

/**
 * 外部请求记录DAO接口
 * @author louie
 * @version 2021-02-05
 */
@MybatisScan
public interface ApiExternalRequestDao extends CrudDao<ApiExternalRequest> {
	
}