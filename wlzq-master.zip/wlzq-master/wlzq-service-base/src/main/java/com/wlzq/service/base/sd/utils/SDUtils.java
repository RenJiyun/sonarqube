package com.wlzq.service.base.sd.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.SdHttpClientUtils;
import com.wlzq.common.utils.SdHttpClientUtils.HttpResult;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.service.base.sd.common.SDResult;
import com.wlzq.service.base.sd.common.SDServiceType;
import com.wlzq.service.base.sd.config.SDConfig;

public class SDUtils {
	/**
	 * 获取思迪服务结果
	 * @param type
	 * @param params
	 * @return
	 */
	public static SDResult doGet(SDServiceType type,String function,String sessionId,Map<String,Object> params) {
		if(type == null) {
			SDResult sdResult = new SDResult();
			sdResult.setErrorNo("-1");
			sdResult.setErrorInfo("请指定思迪服务类型");
			return sdResult;
		}
		if(ObjectUtils.isEmptyOrNull(function)) {
			SDResult sdResult = new SDResult();
			sdResult.setErrorNo("-1");
			sdResult.setErrorInfo("请指定思迪服务类型");
			return sdResult;
		}
		SDConfig sdConfig = SpringApplicationContext.getBean(SDConfig.class);
		if(sdConfig == null) {
			SDResult sdResult = new SDResult();
			sdResult.setErrorNo("-2");
			sdResult.setErrorInfo("未配置思迪服务地址");
			return sdResult;
		}
		String url = type.equals(SDServiceType.WECHAT)?sdConfig.getWechatServiceRoot():sdConfig.getStoreServiceRoot();
		String path = params.get("path") != null?params.get("path").toString():"";
		url = url + path;
		if(ObjectUtils.isNotEmptyOrNull(sessionId)) {
			url = url + ";jsessionid="+sessionId;
		}
		if(params == null) {
			params = new HashMap<String,Object>();
		}
		params.put("funcNo", function);
		String response = HttpClientUtils.doGet(url, params);
		SDResult sdResult = JsonUtils.json2Bean(response, SDResult.class);
		Map<String,Object> resultM = JsonUtils.json2Map(response);
		if(sdResult.getErrorNo().equals("0")) {
			Map<String,Object> data = new HashMap<String,Object>();
			for(String ds:sdResult.getDsName()) {
				data.put(ds,resultM.get(ds));
			}
			sdResult.setData(data);
		}
		return sdResult;
	}
	
	/**
	 * 获取思迪服务结果
	 * @param type
	 * @param params
	 * @return
	 */
	public static SDResult doPost(SDServiceType type,String function,String sessionId,Map<String,Object> params) {
		if(type == null) {
			SDResult sdResult = new SDResult();
			sdResult.setErrorNo("-1");
			sdResult.setErrorInfo("请指定思迪服务类型");
			return sdResult;
		}
		
		SDConfig sdConfig = SpringApplicationContext.getBean(SDConfig.class);
		if(sdConfig == null) {
			SDResult sdResult = new SDResult();
			sdResult.setErrorNo("-2");
			sdResult.setErrorInfo("未配置思迪服务地址");
			return sdResult;
		}
		String url = type.equals(SDServiceType.WECHAT)?sdConfig.getWechatServiceRoot():type.equals(SDServiceType.STORE)?
				sdConfig.getStoreServiceRoot():type.equals(SDServiceType.ONLINEHALL)?sdConfig.getOnlineHallServiceRoot():sdConfig.getMarketServiceRoot();
		String path = params.get("path") != null?params.get("path").toString():"";
		url = url + path;
		Map<String,String> cookies = new HashMap<String,String>();
		if(ObjectUtils.isNotEmptyOrNull(sessionId) && type.equals(SDServiceType.STORE)) {
			url = url + ";jsessionid="+sessionId;
		}else if(ObjectUtils.isNotEmptyOrNull(sessionId) && type.equals(SDServiceType.ONLINEHALL)) {
			cookies.put("JSESSIONID", sessionId);
		}
		if(params == null) {
			params = new HashMap<String,Object>();
		}
		if(!ObjectUtils.isEmptyOrNull(function)) {
			params.put("funcNo", function);
		}
		//HttpResult response = SdHttpClientUtils.doPostReturnStateCode(url, params,cookies,"UTF-8");
		HttpResult response = SdHttpClientUtils.doGetReturnStateCode(url, params,cookies,"UTF-8");
		if(response.content instanceof String) {
			Map<String,Object> mv = JsonUtils.json2Map((String)response.content);
			if(mv.get("results") != null && mv.get("results").equals("")) {
				mv.put("results", null);
			}
			Object results = mv.get("results");
			if(results instanceof String) {
				List resultList = JsonUtils.jsonToList((String)results);
				mv.put("results", resultList);
			}
			SDResult sdResult = JsonUtils.json2Bean(JsonUtils.map2Json(mv), SDResult.class);
			if(sdResult == null) {
				sdResult = new SDResult();
				sdResult.setCookies(response.responseCookies);
				sdResult.setErrorInfo((String)mv.get("errorInfo"));
				sdResult.setErrorNo(String.valueOf(mv.get("errorNo")));
				Map<String, Object> data = new HashMap<String,Object>();
				data.put("results", mv.get("results"));
				List<String> dsName = new ArrayList<String>();
				dsName.add("results");
				sdResult.setDsName(dsName );
				sdResult.setData(data);
				return sdResult;
			}
			sdResult.setCookies(response.responseCookies);
			if(type.equals(SDServiceType.ONLINEHALL)) {
				sdResult.setErrorInfo((String)mv.get("errorInfo"));
				sdResult.setErrorNo(String.valueOf(mv.get("errorNo")));
			}
			if(sdResult.getErrorNo().equals("0") && sdResult.getDsName() != null) {
				Map<String,Object> data = new HashMap<String,Object>();
				for(String ds:sdResult.getDsName()) {
					data.put(ds,mv.get(ds));
				}
				sdResult.setData(data);
			}
			return sdResult;
		}else if(response.content instanceof byte[]) {
			SDResult sdResult = new SDResult();
			sdResult.setCookies(response.responseCookies);
			sdResult.setErrorNo("0");
			sdResult.setImage((byte[])response.content);
			return sdResult;
		}

		SDResult sdResult = new SDResult();
		sdResult.setResults(null);
		sdResult.setErrorNo("-111");
		sdResult.setErrorInfo("获取异常");
		return sdResult;
	}
}
