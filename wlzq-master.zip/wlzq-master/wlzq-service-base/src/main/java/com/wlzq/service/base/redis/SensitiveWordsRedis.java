package com.wlzq.service.base.redis;

import com.wlzq.service.base.sys.RedisFacadeAbstract;

public class SensitiveWordsRedis extends RedisFacadeAbstract {
	
	public static final SensitiveWordsRedis SENSITIVEWORDSREDIS = new SensitiveWordsRedis("base:sensitivewords:list:", 24*3600);

	public static final String SENSITIVEWDS = "sensitivewordslist";
	
	private String redisPrefix;
	private int timeoutSeconds;

	private SensitiveWordsRedis(String redisPrefix) {
		this.redisPrefix = redisPrefix;
	}
	
	private SensitiveWordsRedis(String redisPrefix, int timeoutSeconds) {
		this.redisPrefix = redisPrefix;
		this.timeoutSeconds = timeoutSeconds;
	}
	
	@Override
	protected String getRedisPrefix() {
		return redisPrefix;
	}

	@Override
	protected int getTimeoutSeconds() {
		return timeoutSeconds;
	}

}
