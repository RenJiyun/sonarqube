package com.wlzq.service.base.sys.utils;

import java.io.IOException;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import javax.naming.ldap.PagedResultsControl;
import javax.naming.ldap.PagedResultsResponseControl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wlzq.common.utils.ObjectUtils;

public class LdapUtils {
	
	private static final String EKP_LOGIN_URL = "ldap://172.17.17.11:389";
	private static final String searchBase = "DC=wlzq,DC=com";
	private static final String[] returnedAtts = {"name", "distinguishedName", "mail", "mobile"};
	private static final String searchFilter = "sAMAccountName=";
	
	private static Logger logger = LoggerFactory.getLogger(LdapUtils.class);
	
	public static List<Map<String,Object>> vertify(String user, String password) {
		return vertify(user, password, null);
	}
	
	/**
	 * ekp 账号密码验证
	 */
	public static List<Map<String,Object>> vertify(String user, String password, String url) {
		if (ObjectUtils.isEmptyOrNull(url)) {
			url = EKP_LOGIN_URL;
		}
		Hashtable<String,String> HashEnv = new Hashtable<String,String>();
		HashEnv.put(Context.SECURITY_AUTHENTICATION, "simple"); // LDAP访问安全级别
		HashEnv.put(Context.SECURITY_PRINCIPAL, user + "@wlzq.com"); // AD User
		HashEnv.put(Context.SECURITY_CREDENTIALS, password); // AD// Password
		HashEnv.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory"); // LDAP工厂类
		HashEnv.put(Context.PROVIDER_URL, url);
		HashEnv.put(Context.BATCHSIZE, "4100");
		
		List<Map<String,Object>> datas = null;
		try {
			LdapContext ldapContext = new InitialLdapContext(HashEnv, null);
			logger.info("初始化ldap成功");
			datas = find(ldapContext, searchBase, searchFilter + user,returnedAtts, 1);
			
			ldapContext.close();
			return datas;
		} catch (NamingException e) {
			logger.error("初始化ldap失败");
			logger.error(e.getMessage());
			return datas;
		}
	}
	
	/**
	 * 查询数据
	 * @param searchBase 域节点
	 * @param searchFilter 搜索过滤器
	 * @param returnedAtts 返回属性
	 * @param limit 返回数量
	 * @return
	 */
	public static List<Map<String,Object>> find(LdapContext ldapContext, String searchBase, String searchFilter,String[] returnedAtts,int limit){
		if(ldapContext == null) {
			logger.error("查询失败，创建AD连接失败");
			return Lists.newArrayList();
		}
		
		try {
			ldapContext.setRequestControls(new Control[] { new PagedResultsControl(5000, Control.CRITICAL) });
		} catch (NamingException | IOException e) {
			e.printStackTrace();
			logger.error("设置ldap请求控制器失败");
			return Lists.newArrayList();
		}

		// 搜索控制器
		SearchControls searchCtls = new SearchControls();
		searchCtls.setCountLimit(limit);
		searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE); 
		searchCtls.setReturningAttributes(returnedAtts); // 设置返回属性集

		return ldapDatalistPage(ldapContext, searchBase, searchFilter);

	}
	

	private static List<Map<String,Object>> ldapDatalistPage(LdapContext context, String base, String objectClass) {

		List<Map<String,Object>> datas = Lists.newArrayList();
		int pageSize = 5; 
		byte[] cookie = null;

		try {
			context.setRequestControls(new Control[] { new PagedResultsControl(pageSize, Control.CRITICAL) });// 分页读取控制
			do {// 循环检索数据

				// Perform the search
				SearchControls searchCtls = new SearchControls(); // Create the

				// 创建搜索控制器
				searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE); // Specify

				String returnedAtts[] = { "name", "distinguishedName", "mail", "mobile" };// 定制返回属性

				searchCtls.setReturningAttributes(returnedAtts); // 设置返回属性集

				NamingEnumeration<SearchResult> results = context.search(base, objectClass, searchCtls); // 查询所有信息

				while (results != null && results.hasMoreElements()) {// 遍历结果集
					SearchResult sr = (SearchResult) results.next();// 得到符合搜索条件的DN
					int count = 0;
					Attributes Attrs = sr.getAttributes();// 得到符合条件的属性集
					Map<String,Object> data = Maps.newHashMap();
					if (Attrs != null) {
						try {
							for (NamingEnumeration<? extends Attribute> ne = Attrs.getAll(); ne.hasMore();) {
								Attribute Attr = (Attribute) ne.next();// 得到下一个属性
								// 读取属性值
								for (NamingEnumeration<?> e = Attr.getAll(); e.hasMore(); count++) {
									data.put(Attr.getID().toString(), e.next().toString());
								}
							}
						} catch (NamingException e) {
							e.printStackTrace();
						}
					}

					datas.add(data);
				}

				Control[] controls = context.getResponseControls();
				if (controls != null) {
					for (int i = 0; i < controls.length; i++) {
						if (controls[i] instanceof PagedResultsResponseControl) {
							PagedResultsResponseControl prrc = (PagedResultsResponseControl) controls[i];
							cookie = prrc.getCookie();
						}
					}
				}
				context.setRequestControls(
						new Control[] { new PagedResultsControl(pageSize, cookie, Control.CRITICAL) });
			} while (cookie != null);

		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return datas;
	}
}
