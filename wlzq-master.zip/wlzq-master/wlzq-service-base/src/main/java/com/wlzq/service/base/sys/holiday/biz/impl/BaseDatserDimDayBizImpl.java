package com.wlzq.service.base.sys.holiday.biz.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wlzq.service.base.sys.holiday.biz.BaseDatserDimDayBiz;
import com.wlzq.service.base.sys.holiday.dao.BaseDatserDimDayDao;
import com.wlzq.service.base.sys.holiday.model.BaseDatserDimDay;

/**
 * BaseDatserDimDayBiz接口实现
 * @author louie
 *
 */
@Service
public class BaseDatserDimDayBizImpl implements BaseDatserDimDayBiz {
	
	@Autowired
	private BaseDatserDimDayDao baseDatserDimDayDao;

	@Override
	public BaseDatserDimDay getNextTradeDay(String day) {
		BaseDatserDimDay baseDatserDimDay = baseDatserDimDayDao.getNextTradeDay(Integer.valueOf(day));
		return baseDatserDimDay;
	}

	@Override
	public boolean isTradeDate(Integer dayId) {
		BaseDatserDimDay q = new BaseDatserDimDay();
		q.setDayId(dayId);
		q.setIsTradeDay(BaseDatserDimDay.YES);
		BaseDatserDimDay d = baseDatserDimDayDao.getByDayId(q);
		if (d != null) {
			return true;
		}
		return false;
	}


	@Override
	public BaseDatserDimDay getLastTradeDay(String day) {
		BaseDatserDimDay baseDatserDimDay = baseDatserDimDayDao.getLastTradeDay(Integer.valueOf(day));
		return baseDatserDimDay;
	}
	
}
