package com.wlzq.service.base.sys.holiday.model;

import java.io.Serializable;
import java.util.Date;


/**
 * 天维度表Entity
 * @author cjz
 * @version 2020-03-05
 */
public class BaseDatserDimDay implements Serializable {
	
	private static final long serialVersionUID = 3980783709997706228L;
	
	private Integer id;
	private Integer dayId;		// 6位天ID,YYYYMMDD
	private Integer dateOrder;		// 天排序字段，用于完成时间序列计算
	private Date calendarDate;		// 日期
	private Integer dayOfMonth;		// 一月中的第几天
	private Integer monthId;		// 1到2位月份ID, 1、2、3到12
	private String monthName;		// 3位大写英文月份缩写
	private String monthNameCn;		// 中文月份
	private Integer yearMonthId;		// 6位年月编号
	private Integer yearMonthOrder;		// 对所有月升序排序，依次分配一个连续自然增长的整数编号
	private String yearMonthNameCn;		// 注意月份为2位，不足需补零
	private Date monthFirstDate;		// 当月第一天日期
	private Date monthLastDate;		// 当月最后一天日期
	private Integer quarterId;		// 季度ID
	private String quarterName;		// 2位季度英文名
	private String quarterNameCn;		// 季度中文名
	private Integer yearQuarterId;		// 5位年季度编号
	private Integer yearQuarterOrder;		// 年季度排序字段，用于完成时间序列计算
	private String yearQuarterName;		// 6位年季度英文名
	private String yearQuarterNameCn;		// 年季度中文名
	private Date quarterFirstDate;		// 当季度第一天日期
	private Date quarterLastDate;		// 当季度最后一天日期
	private Integer yearId;		// 4位年编号
	private Integer yearOrder;		// 年排序字段，用于完成时间序列计算
	private String yearName;		// 年英文名
	private String yearNameCn;		// 年中文名
	private Date yearFirstDate;		// 当年第一天日期
	private Date yearLastDate;		// 当年最后一天日期
	private Integer week;		// 星期1-7
	private Integer isTradeDay;		// 是否交易日
	private Integer isHoliday;		// 是否节假日
	
	private Integer dayIdBegin;//查询使用
	private Integer dayIdEnd;
	
	public BaseDatserDimDay() {
		super();
	}
	
	public static final Integer YES = 1;
	public static final Integer NO = 0;
	
	public static final Integer MON = 1;
	public static final Integer TUE = 2;
	public static final Integer WED = 3;
	public static final Integer THU = 4;
	public static final Integer FRI = 5;
	public static final Integer SAT = 6;
	public static final Integer SUN = 7;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getDayId() {
		return dayId;
	}
	public void setDayId(Integer dayId) {
		this.dayId = dayId;
	}
	public Integer getDateOrder() {
		return dateOrder;
	}
	public void setDateOrder(Integer dateOrder) {
		this.dateOrder = dateOrder;
	}
	public Date getCalendarDate() {
		return calendarDate;
	}
	public void setCalendarDate(Date calendarDate) {
		this.calendarDate = calendarDate;
	}
	public Integer getDayOfMonth() {
		return dayOfMonth;
	}
	public void setDayOfMonth(Integer dayOfMonth) {
		this.dayOfMonth = dayOfMonth;
	}
	public Integer getMonthId() {
		return monthId;
	}
	public void setMonthId(Integer monthId) {
		this.monthId = monthId;
	}
	public String getMonthName() {
		return monthName;
	}
	public void setMonthName(String monthName) {
		this.monthName = monthName;
	}
	public String getMonthNameCn() {
		return monthNameCn;
	}
	public void setMonthNameCn(String monthNameCn) {
		this.monthNameCn = monthNameCn;
	}
	public Integer getYearMonthId() {
		return yearMonthId;
	}
	public void setYearMonthId(Integer yearMonthId) {
		this.yearMonthId = yearMonthId;
	}
	public Integer getYearMonthOrder() {
		return yearMonthOrder;
	}
	public void setYearMonthOrder(Integer yearMonthOrder) {
		this.yearMonthOrder = yearMonthOrder;
	}
	public String getYearMonthNameCn() {
		return yearMonthNameCn;
	}
	public void setYearMonthNameCn(String yearMonthNameCn) {
		this.yearMonthNameCn = yearMonthNameCn;
	}
	public Date getMonthFirstDate() {
		return monthFirstDate;
	}
	public void setMonthFirstDate(Date monthFirstDate) {
		this.monthFirstDate = monthFirstDate;
	}
	public Date getMonthLastDate() {
		return monthLastDate;
	}
	public void setMonthLastDate(Date monthLastDate) {
		this.monthLastDate = monthLastDate;
	}
	public Integer getQuarterId() {
		return quarterId;
	}
	public void setQuarterId(Integer quarterId) {
		this.quarterId = quarterId;
	}
	public String getQuarterName() {
		return quarterName;
	}
	public void setQuarterName(String quarterName) {
		this.quarterName = quarterName;
	}
	public String getQuarterNameCn() {
		return quarterNameCn;
	}
	public void setQuarterNameCn(String quarterNameCn) {
		this.quarterNameCn = quarterNameCn;
	}
	public Integer getYearQuarterId() {
		return yearQuarterId;
	}
	public void setYearQuarterId(Integer yearQuarterId) {
		this.yearQuarterId = yearQuarterId;
	}
	public Integer getYearQuarterOrder() {
		return yearQuarterOrder;
	}
	public void setYearQuarterOrder(Integer yearQuarterOrder) {
		this.yearQuarterOrder = yearQuarterOrder;
	}
	public String getYearQuarterName() {
		return yearQuarterName;
	}
	public void setYearQuarterName(String yearQuarterName) {
		this.yearQuarterName = yearQuarterName;
	}
	public String getYearQuarterNameCn() {
		return yearQuarterNameCn;
	}
	public void setYearQuarterNameCn(String yearQuarterNameCn) {
		this.yearQuarterNameCn = yearQuarterNameCn;
	}
	public Date getQuarterFirstDate() {
		return quarterFirstDate;
	}
	public void setQuarterFirstDate(Date quarterFirstDate) {
		this.quarterFirstDate = quarterFirstDate;
	}
	public Date getQuarterLastDate() {
		return quarterLastDate;
	}
	public void setQuarterLastDate(Date quarterLastDate) {
		this.quarterLastDate = quarterLastDate;
	}
	public Integer getYearId() {
		return yearId;
	}
	public void setYearId(Integer yearId) {
		this.yearId = yearId;
	}
	public Integer getYearOrder() {
		return yearOrder;
	}
	public void setYearOrder(Integer yearOrder) {
		this.yearOrder = yearOrder;
	}
	public String getYearName() {
		return yearName;
	}
	public void setYearName(String yearName) {
		this.yearName = yearName;
	}
	public String getYearNameCn() {
		return yearNameCn;
	}
	public void setYearNameCn(String yearNameCn) {
		this.yearNameCn = yearNameCn;
	}
	public Date getYearFirstDate() {
		return yearFirstDate;
	}
	public void setYearFirstDate(Date yearFirstDate) {
		this.yearFirstDate = yearFirstDate;
	}
	public Date getYearLastDate() {
		return yearLastDate;
	}
	public void setYearLastDate(Date yearLastDate) {
		this.yearLastDate = yearLastDate;
	}
	public Integer getWeek() {
		return week;
	}
	public void setWeek(Integer week) {
		this.week = week;
	}
	public Integer getIsTradeDay() {
		return isTradeDay;
	}
	public void setIsTradeDay(Integer isTradeDay) {
		this.isTradeDay = isTradeDay;
	}
	public Integer getIsHoliday() {
		return isHoliday;
	}
	public void setIsHoliday(Integer isHoliday) {
		this.isHoliday = isHoliday;
	}
	public Integer getDayIdBegin() {
		return dayIdBegin;
	}
	public void setDayIdBegin(Integer dayIdBegin) {
		this.dayIdBegin = dayIdBegin;
	}
	public Integer getDayIdEnd() {
		return dayIdEnd;
	}
	public void setDayIdEnd(Integer dayIdEnd) {
		this.dayIdEnd = dayIdEnd;
	}
	
	
}