package com.wlzq.service.base.sys.biz.impl;

import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wlzq.common.constant.CodeConstant;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.security.RSAUtils;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.service.base.sys.biz.EncryptBiz;
import com.wlzq.service.base.sys.config.RSAConfig;
import com.wlzq.service.base.sys.dto.RSAPublicKeyDto;
import com.wlzq.service.base.sys.utils.AppConfigUtils;

/**
 * EncryptBiz实现类
 * 
 * @author
 * @version 1.0
 */
@Service
public class EncryptBizImpl implements EncryptBiz {
	//敏感信息是否加密
	private static final String CONFIG_USER_INFOENC = "sys.user.infoenc";
	
	@Autowired
	private RSAConfig rsaConfig;

	@Override
	public StatusObjDto<RSAPublicKeyDto> getPublicKey() {
		RSAPublicKey publicKey = RSAUtils.getPublicKey(rsaConfig.getPublicKey());
		String modulus = publicKey.getModulus().toString(16);
		String publicExponent = publicKey.getPublicExponent().toString(16);
		RSAPublicKeyDto publicKeyDto = new RSAPublicKeyDto(modulus,publicExponent);
		
		return new StatusObjDto<RSAPublicKeyDto>(true,publicKeyDto,0,"");
	}

	@Override
	public String encrypt(String value) {
		RSAPublicKey publicKey = RSAUtils.getPublicKey(rsaConfig.getPublicKey());
		String encryptValue = RSAUtils.encryptByPublicKey(value, publicKey);
		return encryptValue;
	}

	@Override
	public String decrypt(String value) {
		if(ObjectUtils.isEmptyOrNull(value)) {
			return null;
		}
		
		String decryptResult = null;
		RSAPrivateKey privateKey = RSAUtils.getPrivateKey(rsaConfig.getPrivateKey());
		if(privateKey != null) {
			decryptResult = RSAUtils.decryptByPrivateKey(value, privateKey);
		}
		return decryptResult;
	}

	@Override
	public String decryptBase64(String value) {
		if(ObjectUtils.isEmptyOrNull(value)) {
			return null;
		}
		
		String decryptResult = null;
		RSAPrivateKey privateKey = RSAUtils.getPrivateKey(rsaConfig.getPrivateKey());
		if(privateKey != null) {
			decryptResult = RSAUtils.decryptByPrivateKeyFromBase64(value, privateKey);
		}
		return decryptResult;
	}
	
	@Override
	public String decryptUser(String value,String appVersion) {
		if(ObjectUtils.isEmptyOrNull(appVersion)) return null;
		appVersion = appVersion.replaceAll("\\.", "");
		Integer subEnd = appVersion.length()>2?2:appVersion.length();
		Integer version = Integer.valueOf(appVersion.substring(0,subEnd));
		Integer isEnc = AppConfigUtils.getInt(CONFIG_USER_INFOENC, 0);
		String decValue = null;
		//需要加密且版本大于
		if(CodeConstant.CODE_YES.equals(isEnc) && rsaConfig.getEncVersion() <= version) {
			decValue = this.decryptBase64(value);
		}else {
			decValue = value;
		}
		return decValue;
	}
	
}
