package com.wlzq.service.base.serialnum;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.wlzq.service.base.serialnum.biz.SerialNumberGenBiz;

/***
 * 默认的流水号生成器
 * @author louie
 * @version 1.0
 */
@Component
public class DefaultSerialNumberGenerator implements ISerialNumberGenerator {
	@Autowired
	private SerialNumberGenBiz serialNumberGenBiz;
	
	public String generate(String key, String template, String remark) {
		Map<String,Object> requestBizData = new HashMap<String, Object>();
		requestBizData.put("serialNumberKey", key);
		requestBizData.put("serialNumberTmpl", template);
		requestBizData.put("comment", remark);
		return serialNumberGenBiz.generator(key, template, remark);
	}

	public List<String> generateBatch(String key, String template, String remark, Integer count) {
		Map<String, Object> requestBizData = new HashMap<String, Object>();
		requestBizData.put("serialNumberKey", key);
		requestBizData.put("serialNumberTmpl", template);
		requestBizData.put("comment", remark);
		requestBizData.put("count", count);
		List<String> list = serialNumberGenBiz.generatorBatch(key, template, remark, count);
		return list;
	}

}
