package com.wlzq.service.base.sys.holiday.biz;

import com.wlzq.service.base.sys.holiday.model.BaseDatserDimDay;

/**
 * HolidayBiz类
 * @author 
 * @version 1.0
 */
public interface BaseDatserDimDayBiz {	
	/**
	 * 获取下一交易日
	 * @param firstWorkDay
	 * @return
	 */
	BaseDatserDimDay getNextTradeDay(String firstWorkDay);

	boolean isTradeDate(Integer dayId);

	/**
	 * 获取上一交易日
	 * @param lastWorkDay
	 * @return
	 */
	BaseDatserDimDay getLastTradeDay(String lastWorkDay);

}
