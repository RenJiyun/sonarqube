package com.wlzq.service.base.serialnum.dao;

import org.apache.ibatis.annotations.Param;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.serialnum.model.SerialNumber;

/**
 * SerialNumberHelper DAO类
 * @author louie
 * @version 1.0
 */
@MybatisScan
public interface SerialNumberDao  extends CrudDao<SerialNumber>{
	
	 /**
	 * 保存信息 
	 * @param datas
	 * @return
	 */
	 Integer create(SerialNumber bsCreditDto);
	 
	 /**
 	 * 保存信息
 	 * @param datas
 	 * @return
 	 */
 	 int update(SerialNumber bsCreditDto); 	  	 


	/**
	 * 根据规则可以查询规则
	 * @param serialNumberKey 流水号生产规则key,唯一不能重复
	 * @return
	 */
	SerialNumber getRoleByKey(@Param("serialNumberKey")String serialNumberKey);
}
