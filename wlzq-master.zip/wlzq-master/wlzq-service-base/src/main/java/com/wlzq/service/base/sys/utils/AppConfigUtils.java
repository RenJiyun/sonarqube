package com.wlzq.service.base.sys.utils;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.tomcat.jni.Global;

import com.google.common.collect.Lists;
import com.wlzq.common.utils.DateUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.exception.BizException;
import com.wlzq.service.base.redis.DictRedis;
import com.wlzq.service.base.redis.SysRedis;
import com.wlzq.service.base.sys.dao.SysAppConfigDao;
import com.wlzq.service.base.sys.dao.SysNDictDao;
import com.wlzq.service.base.sys.dto.DictsDto;
import com.wlzq.service.base.sys.model.SysNDict;

/**
 * 应用配置工具类
 * @author Administrator
 *
 */
public class AppConfigUtils {
	
	/**
	 * 获取String型配置
	 * @param 配置key
	 * @return
	 */
	public static String get(String key) {
		Optional.ofNullable(key).orElseThrow(() -> BizException.COMMON_PARAMS_NOT_NULL);
		if (SysRedis.APP_CONFIG.exists(key)) {
			return (String) SysRedis.APP_CONFIG.get(key);
		} else {
			String value = SpringApplicationContext.getBean(SysAppConfigDao.class).getByKey(key);
			SysRedis.APP_CONFIG.set(key, value);
			return value;
		}
	}
	
	/**
	 * 仅从缓存获取String型配置
	 * @param 配置key
	 * @return
	 */
	public static String getFromCache(String key,String defaultValue) {
		Optional.ofNullable(key).orElseThrow(() -> BizException.COMMON_PARAMS_NOT_NULL);
		if (SysRedis.APP_CONFIG.exists(key)) {
			return (String) SysRedis.APP_CONFIG.get(key);
		}
		return defaultValue;
	}
	
	/**
	 * 获取Integer型配置
	 * @param 配置key
	 * @return
	 */
	public static Integer getInt(String key) {
		String result = get(key);
		try {
			return Integer.valueOf(result);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 获取Long型配置
	 * @param 配置key
	 * @return
	 */
	public static Long getLong(String key) {
		String result = get(key);
		try {
			return Long.valueOf(result);
		} catch (Exception e) {
			
			return null;
		}
	}
	
	/**
	 * 获取Date型配置
	 * @param 配置key
	 * @return
	 */
	public static Date getDate(String key) {
		return getDate(key, null);
	}

	/**
	 * 获取Date型配置
	 * @param key 配置key
	 * @param format 日期格式化
	 * @return
	 */
	public static Date getDate(String key,String format) {
		String result = get(key);
		return DateUtils.parseDate(result, format);
	}
	
	/**
	 * 获取List<String>型配置
	 * @param key  配置key
	 * @param split 分隔符
	 * @return
	 */
	public static List<String> getList(String key,String split) {
		if (ObjectUtils.isEmptyOrNull(get(key))) {
			return Lists.newArrayList();
		}
		List<String> result = Lists.newArrayList(get(key).split(split));
		result.forEach(e -> e = e.trim());
		return result;
	}
	
	public static List<Integer> getIntegerList (String key,String split) {
		if (ObjectUtils.isEmptyOrNull(get(key))) {
			return Lists.newArrayList();
		}
		List<String> result = Lists.newArrayList(get(key).split(split));
		List<Integer> intList = Lists.newArrayList();
		try {
			intList = result.stream().map(Integer :: valueOf).collect(Collectors.toList());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return intList;
	}
	

	/**
	 * 获取String型配置
	 * @param key 配置key
	 * @param defaultValue 默认值
	 * @return
	 */
	public static String get(String key,String defaultValue) {
		String result = get(key);
		return ObjectUtils.isNotEmptyOrNull(result)?result:defaultValue;
	}
	
	/**
	 * 获取Integer型配置
	 * @param key 配置key
	 * @param defaultValue 默认值
	 * @return
	 */
	public static Integer getInt(String key,Integer defaultValue) {
		Integer result = getInt(key);
		return ObjectUtils.isNotEmptyOrNull(result)?result:defaultValue;
	}

	/**
	 * 获取Long型配置
	 * @param key 配置key
	 * @param defaultValue 默认值
	 * @return
	 */
	public static Long getLong(String key,Long defaultValue) {
		Long result = getLong(key);
		return ObjectUtils.isNotEmptyOrNull(result)?result:defaultValue;
	}
	
	/**
	 * 获取字典
	 * @param 配置key
	 * @return
	 */
	public static String getDict(String type, String value) {
		String result = new String();
		if (ObjectUtils.isEmptyOrNull(value) || ObjectUtils.isEmptyOrNull(type)) {
			return result;
		}
		String key = type + ":" + value;
		if (DictRedis.SYS_DICT.exists(key)) {
			return (String) DictRedis.SYS_DICT.get(key); 
		} else {
			SysNDictDao dictDao = SpringApplicationContext.getBean(SysNDictDao.class);
			SysNDict entity = new SysNDict();
			entity.setType(type);
			entity.setValue(value);
			entity = dictDao.get(entity);
			if (entity == null) {
				return result;
			}
			DictRedis.SYS_DICT.set(key, Optional.ofNullable(entity.getLabel()).orElse(""));
			return Optional.ofNullable(entity.getLabel()).orElse("");
		}
	}

	/**
	 * 获取字典信息
	 * @param type
	 * @param value
	 * @return
	 */
	public static SysNDict getDictInfo(String type, String value) {
		if (ObjectUtils.isEmptyOrNull(value) || ObjectUtils.isEmptyOrNull(type)) {
			return null;
		}
		String key = type + ":" + value;
		if (DictRedis.SYS_DICT_INFO.exists(key)) {
			return (SysNDict) DictRedis.SYS_DICT_INFO.get(key); 
		} else {
			SysNDictDao dictDao = SpringApplicationContext.getBean(SysNDictDao.class);
			SysNDict entity = new SysNDict();
			entity.setType(type);
			entity.setValue(value);
			entity = dictDao.get(entity);
			if (entity == null) {
				return null;
			}
			DictRedis.SYS_DICT_INFO.set(key, entity);
			return entity;
		}
	}

	/**
	 * 获取字典信息
	 * @param type
	 * @param value
	 * @return
	 */
	public static List<SysNDict> getDictList(String type) {
		if (ObjectUtils.isEmptyOrNull(type)) {
			return null;
		}
		String key = type;
		if (DictRedis.SYS_DICT_LIST.exists(key)) {
			DictsDto dictsDto = (DictsDto) DictRedis.SYS_DICT_LIST.get(key); 
			return dictsDto.getDicts();
		} else {
			SysNDictDao dictDao = SpringApplicationContext.getBean(SysNDictDao.class);
			SysNDict entity = new SysNDict();
			entity.setType(type);
			List<SysNDict> dicts = dictDao.findList(entity);
			DictsDto dictsDto = new DictsDto();
			dictsDto.setDicts(dicts);
			DictRedis.SYS_DICT_LIST.set(key, dictsDto);
			return dicts;
		}
	}
	 
}
