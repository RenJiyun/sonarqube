package com.wlzq.service.base.sys.biz;

import java.util.Map;

/**
 *  ExternalBiz类
 * @author 
 * @version 1.0
 */
public interface ExternalRequestBiz {	

	public  <T extends Object> String doGet(String url, Map<String, T> params,String charSet) ;

	public  <T extends Object> String doPost(String url, Map<String, T> params,	Map<String, String> reqcookies,Map<String, String> header,String charset) ;

	public  <T extends Object> String doPost(String url, String body,Map<String, String> header) ;

}
