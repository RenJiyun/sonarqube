package com.wlzq.service.base.crh;

import java.util.Map;

import com.google.common.collect.Maps;
import com.wlzq.common.constant.CodeConstant;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.SdHttpClientUtils;
import com.wlzq.common.utils.SdHttpClientUtils.HttpResult;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.dto.ResultDto;

public class CrhUtils {
	/**
	 * 业务请求成功返回代码
	 */
	private static Integer SUCCESS_CODE = 0;
	/**
	 * 
	 * @param funcNo 功能号
	 * @param client 登录后返回的cookie中的_client
	 * @param params 参数
	 * @return
	 */
	public static ResultDto doGet(String funcNo,String client,Map<String,Object> params) {
		ResultDto result = new ResultDto();
		CrhConfig config = SpringApplicationContext.getBean(CrhConfig.class);
		if(config == null || ObjectUtils.isEmptyOrNull(config.getUrl())) {
			result.setCode(CodeConstant.CODE_NO);
			result.setMsg("未配置财人汇服务地址");
			return result;
		}
		
		String url = config.getUrl()+funcNo;
		Map<String,String> cookies = Maps.newHashMap();
		if(ObjectUtils.isNotEmptyOrNull(client)) {
			cookies.put("_client", client);
		}
		HttpResult response = SdHttpClientUtils.doGetReturnStateCode(url, params,cookies,"UTF-8");
		Map<String,Object> returnResult = JsonUtils.json2Map((String)response.content);
		if(returnResult != null) {
			Integer errorNo =  (Integer) returnResult.get("error_no");
			if(errorNo.equals(SUCCESS_CODE)) {
				result.setCode(CodeConstant.CODE_NO);
				result.setData(returnResult);
			}else {
				result.setCode(errorNo);
				String errorInfo = (String) returnResult.get("error_info");
				String errorInfo2 = (String) returnResult.get("errorInfo");
				String finalErrorInfo = ObjectUtils.isNotEmptyOrNull(errorInfo)?errorInfo:errorInfo2;
				result.setMsg(finalErrorInfo);
			}
		}else {
			result.setCode(CodeConstant.CODE_NO);
			result.setMsg("财人汇服务请求失败");
		}
		
		return result;
	}
}
