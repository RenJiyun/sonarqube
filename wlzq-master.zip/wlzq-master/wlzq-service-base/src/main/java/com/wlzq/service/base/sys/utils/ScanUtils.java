package com.wlzq.service.base.sys.utils;

import com.google.common.collect.Sets;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.type.ClassMetadata;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.core.type.classreading.SimpleMetadataReaderFactory;
import org.springframework.util.ClassUtils;
import org.springframework.util.SystemPropertyUtils;

import java.util.Set;
import java.util.stream.Collectors;

/**
 * 利用spring-core扫描指定包下面的类
 */
public class ScanUtils {
    /*用于解析资源文件的策略接口*/
    private static final ResourcePatternResolver RESOLVER = new PathMatchingResourcePatternResolver();
    /*MetadataReader的实现都并未public暴露出来，所以我们若想得到它的实例，就只能通过此工厂*/
    private static final MetadataReaderFactory METADATA_READER_FACTORY = new SimpleMetadataReaderFactory();

    /**
     * 扫描指定路径下的所有类
     *
     * @param basePackage  扫描路径
     * @param mustConcrete 扫描的类是否是具体的类，即非接口、非抽象类
     * @return 扫描到的类
     */
    public static Set<Class<?>> scanClass(String basePackage, boolean mustConcrete) {
        String basePath = ClassUtils.convertClassNameToResourcePath(SystemPropertyUtils.resolvePlaceholders(basePackage));
        String scanPath = ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX + basePath + "/**/*.class";

        Set<Class<?>> classes = Sets.newHashSet();
        try {
            Resource[] resources = RESOLVER.getResources(scanPath);
            for (Resource resource : resources) {
                if (resource.isReadable()) {
                    MetadataReader metadataReader = METADATA_READER_FACTORY.getMetadataReader(resource);
                    ClassMetadata classMetadata = metadataReader.getClassMetadata();
                    if (!mustConcrete || classMetadata.isConcrete()) {
                        classes.add(Class.forName(classMetadata.getClassName()));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return classes;
    }

    /**
     * 扫描指定路径下指定超类的所有子类
     *
     * @param basePackage  扫描路径
     * @param superClass   扫描的类的父类
     * @param mustConcrete 扫描的类是否是具体的类，即非接口、非抽象类
     * @return 扫描到的类
     */
    public static Set<Class<?>> scanSubClass(String basePackage, Class<?> superClass, boolean mustConcrete) {
        Set<Class<?>> scanClass = scanClass(basePackage, mustConcrete);

        return scanClass.stream().filter(superClass::isAssignableFrom).collect(Collectors.toSet());
    }
}
