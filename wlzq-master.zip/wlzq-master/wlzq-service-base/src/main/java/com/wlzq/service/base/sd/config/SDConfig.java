package com.wlzq.service.base.sd.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:sdplateform.properties"}) 
@ConfigurationProperties(prefix="sd.service.url")
public class SDConfig {
	/**
	 * 微信服务根目录
	 */
	private String wechatServiceRoot;
	/**
	 * 商城服务根目录
	 */
	private String storeServiceRoot;

	/**
	 * 业务办理服务根目录
	 */
	private String onlineHallServiceRoot;
	
	/**
	 * 行情交易服务根目录
	 */
	private String marketServiceRoot;
	
	public String getWechatServiceRoot() {
		return wechatServiceRoot;
	}
	public void setWechatServiceRoot(String wechatServiceRoot) {
		this.wechatServiceRoot = wechatServiceRoot;
	}
	public String getStoreServiceRoot() {
		return storeServiceRoot;
	}
	public void setStoreServiceRoot(String storeServiceRoot) {
		this.storeServiceRoot = storeServiceRoot;
	}
	public String getOnlineHallServiceRoot() {
		return onlineHallServiceRoot;
	}
	public void setOnlineHallServiceRoot(String onlineHallServiceRoot) {
		this.onlineHallServiceRoot = onlineHallServiceRoot;
	}
	public String getMarketServiceRoot() {
		return marketServiceRoot;
	}
	public void setMarketServiceRoot(String marketServiceRoot) {
		this.marketServiceRoot = marketServiceRoot;
	}

}
