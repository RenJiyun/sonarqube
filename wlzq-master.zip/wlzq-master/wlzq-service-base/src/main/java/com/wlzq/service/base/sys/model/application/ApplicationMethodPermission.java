package com.wlzq.service.base.sys.model.application;

import java.io.Serializable;
import java.util.List;

/**
 * 方法权限
 * @author louie
 * @version 2017-11-07
 */
public class ApplicationMethodPermission  implements Serializable {
	
	private static final long serialVersionUID = 148951428473L;
	private List<String> keys;		//key
	private String method;		// 方法
	private List<String> ips;		// ip
	
	public ApplicationMethodPermission() {
		super();
	}

	public List<String> getKeys() {
		return keys;
	}

	public void setKeys(List<String> keys) {
		this.keys = keys;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public List<String> getIps() {
		return ips;
	}

	public void setIps(List<String> ips) {
		this.ips = ips;
	}
	
}