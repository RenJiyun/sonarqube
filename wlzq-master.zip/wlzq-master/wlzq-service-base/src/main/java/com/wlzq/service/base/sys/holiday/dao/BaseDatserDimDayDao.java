package com.wlzq.service.base.sys.holiday.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.holiday.model.BaseDatserDimDay;

/**
 * 天维度表DAO接口
 * @author cjz
 * @version 2020-03-05
 */
@MybatisScan
public interface BaseDatserDimDayDao extends CrudDao<BaseDatserDimDay> {
	
	public BaseDatserDimDay getByDayId(BaseDatserDimDay datserDimDay);
	
	public List<BaseDatserDimDay> getLastTradeDays(BaseDatserDimDay datserDimDay);
	
	public Integer getYearMonthId(Integer yearMonthOrder);

	public List<BaseDatserDimDay> findListBtwDay(BaseDatserDimDay datserDimDay);

	public List<BaseDatserDimDay> getNextTradeDays(BaseDatserDimDay datserDimDay);
	
	public BaseDatserDimDay getNextTradeDay(@Param("dayId") Integer dayId);

	public BaseDatserDimDay getLastTradeDay(@Param("dayId") Integer dayId);
}