package com.wlzq.service.base.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.retry.interceptor.RetryInterceptorBuilder;
import org.springframework.retry.interceptor.StatefulRetryOperationsInterceptor;

import feign.Request;
import feign.Retryer;

@Configuration
public class CloudConfig {
	@Bean
    Retryer feignRetryer() {
        return Retryer.NEVER_RETRY;
    }
	
	@Bean
	Request.Options requestOptions(ConfigurableEnvironment env){
	    int ribbonReadTimeout = env.getProperty("ribbon.ReadTimeout", int.class, 60000);
	    int ribbonConnectionTimeout = env.getProperty("ribbon.ConnectTimeout", int.class, 60000);

	    return new Request.Options(ribbonConnectionTimeout, ribbonReadTimeout);
	}
	
	@Bean
	StatefulRetryOperationsInterceptor configServerRetryInterceptor() {
		return RetryInterceptorBuilder.stateful()
		  .maxAttempts(1)
		  .build();
	}
	
}
