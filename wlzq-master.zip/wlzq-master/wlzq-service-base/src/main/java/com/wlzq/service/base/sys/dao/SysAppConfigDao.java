package com.wlzq.service.base.sys.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.wlzq.common.model.sys.SysAppConfig;
import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;

/**
 * 配置管理2DAO接口
 * @author zhaozx
 * @version 2019-06-21
 */
@MybatisScan
public interface SysAppConfigDao extends CrudDao<SysAppConfig> {
	
	List<String> findAllPlatform();
	
	String getByKey(String key);
	
}