package com.wlzq.service.base.serialnum.exception;

import com.wlzq.core.exception.BizException;

public class SerialException extends BizException{

	private static final long serialVersionUID = 8221535222331649L;
	
	/** 流水号生成异常 */
	public static final SerialException SERIAL_NUMBER_GEN_ERROR = new SerialException(20030001, "产生流水号错误");
	
	protected SerialException(int code, String msg) {
		super(code, msg);
	}

}
