package com.wlzq.service.base.sys.basesensitiveword.dao;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.basesensitiveword.model.BaseSensitiveword;

/**
 * 敏感词DAO接口
 * @author cjz
 * @version 2018-05-18
 */
@MybatisScan
public interface BaseSensitivewordDao extends CrudDao<BaseSensitiveword> {
	
}