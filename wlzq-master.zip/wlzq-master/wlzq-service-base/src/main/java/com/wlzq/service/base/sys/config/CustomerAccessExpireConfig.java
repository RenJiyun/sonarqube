package com.wlzq.service.base.sys.config;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import com.google.common.collect.Maps;

@Component
@ConfigurationProperties(prefix = "account.customer.login") 
public class CustomerAccessExpireConfig {
	private Integer  defaultExpire = 1;
	
	private String expireConfig;
	/**
	 * 访问过期时间，key:类型（1：投顾），value:天数
	 */
	private Map<Integer,Integer> expireTime;
	
	@PostConstruct
	public void initExpireTime() {
		if(expireTime == null) {
			expireTime = Maps.newHashMap();
		}
	}
	
	public Integer getExpireTime(Integer type) {
		return expireTime.containsKey(type)?expireTime.get(type):1;
	}

	public String getExpireConfig() {
		return expireConfig;
	}

	public void setExpireConfig(String expireConfig) {
		if(expireTime == null) {
			expireTime = Maps.newHashMap();
		}
		if(expireConfig == null || expireConfig.equals("")) return;
		String[] values = expireConfig.split(",");
		for(String value:values) {
			String[] expire = value.split(":");
			if(expire.length != 2) continue;
			Integer type = Integer.valueOf(expire[0]);
			Integer time = Integer.valueOf(expire[1]);
			expireTime.put(type, time);
		}
	}

	public Integer getDefaultExpire() {
		return defaultExpire;
	}

	public void setDefaultExpire(Integer defaultExpire) {
		this.defaultExpire = defaultExpire;
	}
	
}
