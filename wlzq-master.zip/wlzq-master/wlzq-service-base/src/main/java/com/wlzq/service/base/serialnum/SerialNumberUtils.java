package com.wlzq.service.base.serialnum;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import com.wlzq.core.SpringApplicationContext;

/**
 * 序列号产生工具。<br>
 * 注意：序列号模板和备注仅在第一创建时有效，用户初始化数据配置<br>
 * 在第二次执行时，模板使用数据库中已有的，备注也不会被更新到数据库。
 * 
 * @version 1.0
 */
public abstract class SerialNumberUtils {


	private static ISerialNumberGenerator snGenerator = null;
	private static ReentrantLock lock = new ReentrantLock();

	/** 添加单据系统默认产生规则 */
	static {
		snRuleTable = new HashMap<>();
		
		/*** 支付平台  start ****/
		
		/** 支付平台对外流水单据号 */
		addRule("payment_order_no", "string:101,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.支付平台对外流水单据号");
		/** 微信公众号支付订单流水号 */
		addRule("payment_wechat_jsapi_order_no", "string:102,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.公众号内支付商家订单号");
		/** 微信原生扫码支付订单流水号 */
		addRule("payment_wechat_native_order_no", "string:103,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.公众号支付商家订单号");
		/** 保证金支付订单流水号 */
		addRule("payment_deposit_order_no", "string:104,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.保证金支付商家订单号");
		/** 保证金预支付id */
		addRule("payment_deposit_prepay_id", "string:dep105,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.保证金预支付id");
		/** 保证金扣费流水号 */
		addRule("payment_deposit_trans_id", "string:dep106,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.保证金扣费流水号");
		/** 微信红包订单号 */
		addRule("payment_redenvelope_order_no", "string:107,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.微信红包订单号");
		/** 微信app支付订单流水号 */
		addRule("payment_wechat_app_order_no", "string:108,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.微信app支付商家订单号");
		/** 微信h5支付订单流水号 */
		addRule("payment_wechat_h5_order_no", "string:109,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.微信h5支付商家订单号");
		/** 支付宝app支付订单流水号 */
		addRule("payment_ali_app_order_no", "string:110,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.支付宝app支付商家订单号");
		/** 支付宝h5支付订单流水号 */
		addRule("payment_ali_h5_order_no", "string:111,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.支付宝h5支付商家订单号");
		/** 支付宝免密支付订单流水号 */
		addRule("payment_ali_cycle_order_no", "string:112,date:yyyyMMdd,sequence:10|year,rnd:4", "支付流水号.支付宝免密支付商家订单号");
		/** 支付平台代扣协议流水号 */
		addRule("payment_agreement_out_order_no", "string:130,date:yyyyMMdd,sequence:10|year,rnd:4", "支付代扣协议流水号.支付平台代扣协议内部流水号");
		/*** 支付平台  end ****/
		
		/*** 账户平台  start ****/
		
		addRule("point_serial_no", "string:201,date:yyyyMMdd,sequence:10|year,rnd:4", "积分流水号.积分增减流水号");
		
		/*** 账户平台  end ****/
		
		/*** 活动平台  start ****/
		
		/** 答题有奖领奖流水号 */
		addRule("activity_answer_prize_recieve_no", "string:301,date:yyyyMMdd,sequence:10|year,rnd:4", "答题有奖流水号.答题有奖领奖流水号");
		/** 猜涨跌连胜领奖流水号 */
		addRule("activity_guess_prize_recieve_no", "string:302,date:yyyyMMdd,sequence:10|year,rnd:4", "猜涨跌连胜流水号.猜涨跌连胜领奖流水号");
		
		/*** 活动平台  end ****/
		
		/*** 服务平台  start ****/
		
		/** 投顾平台打赏流水号 */
		addRule("service_invest_adviser_reward_order_no", "string:601,date:yyyyMMdd,sequence:10|year,rnd:4", "投顾平台流水号.投顾打赏流水号");
		/** 投顾平台订阅流水号 */
		addRule("service_invest_sub_order_no", "string:601,date:yyyyMMdd,sequence:10|year,rnd:4", "投顾平台流水号.投顾平台订阅流水号");
		
		/*** 服务平台  end ****/
		

		/** 理财平台订单号 */
		addRule("financing_order_no", "string:701,date:yyyyMMdd,sequence:10|year,rnd:4", "理财平台订单流水号.理财平台订单流水号");
		
		/** 理财平台预约定投缓单号*/
		addRule("financing_ration_time_template_no", "string:719,date:yyyyMMdd,sequence:10|year,rnd:4", "理财平台预约定投缓单号.理财平台预约定投缓单号");
		
		/** 增值服务业务订单流水号 */
		addRule("vas_sub_order_no", "string:401,date:yyyyMMdd,sequence:10|year,rnd:4", "增值服务流水号.增值服务订阅流水号");
		
		/** 增值服务业务订单流水号 */
		addRule("fadviser_order_no", "string:801,date:yyyyMMdd,sequence:10|year,rnd:4", "基金投顾流水号.基金投顾订单流水号");
		
		/** 增值服务业务订单流水号 */
		addRule("fadviser_order_no", "string:801,date:yyyyMMdd,sequence:10|year,rnd:4", "基金投顾流水号.基金投顾订单流水号");
		
		/**理财平台订单验证码短信编号*/
		addRule("financing_order_checkcode_smsno", "string:720,date:yyyyMMdd,sequence:10|year,rnd:4", "理财平台订单验证码短信编号.理财平台订单验证码短信编号");
	}
    
	/***
	 * 根据规则key 产生一个序列号
	 * 
	 * @param key
	 * @return
	 */
	public static String genSn(String key) {
		SnRule rule = snRuleTable.get(key);
		if (rule == null) {
			throw new RuntimeException("流水表编号不存在");
		}
		return getSerialNumberGenerator().generate(rule.getKey(), rule.getRule(), rule.getRemark());
	}

	/***
	 * 根据 规则key ，批量产生序列号
	 * 
	 * @param key
	 * @param count
	 *            产生的数量
	 * @return
	 */
	public static List<String> genBatchSn(String key, Integer count) {
		count = (count == null || count <= 0) ? 1 : count;
		SnRule rule = snRuleTable.get(key);
		if (rule == null) {
			throw new RuntimeException("流水表编号不存在");
		}
		return getSerialNumberGenerator().generateBatch(rule.getKey(), rule.getRule(), rule.getRemark(), count);
	}

	private static ISerialNumberGenerator getSerialNumberGenerator() {
		if (snGenerator == null) {
			try {
				lock.lock();

				if (snGenerator == null) {
					snGenerator = getBean(ISerialNumberGenerator.class);
					if (snGenerator == null) {
						snGenerator = new DefaultSerialNumberGenerator();
					}
				}
			} finally {
				lock.unlock();
			}

		}
		return snGenerator;
	}

	private static <T> T getBean(Class<T> clazz) {
		try {
			return SpringApplicationContext.getBean(clazz);
		} catch (Exception e) {
			// e.printStackTrace();
			// 这里不需要输出异常。因为无法获取到Spring的实现类，就自动构造相应类。
			return null;
		}
	}

	/** 序列号规则 */
	private static class SnRule {
		private String key;
		private String rule;
		private String remark;

		public SnRule(String key, String rule, String remark) {
			super();
			this.key = key;
			this.rule = rule;
			this.remark = remark;
		}

		public String getKey() {
			return key;
		}

		public String getRule() {
			return rule;
		}

		public String getRemark() {
			return remark;
		}
	}

	/***
	 * 序列号生成规则表
	 */
	private static HashMap<String, SnRule> snRuleTable;

	/***
	 * 添加规则
	 * 
	 * @param prex
	 *            前缀
	 * @param key
	 * @param rule
	 * @param remark
	 */
	private static void addRule(String key, String rule, String remark) {
		snRuleTable.put(key, new SnRule(key, rule, remark));
	}

	/** 支付流水号.支付平台对外流水单据号 */
	public static final String getPayOrderNo() {
		return genSn("payment_order_no");
	}

	/** 微信公众号支付订单流水号 */
	public static String getWechatJsApiPaymentOrderNo() {
		return genSn("payment_wechat_jsapi_order_no");
	}
	
	/** 微信原生扫码支付订单流水号 */
	public static String getWechatNativePaymentOrderNo() {
		return genSn("payment_wechat_native_order_no");
	}

	/** 微信app支付订单流水号 */
	public static String getWechatAppPaymentOrderNo() {
		return genSn("payment_wechat_app_order_no");
	}

	/** 微信h5支付订单流水号 */
	public static String getWechatH5PaymentOrderNo() {
		return genSn("payment_wechat_h5_order_no");
	}
	
	/** 保证金支付订单流水号 */
	public static String getDepositPaymentOrderNo() {
		return genSn("payment_deposit_order_no");
	}

	/** 支付宝app支付订单流水号 */
	public static String getAliAppPaymentOrderNo() {
		return genSn("payment_ali_app_order_no");
	}
	
	/** 支付宝h5支付订单流水号 */
	public static String getAliH5PaymentOrderNo() {
		return genSn("payment_ali_h5_order_no");
	}
	
	/** 支付宝免密支付订单流水号 */
	public static String getAliCyclePaymentOrderNo() {
		return genSn("payment_ali_cycle_order_no");
	}
	
	/** 保证金预支付id */
	public static String getDepositPaymentPrepayId() {
		return genSn("payment_deposit_prepay_id");
	}

	/** 保证金扣费流水号 */
	public static String getDepositPaymentTransId() {
		return genSn("payment_deposit_trans_id");
	}
	
	/** 积分增减流水号 */
	public static String getPointSerialNo() {
		return genSn("point_serial_no");
	}

	/** 答题有奖领奖流水号 */
	public static String getActivityAnswerPrizeRecieveNo() {
		return genSn("activity_answer_prize_recieve_no");
	}
	
	/** 微信红包订单号 */
	public static String getRedEnvelopeNo() {
		return genSn("payment_redenvelope_order_no");
	}

	/** 猜涨跌领奖流水号 */
	public static String getActivityGuessPrizeRecieveNo() {
		return genSn("activity_guess_prize_recieve_no");
	}
	
	/** 投顾打赏流水号 */
	public static String getServiceAdviserRewardOrderNo() {
		return genSn("service_invest_adviser_reward_order_no");
	}

	/** 投顾平台订阅流水号 */
	public static String getServiceInvestSubOrderNo() {
		return genSn("service_invest_sub_order_no");
	}
	
	/** 理财平台订单号 */
	public static String getFinancingOrderNo() {
		return genSn("financing_order_no");
	}
	
	/**理财平台预约定投缓单号*/
	public static String getFinancingRationTimeTemplateNo() {
		return genSn("financing_ration_time_template_no");
	}
	
	/**理财平台预约定投缓单号*/
	public static String getVasSubOrderNo() {
		return genSn("vas_sub_order_no");
	}
	
	/**基金投顾订单号*/
	public static String getFadviserOrderNo() {
		return genSn("fadviser_order_no");
	}
	
	/**基金投顾订单号*/
	public static String getPaymentAgreementOutOrderNo() {
		return genSn("payment_agreement_out_order_no");
	}
	
	/** 订单验证码短信编号 */
	public static String getFinOrderCheckCodeSmsNo() {
		return genSn("financing_order_checkcode_smsno");
	}
}
