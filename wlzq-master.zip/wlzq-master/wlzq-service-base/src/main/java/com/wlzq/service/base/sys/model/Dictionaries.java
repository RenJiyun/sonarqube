package com.wlzq.service.base.sys.model;

/**
 * Dictionaries 实体类
 * @author  2017-8-16 16:08:08
 * @version 1.0
 */
public class Dictionaries{
	
	//columns START
	/**name*/
	private java.lang.String name;	
	/**code*/
	private java.lang.String code;	
	/**value*/
	private java.lang.String value;	
	/**ordyBy*/
	private java.lang.Long ordyBy;	
	/**parentId*/
	private java.lang.String parentId;	
	/**dicLevel*/
	private java.lang.Long dicLevel;	
	/**parentCode*/
	private java.lang.String parentCode;	
	//columns END

	public java.lang.String getName() {
		return this.name;
	}
	
	public void setName(java.lang.String value) {
		this.name = value;
	}

	public java.lang.String getCode() {
		return this.code;
	}
	
	public void setCode(java.lang.String value) {
		this.code = value;
	}

	public java.lang.String getValue() {
		return this.value;
	}
	
	public void setValue(java.lang.String value) {
		this.value = value;
	}

	public java.lang.Long getOrdyBy() {
		return this.ordyBy;
	}
	
	public void setOrdyBy(java.lang.Long value) {
		this.ordyBy = value;
	}

	public java.lang.String getParentId() {
		return this.parentId;
	}
	
	public void setParentId(java.lang.String value) {
		this.parentId = value;
	}

	public java.lang.Long getDicLevel() {
		return this.dicLevel;
	}
	
	public void setDicLevel(java.lang.Long value) {
		this.dicLevel = value;
	}

	public java.lang.String getParentCode() {
		return this.parentCode;
	}
	
	public void setParentCode(java.lang.String value) {
		this.parentCode = value;
	}

}

