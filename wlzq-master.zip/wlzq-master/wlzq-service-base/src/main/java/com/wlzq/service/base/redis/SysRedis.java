package com.wlzq.service.base.redis;

import com.wlzq.service.base.sys.RedisFacadeAbstract;

public  class SysRedis  extends RedisFacadeAbstract {

	/**app信息 */
	public static final SysRedis APP_INFO = new SysRedis("sys:application:info:",30*24*3600);
	/**app方法信息 */
	public static final SysRedis APP_METHODS = new SysRedis("sys:application:methods:",60);
	/**app key权限信息 */
	public static final SysRedis APP_KEY_PERMISSION = new SysRedis("sys:application:key:",30*24*3600);
	/**验证码信息，key:id,value:code */
	public static final SysRedis SYS_VERIFY_CODE = new SysRedis("sys:verify:code:",300);
	/**系统参数配置，key:string,value:string**/
	public static final SysRedis APP_CONFIG = new SysRedis("sys:application:config:",2*60);
	
	private String redisPrefix;
	private int timeoutSeconds;

	private SysRedis(String redisPrefix) {
		this.redisPrefix = redisPrefix;
	}

	private SysRedis(String redisPrefix,int timeoutSeconds) {
		this.redisPrefix = redisPrefix;
		this.timeoutSeconds = timeoutSeconds;
	}
	
	@Override
	protected String getRedisPrefix() {
		return redisPrefix;
	}

	@Override
	protected int getTimeoutSeconds() {
		return timeoutSeconds;
	}
	
}