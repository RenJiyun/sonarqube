package com.wlzq.service.base.sys.utils;

import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.Maps;
import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.service.base.sys.config.ImageConfig;

public class ImageUtils {
	public static ResultDto uploadImage(String base64Image) {
		ImageConfig imageConfig = SpringApplicationContext.getBean(ImageConfig.class);
		String method = "base.image.upload";
		Map<String,Object> busparams = new HashMap<String,Object>();
		busparams.put("image", base64Image);
		Map<String,Object> params = Maps.newHashMap();
		params.put("method", method);
		params.put("image",base64Image);
		String upResult = HttpClientUtils.doPost(imageConfig.getUploadUrl(), params);
		ResultDto result = JsonUtils.json2Bean(upResult, ResultDto.class);
		return result;
	}
	
	public static String getImageUrl(String imageKey) {
		if(ObjectUtils.isEmptyOrNull(imageKey)) return null;
		
		ImageConfig imageConfig = SpringApplicationContext.getBean(ImageConfig.class);
		String imageUrl = imageConfig.getRootUrl()+imageKey;
		
		return imageUrl;
	}
	
	public static String getImageLocalUrl(String imageKey) {
		if(ObjectUtils.isEmptyOrNull(imageKey)) return null;
		
		ImageConfig imageConfig = SpringApplicationContext.getBean(ImageConfig.class);
		String imageUrl = imageConfig.getRootLocalUrl()+imageKey;
		
		return imageUrl;
	}
	
	public static String getFileUrl(String fileKey) {
		if(ObjectUtils.isEmptyOrNull(fileKey)) return null;
		
		ImageConfig imageConfig = SpringApplicationContext.getBean(ImageConfig.class);
		String fileUrl = imageConfig.getFileRootUrl()+fileKey;
		
		return fileUrl;
	}
}
