package com.wlzq.service.base.mq.consumer;

@SuppressWarnings("rawtypes")
public class MessageConsumer {
	/**
	 * messagebody转换的对象类
	 */
	private  Class entityClass;
	/**
	 * 消息消费处理
	 */
	private MessageConsumerHandler consumer;
	public MessageConsumer(Class entityClass, MessageConsumerHandler consumer) {
		super();
		this.entityClass = entityClass;
		this.consumer = consumer;
	}
	public Class getEntityClass() {
		return entityClass;
	}
	public void setEntityClass(Class entityClass) {
		this.entityClass = entityClass;
	}
	public MessageConsumerHandler getConsumer() {
		return consumer;
	}
	public void setConsumer(MessageConsumerHandler consumer) {
		this.consumer = consumer;
	}
	
}
