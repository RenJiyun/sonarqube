package com.wlzq.service.base.sys.utils;

import com.wlzq.common.RequestId;
import com.wlzq.common.model.account.AccTokenUser;
import com.wlzq.common.model.sys.LoginTerminalInfo;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.global.ThreadGlobal;
import com.wlzq.service.base.redis.UserRedis;

public class TerminalUtils {
	/**
	 * 获取终端信息
	 * @return
	 */
	public static String getOpStation() {
		RequestId request = ThreadGlobal.reqestId.get();
		if(request == null) {
			LoginTerminalInfo terminalInfo = new LoginTerminalInfo();
			terminalInfo.setType(LoginTerminalInfo.TYPE_OTHER);
			return terminalInfo.toOpstation();
		}
		//usertoken获取终端信息
		String userToken = request.getToken();
		LoginTerminalInfo terminalInfo = getTerminalByUserToken(userToken);
		if(ObjectUtils.isNotEmptyOrNull(terminalInfo)) {
			AccTokenUser user = (AccTokenUser) UserRedis.TOKEN_INFO.get(userToken);
			if(user != null) {
				terminalInfo.setMobile(user.getMobile());
			}
			terminalInfo.setClientIp(request.getClientIp());
			terminalInfo.setClientPort(request.getClientPort());
			return terminalInfo.toOpstation(); 
		}
		
		//custToken获取终端信息
		String custToken = request.getCustToken();
		if(ObjectUtils.isEmptyOrNull(custToken)) {
			terminalInfo = new LoginTerminalInfo();
			terminalInfo.setType(LoginTerminalInfo.TYPE_OTHER);
			terminalInfo.setClientIp(request.getClientIp());
			terminalInfo.setClientPort(request.getClientPort());
			return terminalInfo.toOpstation();
		}
		terminalInfo = (LoginTerminalInfo) UserRedis.CUSTOMER_TERMINAL_INFO.get(custToken);
		if(terminalInfo == null) {
			terminalInfo = new LoginTerminalInfo();
			terminalInfo.setType(LoginTerminalInfo.TYPE_OTHER);
			terminalInfo.setClientIp(request.getClientIp());
			terminalInfo.setClientPort(request.getClientPort());
			String token = request.getToken();
			if(ObjectUtils.isNotEmptyOrNull(token)) {
				AccTokenUser user = (AccTokenUser) UserRedis.TOKEN_INFO.get(token);
				if(user != null) {
					terminalInfo.setMobile(user.getMobile());
				}
			}
		}
		return terminalInfo.toOpstation();
	}
	
	/**
	 * 获取终端信息
	 * @return
	 */
	public static LoginTerminalInfo getTerminalByUserToken(String userToken) {
		if(ObjectUtils.isEmptyOrNull(userToken)) return null;
		LoginTerminalInfo terminalInfo = (LoginTerminalInfo) UserRedis.CUSTOMER_TERMINAL_INFO.get(userToken);
		return terminalInfo;
	}

	/**
	 * 获取终端信息
	 * @return
	 */
	public static LoginTerminalInfo getTerminalByCustToken(String custToken) {
		if(ObjectUtils.isEmptyOrNull(custToken)) return null;
		LoginTerminalInfo terminalInfo = (LoginTerminalInfo) UserRedis.CUSTOMER_TERMINAL_INFO.get(custToken);
		return terminalInfo;
	}
}
