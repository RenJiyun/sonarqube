package com.wlzq.service.base.mq.consumer;

/**
 * mq消息消费处理
 * @author Administrator
 * @param <T>
 *
 */
public interface MessageConsumerHandler<T> {
	/**
	 * 消息处理
	 * @param object 消息转为对象
	 * @return
	 */
	boolean handle(T entity);
}
