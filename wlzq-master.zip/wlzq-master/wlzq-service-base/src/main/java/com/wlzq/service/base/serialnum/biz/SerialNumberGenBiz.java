package com.wlzq.service.base.serialnum.biz;

import java.util.List;

public interface SerialNumberGenBiz {
	/**
	 * 生成一个流水号
	 * 
	 * @param serialNumberKey
	 *            单据号产生标识号.每个流水号类型的key不能和其他的流水号的可以相同。<br>
	 *            建议命名规则：{模块}_{系统}_{单据类型}
	 * @param serialNumberTmpl
	 *            序列号生成模板.格式如下：<br>
	 *            {string:原样字符串} 说明：原样输出字符串 <br>
	 *            {date:日期格式} 说明：格式化日期输出 <br>
	 *            {sequence:宽度|流水号重置周期} 说明：输出流水号.宽度：流水号宽度。 流水号重置周期包括：day - 按日重置,
	 *            month - 按月重置, year - 按年重置, no - 不重置 <br>
	 *            {rnd:宽度} 说明： 产生随机数字，位数等于宽度<br>
	 *            例如：{string:201}{date:yyyyMMdd}{sequence:6|no}{rnd:4}
	 *            生成的流水号可能是：2012015101200000012563
	 * @param comment
	 *            序列号说明
	 * @return
	 */
	public String generator(String serialNumberKey, String serialNumberTmpl, String comment);

	/**
	 * 批量生成流水号
	 * 
	 * @param serialNumberKey
	 *            单据号产生标识号.每个流水号类型的key不能和其他的流水号的可以相同。<br>
	 *            建议命名规则：{模块}_{系统}_{单据类型}
	 * @param serialNumberTmpl
	 *            序列号生成模板.格式如下：<br>
	 *            {string:原样字符串} 说明：原样输出字符串 <br>
	 *            {date:日期格式} 说明：格式化日期输出 <br>
	 *            {sequence:宽度|流水号重置周期} 说明：输出流水号.宽度：流水号宽度。 流水号重置周期包括：day - 按日重置,
	 *            month - 按月重置, year - 按年重置, no - 不重置 <br>
	 *            {rnd:宽度} 说明： 产生随机数字，位数等于宽度<br>
	 *            例如：{string:201}{date:yyyyMMdd}{sequence:6|no}{rnd:4}
	 *            生成的流水号可能是：2012015101200000012563
	 * @param comment
	 *            序列号说明
	 * @return
	 */
	public List<String> generatorBatch(String serialNumberKey, String serialNumberTmpl, String comment, int count);
}
