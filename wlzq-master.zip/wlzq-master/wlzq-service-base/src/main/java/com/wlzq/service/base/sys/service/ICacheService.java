package com.wlzq.service.base.sys.service;

import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.service.base.sys.RedisFacadeAbstract;

import java.util.List;

/**
 * redis缓存相关操作 service类
 */
public interface ICacheService {

    /**
     * 删除缓存
     *
     * @param basePackage 要扫描的RedisFacadeAbstract子类的包路径，例：com.wlzq.activity.*.redis
     * @param prefix      缓存的前缀
     * @param key         缓存的key
     * @return StatusDto
     */
    StatusDto deleteCache(String basePackage, String prefix, String key);

    /**
     * 取出支持删除key的对象
     *
     * @param basePackage 要扫描的RedisFacadeAbstract子类的包路径，例：com.wlzq.activity.*.redis
     * @param prefix      缓存的前缀
     * @return StatusDto
     */
    StatusObjDto<RedisFacadeAbstract> getRedisFacadeAbstract(String basePackage, String prefix);

    /**
     * 查找basePackage下的全部缓存前缀
     *
     * @param basePackage 要扫描的RedisFacadeAbstract子类的包路径，例：com.wlzq.base.*
     */
    StatusObjDto<List<String>> prefixList(String basePackage);
}
