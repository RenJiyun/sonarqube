package com.wlzq.service.base.sys.basesensitiveword.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import com.wlzq.core.SpringApplicationContext;
import com.wlzq.service.base.redis.SensitiveWordsRedis;
import com.wlzq.service.base.sys.basesensitiveword.dao.BaseSensitivewordDao;
import com.wlzq.service.base.sys.basesensitiveword.model.BaseSensitiveword;
import com.wlzq.service.base.sys.basesensitiveword.utils.ufa.BCConvert;
import com.wlzq.service.base.sys.basesensitiveword.utils.ufa.FilterSet;
import com.wlzq.service.base.sys.basesensitiveword.utils.ufa.WordNode;

/**
 * 敏感词过滤器
 * @author cjz
 *
 */
public class SensitiveWordFilterUtil {

	/** 存储首字 */
	private static final FilterSet set = new FilterSet();
	/** 存储节点 */
	private static final Map<Integer, WordNode> nodes = new HashMap<Integer, WordNode>(1024, 1);
	/** 停顿词 */
	private static final Set<Integer> stopwdSet = new HashSet<>();
	/** 敏感词过滤替换 */
	private static final char SIGN = '*';

	/** 停顿词   "<",">"这两个符号不放进停顿词中，可用于监测xss*/
	private static final String[] stopw = {"!", ".",",","#","$","%","&","*","(",")","|","?","/","@","\"","'",";","[","]","{","}","+","~","-","_","=","^"," ","！","。","，","￥","（","）","？","、","“ ","‘ ","；","【","】","——","……","《","》"};
	
	private static BaseSensitivewordDao baseSensitivewordDao;
	
	static {
		try {
			init();
		} catch (Exception e) {
			throw new RuntimeException("初始化过滤器失败");
		}
	}

	/**
	 * 初始化停顿词
	 */
	private static void init() {
		List<String> stopwds = new ArrayList<String>();
		for (String string : stopw) {
			stopwds.add(string);
		}
		addStopWord(stopwds);
	}
	
	/**
	 * 初始化敏感词，可以外部给出
	 * @param list
	 */
	public static void initSensitiveWords(List<String> list) {
		addSensitiveWord(list);
	}
	
	/**
	 *  获取敏感词
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private static List<String> getSensitiveWords() {
		baseSensitivewordDao = SpringApplicationContext.getBean(BaseSensitivewordDao.class);
		List<String> list = new ArrayList<String>();
		List<BaseSensitiveword> l = null;
		list = (List<String>) SensitiveWordsRedis.SENSITIVEWORDSREDIS.get(SensitiveWordsRedis.SENSITIVEWDS);
		if (list != null) {
			return list;
		}
		l = baseSensitivewordDao.findAllList(null);
		
		list = new ArrayList<String>();
		if (l != null && l.size() > 0) {
			for (BaseSensitiveword baseSensitiveword : l) {
				list.add(baseSensitiveword.getContent());
			}
		}
		SensitiveWordsRedis.SENSITIVEWORDSREDIS.set(SensitiveWordsRedis.SENSITIVEWDS, list, 24 * 3600);
		return list;
	}

//	/**
//	 * 增加敏感词
//	 * 
//	 * @param path
//	 * @return
//	 */
//	private static List<String> readWordFromFile(String path) {
//		List<String> words;
//		BufferedReader br = null;
//		try {
//			br = new BufferedReader(new InputStreamReader(WordFilter.class
//					.getClassLoader().getResourceAsStream(path)));
//			words = new ArrayList<String>(1200);
//			for (String buf = ""; (buf = br.readLine()) != null;) {
//				if (buf == null || buf.trim().equals(""))
//					continue;
//				words.add(buf);
//			}
//		} catch (Exception e) {
//			throw new RuntimeException(e);
//		} finally {
//			try {
//				if (br != null)
//					br.close();
//			} catch (IOException e) {
//			}
//		}
//		return words;
//	}

	/**
	 * 增加停顿词
	 * 
	 * @param words
	 */
	private static void addStopWord(final List<String> words) {
		if (words != null && words.size() > 0) {
			char[] chs;
			for (String curr : words) {
				chs = curr.toCharArray();
				for (char c : chs) {
					stopwdSet.add(charConvert(c));
				}
			}
		}
	}

	/**
	 * 添加DFA节点
	 * 
	 * @param words
	 */
	private static void addSensitiveWord(final List<String> words) {
		if (words != null && words.size() > 0) {
			char[] chs;
			int fchar;
			int lastIndex;
			WordNode fnode; // 首字母节点
			for (String curr : words) {
				chs = curr.toCharArray();
				fchar = charConvert(chs[0]);
				if (!set.contains(fchar)) {// 没有首字定义
					set.add(fchar);// 首字标志位 可重复add,反正判断了，不重复了
					fnode = new WordNode(fchar, chs.length == 1);
					nodes.put(fchar, fnode);
				} else {
					fnode = nodes.get(fchar);
					if (!fnode.isLast() && chs.length == 1)
						fnode.setLast(true);
				}
				lastIndex = chs.length - 1;
				for (int i = 1; i < chs.length; i++) {
					fnode = fnode.addIfNoExist(charConvert(chs[i]), i == lastIndex);
				}
			}
		}
	}

	/**
	 * 过滤判断 将敏感词转化为成屏蔽词
	 * 
	 * @param src
	 * @return
	 */
	public static final String doFilter(final String src) {
		initSensitiveWords(getSensitiveWords());
		char[] chs = src.toCharArray();
		int length = chs.length;
		int currc;
		int k;
		WordNode node;
		for (int i = 0; i < length; i++) {
			currc = charConvert(chs[i]);
			if (!set.contains(currc)) {
				continue;
			}
			node = nodes.get(currc);// 日 2
			if (node == null)// 其实不会发生，习惯性写上了
				continue;
			boolean couldMark = false;
			int markNum = -1;
			if (node.isLast()) {// 单字匹配（日）
				couldMark = true;
				markNum = 0;
			}
			// 继续匹配（日你/日你妹），以长的优先
			// 你-3 妹-4 夫-5
			k = i;
			for (; ++k < length;) {
				int temp = charConvert(chs[k]);
				if (stopwdSet.contains(temp))
					continue;
				node = node.querySub(temp);
				if (node == null)// 没有了
					break;
				if (node.isLast()) {
					couldMark = true;
					markNum = k - i;// 3-2
				}
			}
			if (couldMark) {
				for (k = 0; k <= markNum; k++) {
					chs[k + i] = SIGN;
				}
				i = i + markNum;
			}
		}

		return new String(chs);
	}

	/**
	 * 是否包含敏感词
	 * 
	 * @param src
	 * @return
	 */
	public static final boolean isContainSensitiveWords(final String src) {
		initSensitiveWords(getSensitiveWords());
		char[] chs = src.toCharArray();
		int length = chs.length;
		int currc;
		int k;
		WordNode node;
		for (int i = 0; i < length; i++) {
			currc = charConvert(chs[i]);
			if (!set.contains(currc)) {
				continue;
			}
			node = nodes.get(currc);// 日 2
			if (node == null)// 其实不会发生，习惯性写上了
				continue;
			boolean couldMark = false;
			if (node.isLast()) {// 单字匹配（日）
				couldMark = true;
			}
			// 继续匹配（日你/日你妹），以长的优先
			// 你-3 妹-4 夫-5
			k = i;
			for (; ++k < length;) {
				int temp = charConvert(chs[k]);
				if (stopwdSet.contains(temp))
					continue;
				node = node.querySub(temp);
				if (node == null)// 没有了
					break;
				if (node.isLast()) {
					couldMark = true;
				}
			}
			if (couldMark) {
				return true;
			}
		}

		return false;
	}

	/**
	 * 判断是否有xss注入
	 * @param src
	 * @return
	 */
	public static boolean isContainXssWords(String src) {
		String value = src.replaceAll(" ", "");
		// 避免script 标签
		Pattern scriptPattern = Pattern.compile("(.*?)<script>(.*?)</script>(.*?)", Pattern.CASE_INSENSITIVE);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 避免src形式的表达式\
		scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 删除单个的 </script> 标签
		scriptPattern = Pattern.compile("(.*?)</script>", Pattern.CASE_INSENSITIVE);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		scriptPattern = Pattern.compile("<script>(.*?)", Pattern.CASE_INSENSITIVE);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 删除单个的<script ...> 标签
		scriptPattern = Pattern.compile("<script(.*?)>(.*?)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 避免 eval(...) 形式表达式
		scriptPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 避免 e­xpression(...) 表达式
		scriptPattern = Pattern.compile("(.*?)e­xpression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 避免 javascript: 表达式
		scriptPattern = Pattern.compile("(.*?)javascript:(.*?)", Pattern.CASE_INSENSITIVE);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 避免 vbscript:表达式
		scriptPattern = Pattern.compile("(.*?)vbscript:(.*?)", Pattern.CASE_INSENSITIVE);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		// 避免 onload= 表达式
		scriptPattern = Pattern.compile("(.*?)onload(.*?)=(.*?)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		if (scriptPattern.matcher(value).matches()) {
			return true;
		}
		
//		if (src.contains("<script")) {
//			return true;
//		} else if (src.contains("</script")) {
//			return true;
//		} else if (src.contains("eval(")) {
//			return true;
//		} else if (src.contains("e­xpression")) {
//			return true;
//		} else if (src.contains("javascript:")) {
//			return true;
//		} else if (src.contains("vbscript:")) {
//			return true;
//		} else if (src.contains("onload(")) {
//			return true;
//		}
		return false;
	}
	
	/**
	 * 大写转化为小写 全角转化为半角
	 * 
	 * @param src
	 * @return
	 */
	private static int charConvert(char src) {
		int r = BCConvert.qj2bj(src);
		return (r >= 'A' && r <= 'Z') ? r + 32 : r;
	}

}
