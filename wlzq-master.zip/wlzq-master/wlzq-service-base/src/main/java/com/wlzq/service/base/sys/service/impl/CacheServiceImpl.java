package com.wlzq.service.base.sys.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wlzq.core.dto.StatusDto;
import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.service.base.sys.RedisFacadeAbstract;
import com.wlzq.service.base.sys.service.ICacheService;
import com.wlzq.service.base.sys.utils.ScanUtils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * redis缓存相关操作 service实现类
 */
public class CacheServiceImpl implements ICacheService {
    /**
     * key: prefix, value: RedisFacadeAbstract子类的实例对象
     */
    private final Map<String, RedisFacadeAbstract> subRedisFacadeAbstractCache = Maps.newConcurrentMap();

    @Override
    public StatusDto deleteCache(String basePackage, String prefix, String key) {

        StatusObjDto<RedisFacadeAbstract> redisFacadeAbstract = getRedisFacadeAbstract(basePackage, prefix);

        // 删除缓存
        redisFacadeAbstract.getObj().del(key);

        return new StatusDto(true);
    }

    @Override
    public StatusObjDto<RedisFacadeAbstract> getRedisFacadeAbstract(String basePackage, String prefix) {
        if (subRedisFacadeAbstractCache.isEmpty()) {
            // 如果subRedisFacadeAbstractCache中没有能处理key的对象，就扫描basePackage开始查找
            cacheSubRedisFacadeAbstractByScan(basePackage);
        }

        // 取出支持删除key的对象
        RedisFacadeAbstract subRedisFacadeAbstract = subRedisFacadeAbstractCache.get(prefix);

        return new StatusObjDto<>(true, subRedisFacadeAbstract);
    }

    @Override
    public StatusObjDto<List<String>> prefixList(String basePackage) {
        if (subRedisFacadeAbstractCache.isEmpty()) {
            cacheSubRedisFacadeAbstractByScan(basePackage);
        }

        Set<String> prefixList = subRedisFacadeAbstractCache.keySet();

        return new StatusObjDto<>(true, Lists.newArrayList(prefixList));
    }

    /**
     * 扫描指定包路径，缓存RedisFacadeAbstract对象
     *
     * @param basePackage 要扫描的RedisFacadeAbstract子类的包路径，例：com.wlzq.activity.*.redis
     */
    private void cacheSubRedisFacadeAbstractByScan(String basePackage) {
        // 获取所有子类
        Set<Class<?>> subClasses = ScanUtils.scanSubClass(basePackage, RedisFacadeAbstract.class, true);

        for (Class<?> subClass : subClasses) {
            Field[] fields = subClass.getFields();

            for (Field field : fields) {
                if (field.getType().equals(subClass)) {

                    try {
                        // 得到subClass的实例对象
                        RedisFacadeAbstract subRedisFacadeAbstract = (RedisFacadeAbstract) field.get(subClass);
                        Method getRedisPrefix = subClass.getDeclaredMethod("getRedisPrefix");
                        getRedisPrefix.setAccessible(true);
                        Object prefix = getRedisPrefix.invoke(subRedisFacadeAbstract);

                        // 把prefix与subRedisFacadeAbstract的对应关系缓存起来
                        subRedisFacadeAbstractCache.put((String) prefix, subRedisFacadeAbstract);

                    } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
