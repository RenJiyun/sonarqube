package com.wlzq.service.base.sys.basesensitiveword.model;

/**
 * 敏感词Entity
 * @author cjz
 * @version 2018-05-18
 */
public class BaseSensitiveword {
	
	private Integer id;
	private String content;		// 敏感词内容
	private Integer status;		// 是否有效,1:有效,0:无效
	
	public BaseSensitiveword() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
}