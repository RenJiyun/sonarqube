package com.wlzq.service.base.sys.holiday.biz.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wlzq.common.utils.DateUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.service.base.sys.holiday.biz.HolidayBiz;
import com.wlzq.service.base.sys.holiday.dao.HolidayDao;
import com.wlzq.service.base.sys.holiday.model.Holiday;

/**
 * HolidayBiz接口实现
 * @author louie
 *
 */
@Service
public class HolidayBizImpl implements HolidayBiz {
	
	@Autowired
	private HolidayDao holidayDao;

	@Override
	public Holiday getHolidayFromDate(Date date) {
		if(ObjectUtils.isEmptyOrNull(date)) {
			return null;
		}
		Holiday param = new Holiday();
		param.setDate(date);
		Holiday holiday = holidayDao.findByDate(param);
		
		return holiday;
	}
	
	/**
	 * 是否为交易日
	 * @param date
	 * @return
	 */
	public boolean isTradeDate(Date date) {
		if(ObjectUtils.isEmptyOrNull(date)) {
			return false;
		}
		if(DateUtils.isWeekend(date)) return false;
		//查询是否在假期
		date = DateUtils.getDayStart(date);
		Holiday holiday = this.getHolidayFromDate(date);
		if(holiday != null) return false;
		return true;
	}
	
	/**
	 * 获取指定日期过后指定交易天数后的交易日
	 * @param date
	 * @param afterTradeDays
	 * @return
	 */
	public Date getTradeDateAfterDays(Date date,int afterTradeDays) {
		if(date == null || afterTradeDays < 1) return null;
		int count = 0;
		while(true) {
			date = DateUtils.addDay(date, 1);
			if(this.isTradeDate(date)){
				count++;
				if(count == afterTradeDays) {
					return date;
				}
			}
		}
	}
	
}
