package com.wlzq.service.base.config;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;

import com.wlzq.common.utils.ObjectUtils;
import org.springframework.data.redis.core.StringRedisTemplate;

@Configuration

@EnableCaching //启用缓存，这个注解很重要；

public class RedisCacheConfig<K, V> extends CachingConfigurerSupport {
       /**

        * 缓存管理器.

        * @param redisTemplate

        * @return

        */

       @Bean
       public CacheManager cacheManager(RedisConnectionFactory factory) {

              CacheManager cacheManager = RedisCacheManager.create(factory);

              return cacheManager;

       }

 

      

       /**

        * redis模板操作类,类似于jdbcTemplate的一个类;

        *

        * 虽然CacheManager也能获取到Cache对象，但是操作起来没有那么灵活；

        *

        * 这里在扩展下：RedisTemplate这个类不见得很好操作，我们可以在进行扩展一个我们

        *

        * 自己的缓存类，比如：RedisStorage类;

        *

        * @param factory : 通过Spring进行注入，参数在application.properties进行配置；

        * @return

        */

       @Bean(name = "redisDatabase1")
       public RedisTemplate<K, V> redisTemplate(LettuceConnectionFactory factory) {
              RedisTemplate<K,V> redisTemplate = new RedisTemplate<K, V>();

              redisTemplate.setConnectionFactory(factory);

             

              //key序列化方式;（不然会出现乱码;）,但是如果方法上有Long等非String类型的话，会报类型转换错误；

              //所以在没有自己定义key生成策略的时候，以下这个代码建议不要这么写，可以不配置或者自己实现ObjectRedisSerializer

              //或者JdkSerializationRedisSerializer序列化方式;

//           RedisSerializer<String>redisSerializer = new StringRedisSerializer();//Long类型不可以会出现异常信息;

//           redisTemplate.setKeySerializer(redisSerializer);

//           redisTemplate.setHashKeySerializer(redisSerializer);

             

              return redisTemplate;

       }

       /**
        * 用于支持stringRedisTemplate.keys(pattern)方法
        */
       @Bean(name = "redisDatabase2")
       public RedisTemplate<String, String> stringRedisTemplate(LettuceConnectionFactory factory) {
              RedisTemplate<String, String> redisTemplate = new StringRedisTemplate();
              redisTemplate.setConnectionFactory(factory);

              return redisTemplate;
       }

       //       @Bean(name = "redisDatabase0")
//       public RedisTemplate<K, V> redisTemplate0(
//               @Value("${spring.redis.pool.max-active}") int maxActive,
//               @Value("${spring.redis.pool.max-wait}") int maxWait,
//               @Value("${spring.redis.pool.max-idle}") int maxIdle,
//               @Value("${spring.redis.pool.min-idle}") int minIdle,
//               @Value("${spring.redis.host}") String hostName,
//               @Value("${spring.redis.port}") int port,
//               @Value("${spring.redis.password:}") String password) {
//
//           /* ========= 基本配置 ========= */
//           RedisStandaloneConfiguration configuration = new RedisStandaloneConfiguration();
//           configuration.setHostName(hostName);
//           configuration.setPort(port);
//           configuration.setDatabase(0);
//           if (!ObjectUtils.isEmptyOrNull(password)) {
//               RedisPassword redisPassword = RedisPassword.of(password);
//               configuration.setPassword(redisPassword);
//           }
//
//           /* ========= 连接池通用配置 ========= */
//           GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
//           genericObjectPoolConfig.setMaxTotal(maxActive);
//           genericObjectPoolConfig.setMinIdle(minIdle);
//           genericObjectPoolConfig.setMaxIdle(maxIdle);
//           genericObjectPoolConfig.setMaxWaitMillis(maxWait);
//
//           /* ========= jedis pool ========= */
//           /*
//           JedisClientConfiguration.DefaultJedisClientConfigurationBuilder builder = (JedisClientConfiguration.DefaultJedisClientConfigurationBuilder) JedisClientConfiguration
//                   .builder();
//           builder.connectTimeout(Duration.ofSeconds(timeout));
//           builder.usePooling();
//           builder.poolConfig(genericObjectPoolConfig);
//           JedisConnectionFactory connectionFactory = new JedisConnectionFactory(configuration, builder.build());
//           // 连接池初始化
//           connectionFactory.afterPropertiesSet();
//           */
//
//           /* ========= lettuce pool ========= */
//           LettucePoolingClientConfiguration.LettucePoolingClientConfigurationBuilder builder = LettucePoolingClientConfiguration.builder();
//           builder.poolConfig(genericObjectPoolConfig);
//          // builder.commandTimeout(Duration.ofSeconds(timeout));
//           LettuceConnectionFactory connectionFactory = new LettuceConnectionFactory(configuration, builder.build());
//           connectionFactory.afterPropertiesSet();
//
//           /* ========= 创建 template ========= */
//           RedisTemplate<K,V> redisTemplate = new RedisTemplate<K, V>();
//           redisTemplate.setConnectionFactory(connectionFactory);
//           
//           return redisTemplate;
//       }
//
// 
 

}