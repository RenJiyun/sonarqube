package com.wlzq.service.base.redis;

import com.wlzq.service.base.sys.RedisFacadeAbstract;

public class DictRedis  extends RedisFacadeAbstract {

	/**字典缓存：sys:dict:type:key */
	public static final DictRedis SYS_DICT = new DictRedis("sys:dict:",30*24*3600);

	/**字典缓存：sys:dict:type:key */
	public static final DictRedis SYS_DICT_INFO = new DictRedis("sys:dictinfo:",30*24*3600);

	/**字典缓存：sys:dict:type */
	public static final DictRedis SYS_DICT_LIST = new DictRedis("sys:dictlist:",30*24*3600);
	
	private String redisPrefix;
	private int timeoutSeconds;

	private DictRedis(String redisPrefix) {
		this.redisPrefix = redisPrefix;
	}

	private DictRedis(String redisPrefix,int timeoutSeconds) {
		this.redisPrefix = redisPrefix;
		this.timeoutSeconds = timeoutSeconds;
	}

	@Override
	protected String getRedisPrefix() {
		return redisPrefix;
	}

	@Override
	protected int getTimeoutSeconds() {
		return timeoutSeconds;
	}
}