package com.wlzq.service.base.sys.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * 验证码 实体类
 * @author  2017-8-16 16:08:08
 * @version 1.0
 */
public class VerifyCode{
	/**验证码ID*/
	private java.lang.String id;
	/**验证码*/
	@JsonIgnore
	private java.lang.String code;
	/**验证码图片base64字符串*/
	private java.lang.String image;
	public java.lang.String getId() {
		return id;
	}
	public void setId(java.lang.String id) {
		this.id = id;
	}
	
	public java.lang.String getCode() {
		return code;
	}
	public void setCode(java.lang.String code) {
		this.code = code;
	}
	public java.lang.String getImage() {
		return image;
	}
	public void setImage(java.lang.String image) {
		this.image = image;
	}	
	
}

