package com.wlzq.service.base.sys.biz;

import com.wlzq.service.base.sys.model.VerifyCode;

/**
 * VerifyCodeBiz类
 * @author 
 * @version 1.0
 */
public interface VerifyCodeBiz {	

	/**
	 * 生成验证码
	 * @param id 验证码id
	 * @return
	 */
	VerifyCode createVerifyCode(String id);
	
	/**
	 * 检查验证码
	 * @param id 验证码id
	 * @param code 输入验证码
	 * @return
	 */
	boolean checkVerifyCode(String id,String code);
}
