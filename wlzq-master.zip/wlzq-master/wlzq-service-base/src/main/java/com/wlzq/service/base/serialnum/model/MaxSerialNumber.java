package com.wlzq.service.base.serialnum.model;

/**
 * 流水号扩展对象。记录可以使用的最大流水号。
 * 
 * @author louie
 */
public class MaxSerialNumber extends SerialNumber {
	private static final long serialVersionUID = 645423564642695L;

	/** 可以使用的最大流水号 */
	private int maxSerialNumber;

	/** 可以使用的最大流水号 */
	public int getMaxSerialNumber() {
		return maxSerialNumber;
	}

	/** 可以使用的最大流水号 */
	public void setMaxSerialNumber(int maxSerialNumber) {
		this.maxSerialNumber = maxSerialNumber;
	}

}
