package com.wlzq.service.base.sys;

import java.net.InetAddress;
import java.util.Date;

import com.wlzq.common.constant.CodeConstant;
import com.wlzq.common.model.behavior.ApiRequest;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.core.RequestParams;
import com.wlzq.core.annotation.ApiServiceTypeEnum;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.service.base.mq.MessageUtils;
import com.wlzq.service.base.sys.utils.AppConfigUtils;

public class RequestSendHandler implements Runnable {     //内部类
	private RequestParams params;
	private Long spend;
	private ResultDto result;
	private String topic;
	private String topicTags;
	private Date startTime;
	
    public  RequestSendHandler(RequestParams params,Long spend,ResultDto result,String topic,String topicTags,Date startTime) {
        this.params = params;
        this.spend = spend;
        this.result = result;
        this.topic = topic;
        this.topicTags = topicTags;
        this.startTime = startTime;
    }

	@Override
	public void run() {
		try {
		    Integer saveFlag = AppConfigUtils.getInt("sys.request.save",0);
		    if(saveFlag.equals(CodeConstant.CODE_NO)) return ;
		    
			ApiRequest record = new ApiRequest();
			record.setRequestId(params.getRequestId());
			record.setRequestOrder(params.getRequestOrder());
	    	record.setKey(params.getKey());
	    	record.setCreateTime(new Date());
	    	record.setIp(params.getClientIp());
	    	record.setMethod(params.getService()+"."+params.getMethod());
	    	record.setSearchParam("");
	    	record.setSpend(spend.intValue());
	    	record.setStatus(result.getCode());
	    	record.setUrl("");
	    	InetAddress address = InetAddress.getLocalHost();
	    	record.setServer(address.getHostAddress());
	    	String resultStr = JsonUtils.object2JSON(result);
	    	resultStr = resultStr.length() > 1000?resultStr.substring(0, 1000):resultStr;
	    	record.setStatusMessage(resultStr);
	    	Integer type = params.getServiceType().equals(ApiServiceTypeEnum.APP)?1: 
	    		params.getServiceType().equals(ApiServiceTypeEnum.COOPERATION)?2: 
	    			params.getServiceType().equals(ApiServiceTypeEnum.CALLBACK)?3:4;
	    	record.setType(type);
	    	record.setUserId(result.getUserId());
	    	record.setMobile(result.getMobile());
	    	record.setCustomerId(result.getCustomerId());
	    	String method = params.getService()+"."+params.getMethod();
	    	if(method.equals("base.image.upload")) { //若为上传图片，不记录参数信息
	    		record.setParams("");
	    	}else {
	    		String callbackParam = params.getInputBytes() != null?new String(params.getInputBytes(),"UTF-8"):"";
	    		record.setParams("sys:"+JsonUtils.map2Json(params.getSysParams())+";callback:"+callbackParam);
	    	}
	    	record.setCreateTime(startTime);
	    	//送入消息队列
   		    MessageUtils.send(topic, topicTags, record);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
	}
}