/**
 * Copyright &copy; 2001-2018 <a href="http://www.wlzq.cn">wlzq</a> All rights reserved.
 */
package com.wlzq.service.base.sys.holiday.dao;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.holiday.model.Holiday;

/**
 * 假期信息DAO接口
 * @author louie
 * @version 2018-05-24
 */
@MybatisScan
public interface HolidayDao extends CrudDao<Holiday> {
	/**
	 * 查询日期所属假期
	 * @param holiday
	 * @return
	 */
	Holiday findByDate(Holiday holiday);
}