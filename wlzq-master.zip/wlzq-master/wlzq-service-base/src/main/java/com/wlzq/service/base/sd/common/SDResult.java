package com.wlzq.service.base.sd.common;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SDResult {
	private String errorNo;
	private String errorInfo;
	private Map<String,String> cookies;
	private byte[] image;
	private List<String> dsName;
	private List<Map<String,Object>> results;
	private Map<String,Object> data;
	
	public boolean isOk() {
		return this.errorNo.equals("0");
	}
	public String getErrorNo() {
		return errorNo;
	}
	@JsonProperty(value="error_no")
	public void setErrorNo(String errorNo) {
		this.errorNo = errorNo;
	}
	
	public String getErrorInfo() {
		return errorInfo;
	}
	@JsonProperty(value="error_info")
	public void setErrorInfo(String errorInfo) {
		this.errorInfo = errorInfo;
	}
	
	public List<Map<String, Object>> getResults() {
		return results;
	}
	public void setResults(List<Map<String, Object>> results) {
		this.results = results;
	}
	
	public Map<String, String> getCookies() {
		return cookies;
	}
	public void setCookies(Map<String, String> cookies) {
		this.cookies = cookies;
	}
	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	public Map<String, Object> getData() {
		return data;
	}
	public void setData(Map<String, Object> data) {
		this.data = data;
	}
	public List<String> getDsName() {
		return dsName;
	}
	public void setDsName(List<String> dsName) {
		this.dsName = dsName;
	}
	
}
