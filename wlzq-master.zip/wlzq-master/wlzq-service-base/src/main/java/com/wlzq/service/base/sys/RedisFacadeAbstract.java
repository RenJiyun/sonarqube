package com.wlzq.service.base.sys;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.wlzq.core.SpringApplicationContext;
import com.wlzq.service.base.sys.dao.BaseRedisDao;

@SuppressWarnings({ "rawtypes", "unchecked" })
public abstract class RedisFacadeAbstract {
	private static final Logger log = LoggerFactory.getLogger(RedisFacadeAbstract.class);
	// 默认超时时间
	private static int DefaultTimeoutSenonds = 1 * 24 * 60 * 60; // 1 天

	/**
	 * redis key 前缀
	 * @return
	 */
	protected abstract String getRedisPrefix();
	
	/**
	 * 超时时间
	 * @return
	 */
	protected abstract int getTimeoutSeconds() ;

	public Object getField(String key, String field) {
		try {
			key = getRedisPrefix() + key;
			byte[] serialize = (byte[]) getRedis().opsForMapGet(key, field);
			return SerializeUtil.unserialize(serialize);
		} catch (Exception e) {
			log.error("cache error: ",e);
			return null;
		}
	}

	public boolean setField(String key, String field, Object value) {
		byte[] serialize = SerializeUtil.serialize(value);
		try {
			key = getRedisPrefix() + key;
			getRedis().opsForMapPut(key, field, serialize);
		} catch (Exception e) {
			log.error("cache error: ",e);
			return false;
		}
		return true;
	}

	public Object get(String key) {
		try {
			key = getRedisPrefix() + key;
			byte[] serialize = (byte[]) getRedis().get(key);
			if(serialize == null || serialize.length == 0) return null;
			return SerializeUtil.unserialize(serialize);
		} catch (Exception e) {
			log.error("cache error: ",e);
			return null;
		}
	}
	
	public boolean setNXEX(String key, Object value) {
		int timeout = this.getTimeoutSeconds();
		if(timeout == 0) {
			timeout = DefaultTimeoutSenonds;
		}
		return this.setNXEX(key, value, timeout);
	}
	
	/**
	 * 设置缓存。默认缓存时间1天
	 * 
	 * @param key
	 * @param value
	 * @return
	 */
	public boolean set(String key, Object value) {
		int timeout = this.getTimeoutSeconds();
		if(timeout == 0) {
			timeout = DefaultTimeoutSenonds;
		}
		return this.set(key, value, timeout);
	}

	/**
	 * 判断是否缓存了key.<br>
	 * 经过测试，这个判断并不准确。如果可以过期了，或者被其他地方删除了，依然返回true.
	 * 
	 * @param key
	 * @return
	 */
	public boolean exists(String key) {
		try {
			key = getRedisPrefix() + key;
			return getRedis().exists(key);
		} catch (Exception e) {
			log.error("cache error: ",e);
			return false;
		}
	}

	/**
	 * 设置key过期
	 * 
	 * @param key
	 * @param timeoutSeconds
	 */
	public void expire(String key, int timeoutSeconds) {
		getRedis().expire(key, timeoutSeconds, TimeUnit.SECONDS);
	}

	/**
	 * 获取过期时间（秒）
	 * @param key
	 * @return -1：此键值没有设置过期日期，-2：不存在此键
	 */
	public long getExpire(String key) {
		return getRedis().getExpire(key);
	}

	/**
	 * 设置缓存。并且指定超时时间。
	 * 
	 * @param key
	 * @param value
	 * @param timeoutSeconds
	 *            过期时间:秒; -1 表示永不过期
	 */
	public boolean set(String key, Object value, int timeoutSeconds) {

		byte[] serialize = SerializeUtil.serialize(value);
		try {
			key = getRedisPrefix() + key;
			if (timeoutSeconds <= -1) {
				getRedis().set(key, serialize);
			} else {
				getRedis().set(key, serialize, timeoutSeconds, TimeUnit.SECONDS);
			}
			return true;
		} catch (Exception e) {
			log.error("cache error: ",e);
			return false;
		}
	}
	
	public boolean setNXEX(String key, Object value, int timeoutSeconds) {
		byte[] serialize = SerializeUtil.serialize(value);
		try {
			key = getRedisPrefix() + key;
			boolean setNXEX = getRedis().setNXEX(key, serialize);
			if(setNXEX) {
				getRedis().expire(key, timeoutSeconds, TimeUnit.SECONDS);
			}
			return setNXEX;
		} catch (Exception e) {
			log.error("cache error: ",e);
			return false;
		}
	}

	/**
	 * 自增
	 * 
	 * @param key
	 * @return
	 */
	public long inc(String key) {
		key = getRedisPrefix() + key;
		return getRedis().inc(key);
	}

	public void del(String key) {
		try {
			key = getRedisPrefix() + key;
			getRedis().del(key);
		} catch (Exception e) {
		}

	}

	/**
	 * 按步长自增
	 * 
	 * @param key
	 * @param step
	 *            步长
	 * @return
	 */
	public long incBy(String key, long step) {
		key = getRedisPrefix() + key;
		return getRedis().incBy(key, step);
	}

	/** List 相关 API */

	public Object range(String key, Long start, Long end) {
		key = getRedisPrefix() + key;
		return getRedis().range(getKey(key), start, end);
	}

	public Object index(String key, Long index) {
		return getRedis().index(getKey(key), index);
	}

	public Long size(String key) {
		return getRedis().size(getKey(key));
	}

	public Long leftPush(String key, Object value) {
		return getRedis().leftPush(getKey(key), value);
	}

	public Long rightPush(String key, Object value) {
		return getRedis().rightPush(getKey(key), value);
	}

	public Object leftPop(String key) {
		return getRedis().leftPop(getKey(key));
	}

	public Object leftPop(String key, long timeout, TimeUnit unit) {
		return getRedis().leftPop(getKey(key), timeout, unit);
	}

	public Object rightPop(String key) {
		return getRedis().rightPop(getKey(key));
	}

	public Object rightPop(String key, long timeout, TimeUnit unit) {
		return getRedis().rightPop(getKey(key), timeout, unit);
	}

	public Object rightPopAndLeftPush(String sourceKey, String destinationKey) {
		return getRedis().rightPopAndLeftPush(getKey(sourceKey), getKey(destinationKey));
	}

	public Object rightPopAndLeftPush(String sourceKey, String destinationKey, long timeout, TimeUnit unit) {
		return getRedis().rightPopAndLeftPush(getKey(sourceKey), getKey(destinationKey), timeout, unit);
	}

	/** List 相关 API */

	/** hash map 操作 start */
	public boolean opsForMapHasKey(String key, String field) {
		return getRedis().opsForMapHasKey(getKey(key), field);
	}

	public void opsForMapPut(Object key, Object field, Object value) {
		getRedis().opsForMapPut(getKey((String) key), field, value);
	}

	public Object opsForMapGet(Object key, Object field) {
		return getRedis().opsForMapGet(getKey((String) key), field);
	}

	public void opsForMapDelete(Object key, Object... hashKeys) {
		getRedis().opsForMapDelete(getKey((String) key), hashKeys);
	}

	public Map opsForMapScan(Object key) {
		return getRedis().opsForMapScan(getKey((String) key));
	}

	/** set 相关 API */
	public Long sadd(Object key, Object... values) {
		key = getRedisPrefix() + key;
		return getRedis().sadd(key, values);
	}

	public Long scard(Object key) {
		key = getRedisPrefix() + key;
		return getRedis().scard(key);
	}
	
	public Object sRandomMember(Object key) {
		key = getRedisPrefix() + key;
		return getRedis().sRandomMember(key);
	}

	public Object sPop(Object key) {
		key = getRedisPrefix() + key;
		return getRedis().sPop(key);
	}

	public Long sremove(Object key, Object... values) {
		key = getRedisPrefix() + key;
		return getRedis().sremove(key, values);
	}
	/** set 相关 API */

	/** hash map 操作 end */

	private static BaseRedisDao redisClient;

	protected BaseRedisDao getRedis() {
		return redisClient != null ? redisClient
				: (redisClient = (BaseRedisDao) SpringApplicationContext.getBean("baseRedisDao"));
	}

	private String getKey(String key) {
		return getRedisPrefix() + key;
	}

	/*根据缓存前缀得到全部的key*/
	public Set<String> keys() {
		String patten = "*" + getRedisPrefix() + "*";
		return getRedis().keys(patten);
	}

	private static class SerializeUtil {
		public static byte[] serialize(Object object) {
			ObjectOutputStream oos = null;
			ByteArrayOutputStream baos = null;
			try {
				// 序列化
				baos = new ByteArrayOutputStream();
				oos = new ObjectOutputStream(baos);
				oos.writeObject(object);
				byte[] bytes = baos.toByteArray();
				return bytes;
			} catch (Exception e) {

			}
			return null;
		}

		public static Object unserialize(byte[] bytes) {
			ByteArrayInputStream bais = null;
			try {
				// 反序列化
				bais = new ByteArrayInputStream(bytes);
				ObjectInputStream ois = new ObjectInputStream(bais);
				return ois.readObject();
			} catch (Exception e) {
				log.error("cache error: ",e);
			}
			return null;
		}
	}
}