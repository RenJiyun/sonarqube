package com.wlzq.service.base.sys.model.application;

import java.io.Serializable;

/**
 * 方法权限管理Entity
 * @author louie
 * @version 2017-11-07
 */
public class ApplicationMethod  implements Serializable {
	
	private static final long serialVersionUID = 1489438473L;
	private String key;		// 秘钥
	private String method;		// 方法
	private String ip;		// 方法
	
	public ApplicationMethod() {
		super();
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	
}