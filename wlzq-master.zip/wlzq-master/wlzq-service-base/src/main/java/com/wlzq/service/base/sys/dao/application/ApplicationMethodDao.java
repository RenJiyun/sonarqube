package com.wlzq.service.base.sys.dao.application;

import java.util.List;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.model.application.ApplicationMethod;

/**
 * 方法权限管理DAO接口
 * @author louie
 * @version 2017-11-07
 */
@MybatisScan
public interface ApplicationMethodDao extends CrudDao<ApplicationMethod> {
	/**
	 * 查询方法
	 * @param key
	 * @return
	 */
	List<ApplicationMethod> findMethods(String key);
	/**
	 * 查询方法
	 * @param method
	 * @return
	 */
	List<ApplicationMethod> findMethod(ApplicationMethod method);
	/**
	 * 方法名查询方法
	 * @param method
	 * @return
	 */
	List<ApplicationMethod> findMethodByName(String method);
}