package com.wlzq.service.base.sys.model;

import java.io.Serializable;

public class SysNDict implements Serializable {

	private static final long serialVersionUID = 12342323L;
	private String id;		// id
	private String value;		// value
	private String label;		// label
	private String type;		// type
	private String description;		// description
	private SysNDict parent;		// parent_id
	private Integer sort;		// sort
	private Integer delFlag;
	
	public SysNDict() {
		super();
	}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public Integer getDelFlag() {
		return delFlag;
	}
	
	public void setDelFlag(Integer delFlag) {
		this.delFlag = delFlag;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}
	
	public SysNDict getParent() {
		return parent;
	}

	public void setParent(SysNDict parent) {
		this.parent = parent;
	}
}
