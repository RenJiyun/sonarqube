package com.wlzq.service.base.sys.model;

import java.util.Date;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 请求记录Entity
 * @author louie
 * @version 2017-10-18
 */
public class CoopRequestRecord {
	
	private Integer id;
	private String userId;		// 用户Id
	private String key;		// key
	private String method;		// 请求方法
	private String searchParam;		// 搜索参数
	private String url;		// 请求方法
	private String ip;		// 请求IP
	private Integer type;		// 类型
	private Integer spend;		// 消耗时间
	private String params;		// 链接
	private Integer status;		// 状态，1：成功，其它：失败
	private String statusMessage;		// 状态提示
	private Date createTime;		// 创建时间
	
	public CoopRequestRecord() {
		super();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Length(min=1, max=50, message="key长度必须介于 1 和 50 之间")
	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	@Length(min=1, max=100, message="请求方法长度必须介于 1 和 100 之间")
	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	
	@Length(min=0, max=1000, message="搜索参数长度必须介于 0 和 1000 之间")
	public String getSearchParam() {
		return searchParam;
	}

	public void setSearchParam(String searchParam) {
		this.searchParam = searchParam;
	}
	
	@Length(min=0, max=2000, message="请求方法长度必须介于 0 和 2000 之间")
	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	@Length(min=1, max=64, message="请求IP长度必须介于 1 和 64 之间")
	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	
	@NotNull(message="类型不能为空")
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}
	
	@Length(min=0, max=2000, message="链接长度必须介于 0 和 2000 之间")
	public String getParams() {
		return params;
	}

	public void setParams(String params) {
		this.params = params;
	}
	
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
	@Length(min=0, max=2000, message="状态提示长度必须介于 0 和 2000 之间")
	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	@NotNull(message="创建时间不能为空")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Integer getSpend() {
		return spend;
	}

	public void setSpend(Integer spend) {
		this.spend = spend;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}