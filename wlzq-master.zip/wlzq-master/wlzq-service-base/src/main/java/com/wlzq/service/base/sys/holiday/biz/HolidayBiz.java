package com.wlzq.service.base.sys.holiday.biz;

import java.util.Date;

import com.wlzq.service.base.sys.holiday.model.Holiday;

/**
 * HolidayBiz类
 * @author 
 * @version 1.0
 */
public interface HolidayBiz {	
	/**
	 * 日期查询假期
	 * @param date
	 * @return
	 */
	Holiday getHolidayFromDate(Date date);
	
	/**
	 * 是否为交易日
	 * @param date
	 * @return
	 */
	public boolean isTradeDate(Date date);
	
	/**
	 * 获取指定日期过后指定交易天数后的交易日
	 * @param date
	 * @param afterTradeDays
	 * @return
	 */
	public Date getTradeDateAfterDays(Date date,int afterTradeDays);
}
