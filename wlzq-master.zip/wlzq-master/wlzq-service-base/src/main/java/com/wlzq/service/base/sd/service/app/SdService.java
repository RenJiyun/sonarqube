package com.wlzq.service.base.sd.service.app;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.wlzq.common.utils.Base64;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.RequestParams;
import com.wlzq.core.annotation.Signature;
import com.wlzq.core.dto.ResultDto;
import com.wlzq.core.exception.BizException;
import com.wlzq.service.base.sd.common.SDResult;
import com.wlzq.service.base.sd.common.SDServiceType;
import com.wlzq.service.base.sd.utils.SDUtils;

/**
 * SdService 实现类
 * @author 
 * @version 1.0
 */
@Service("sidi.service")
public class SdService {
    
    @Signature(true)
	public ResultDto proxy(RequestParams params) {
    	Integer type = params.getInt("serviceType1");
    	if(ObjectUtils.isEmptyOrNull(type)) {
    		throw BizException.COMMON_PARAMS_NOT_NULL.format("serviceType1");
    	}
    	if(type < 1 || type > 4) {
    		throw BizException.COMMON_PARAMS_IS_ILLICIT.format("serviceType1");
    	}
    	SDServiceType serviceType = type.equals(1)?SDServiceType.STORE:type.equals(2)?SDServiceType.WECHAT:
    		type.equals(3)?SDServiceType.ONLINEHALL:type.equals(4)?SDServiceType.MARKET:null;
		String jsessionid = (String)params.getCookie("JSESSIONID");
		String funcNo =  params.get("funcNo") != null?(String)params.get("funcNo"):"";
		SDResult result = SDUtils.doPost(serviceType, funcNo, jsessionid, params.getParams());
		Map<String,Object> data = new HashMap<String,Object>();
		if(!ObjectUtils.isEmptyOrNull(result.getResults())) {
			data.put("info", result.getResults());
		}else {
			data.put("info", result.getData());
		}
		ResultDto backresult = new ResultDto(0,data,"");
		backresult.setCookies(result.getCookies());
		if(!result.isOk()) {
    		backresult.setCode(Integer.valueOf(result.getErrorNo()));
    		backresult.setMsg(result.getErrorInfo());
    	}else {
    		if(result.getImage() != null) {
    			//backresult.setOutPutType(ResultConstant.OUTPUT_TYPE_IMAGE);
    			//backresult.setImageBytes(result.getImage());
    			String imageStr = Base64.encode(result.getImage());// encoder.encodeBuffer(bytes).trim(); 
    	        imageStr = "data:image/jpg;base64,"+imageStr;
    	        data.put("image", imageStr);
    		}
    	}
    	return backresult;
	}
    
}
