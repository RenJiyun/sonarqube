package com.wlzq.service.base.sys.biz.impl;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.Random;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.springframework.stereotype.Service;

import com.wlzq.common.utils.Base64;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.core.exception.BizException;
import com.wlzq.service.base.redis.SysRedis;
import com.wlzq.service.base.sys.biz.VerifyCodeBiz;
import com.wlzq.service.base.sys.model.VerifyCode;

/**
 * VerifyCodeBiz接口实现
 * @author louie
 *
 */
@Service
public class VerifyCodeBizImpl implements VerifyCodeBiz {

	@Override
	public VerifyCode createVerifyCode(String id) {
		if(ObjectUtils.isNotEmptyOrNull(id)) {
			String exist = (String) SysRedis.SYS_VERIFY_CODE.get(id);
			id = ObjectUtils.isEmptyOrNull(exist)?UUID.randomUUID().toString().replaceAll("-", ""):id;
		}else {
			id = UUID.randomUUID().toString().replaceAll("-", "");
		}
		VerifyCode code = getVerifyCode(id);
		if(code == null) {
			throw BizException.COMMON_CUSTOMIZE_ERROR.format("生成验证码异常");
		}
		//设置缓存
		SysRedis.SYS_VERIFY_CODE.set(code.getId(), code.getCode());
		return code;
	}

	@Override
	public boolean checkVerifyCode(String id, String code) {
		String compCode = (String) SysRedis.SYS_VERIFY_CODE.get(id);
		if(ObjectUtils.isEmptyOrNull(compCode) || !compCode.equals(code)) {
			return false;
		}
		//删除缓存
		SysRedis.SYS_VERIFY_CODE.del(id);
		
		return true;
	}
	
	private VerifyCode getVerifyCode(String id) {
        // 在内存中创建图象
        int width = 70, height = 30;
        BufferedImage image = new BufferedImage(width, height,BufferedImage.TYPE_INT_RGB);
        // 获取图形上下文
        Graphics g = image.getGraphics();
        // 生成随机类
        Random random = new Random();
        // 设定背景色
        g.setColor(getRandColor(200, 250));
        g.fillRect(0, 0, width, height);
        // 设定字体
        g.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        // 随机产生155条干扰线，使图象中的认证码不易被其它程序探测到
        g.setColor(getRandColor(160, 200));
        for (int i = 0; i < 155; i++) {
            int x = random.nextInt(width);
            int y = random.nextInt(height);
            int xl = random.nextInt(12);
            int yl = random.nextInt(12);
            g.drawLine(x, y, x + xl, y + yl);
        }
        // 取随机产生的认证码(6位数字)
        String code = "";
        for (int i = 0; i < 4; i++) {
            String rand = String.valueOf(random.nextInt(10));
            code += rand;
            // 将认证码显示到图象中
            g.setColor(new Color(20 + random.nextInt(110), 20 + random
                    .nextInt(110), 20 + random.nextInt(110)));
            // 调用函数出来的颜色相同，可能是因为种子太接近，所以只能直接生成
            g.drawString(rand, 12 * i + 9, 23);
        }
        // 图象生效
        g.dispose();
        try {
        	ByteArrayOutputStream baos = new ByteArrayOutputStream();   
            ImageIO.write(image, "png", baos);   
            byte[] bytes = baos.toByteArray();   
            String imageStr = Base64.encode(bytes);
            baos.close();
            imageStr = "data:image/jpg;base64,"+imageStr;
            
            VerifyCode verifyCode = new VerifyCode();
            verifyCode.setId(id);
            verifyCode.setCode(code);
            verifyCode.setImage(imageStr);
            return verifyCode;
        } catch (Exception e) {
            System.out.println("验证码图片产生出现错误：" + e.toString());
        }
        return null;
	}

    /*
     * 给定范围获得随机颜色
     */
    private Color getRandColor(int fc, int bc) {
        Random random = new Random();
        if (fc > 255)
            fc = 255;
        if (bc > 255)
            bc = 255;
        int r = fc + random.nextInt(bc - fc);
        int g = fc + random.nextInt(bc - fc);
        int b = fc + random.nextInt(bc - fc);
        return new Color(r, g, b);
    }
}
