package com.wlzq.service.base.sys;

import com.wlzq.core.SpringApplicationContext;
import com.wlzq.service.base.sys.service.IDictionaryService;

public class DictionaryFacade {
	private static IDictionaryService dicSrv;
	
	public static String getValue(String key) {
		return getDicSrv().getValue(key);
	}

	public static Integer getInteger(String key) {
		return getDicSrv().getInteger(key);
	}
	
	protected static IDictionaryService getDicSrv() {
		if(dicSrv != null) return dicSrv;
		IDictionaryService obj = (IDictionaryService) SpringApplicationContext.getBean("dictionaryService");		
		return obj;
	}
	
}
