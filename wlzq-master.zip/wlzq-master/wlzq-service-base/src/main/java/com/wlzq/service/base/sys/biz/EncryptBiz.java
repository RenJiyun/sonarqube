package com.wlzq.service.base.sys.biz;

import com.wlzq.core.dto.StatusObjDto;
import com.wlzq.service.base.sys.dto.RSAPublicKeyDto;

/**
 * EncryptBiz类
 * @author 
 * @version 1.0
 */
public interface EncryptBiz {	
	
	/**
	 * 获取公钥
	 * @return
	 */
	StatusObjDto<RSAPublicKeyDto> getPublicKey();

	/**
	 * 加密
	 * @param value
	 * @return
	 */
	String encrypt(String value);
	
	/**
	 * 解密
	 * @param value
	 * @return
	 */
	String decrypt(String value);
	
	/**
	 * base64解密
	 * @param value
	 * @return
	 */
	String decryptBase64(String value);
	
	/**
	 * 用户信息解密
	 * @param value 
	 * @param appVersion 版本，需要加密且该版本大于等于指定版本需要加密
	 * @return
	 */
	String decryptUser(String value,String appVersion);
}
