package com.wlzq.service.base.serialnum.biz.impl;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wlzq.common.utils.BeanUtils;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.common.utils.RandomUtils;
import com.wlzq.service.base.serialnum.biz.SerialNumberGenBiz;
import com.wlzq.service.base.serialnum.dao.SerialNumberDao;
import com.wlzq.service.base.serialnum.exception.SerialException;
import com.wlzq.service.base.serialnum.model.MaxSerialNumber;
import com.wlzq.service.base.serialnum.model.SerialNumber;

/**
 * 序列号生成
 *
 */
@Service("serialNumberGenBiz")
public class SerialNumberGenBizImpl implements SerialNumberGenBiz {

	private static final int CACHE_COUNT = 2000;// 本地缓存的数量
	/**
	 * 可重入锁
	 */
	private static final Lock LOCK = new ReentrantLock();

	/**
	 * 本地存储序列号。每次对数据库的最后序列号值加cacheCount，然后在本地就可以有cacheCount个序列号可用。
	 * 如果初始化时或本地挂掉，则会重新从数据库加载到本地
	 */
	private static final Map<String, MaxSerialNumber> seqMap = new HashMap<String, MaxSerialNumber>();

	@Autowired
	private SerialNumberDao serialNumberHelperDao;

	public String generator(String serialNumberKey, String serialNumberTmpl, String comment) {
		return generatorBatch(serialNumberKey, serialNumberTmpl, comment, 1).get(0);
	}
	
	@Transactional
	public List<String> generatorBatch(String serialNumberKey, String serialNumberTmpl, String comment, int count) {
		Calendar genTime = Calendar.getInstance(); // 生成时间(当前时间)
		SerialNumber serialNumberHelper = null;
		try {
			// 在数据库或者缓存中拿到数据
			serialNumberHelper = updateSnLastGeneNum(serialNumberKey, serialNumberTmpl, comment, count, genTime);
			// 根据规则和数据生成流水号
			List<String> serialNumbers = genSerialNumber(serialNumberHelper.getSerialNumberTmpl(),
					serialNumberHelper.getLastGenerateNumber(), genTime, count);
			return serialNumbers;
		} catch (Exception e) {
			throw SerialException.SERIAL_NUMBER_GEN_ERROR;
		}
	}
	
	/***
	 * 根据规则和数据生成流水号，只是生成。没有数据修改和数据库修改。
	 * @param serialNumberTmpl 流水号模板
	 * @param lastGenerateNumber 上一次的流水号号码
	 * @param geneTime 生成时间
	 * @param count 数量
	 * @return
	 */
	private List<String> genSerialNumber(String serialNumberTmpl, Integer lastGenerateNumber, Calendar geneTime, int count) {
		List<String> serialNos = new ArrayList<String>();
		String[] snSplits = serialNumberTmpl.split(",");
		for (int i = 0; i < count; i++) {
			StringBuilder serialNo = new StringBuilder();
			for (String snSplit : snSplits) {
				if(ObjectUtils.isEmptyOrNull(snSplit)) continue;
				String[] codes = snSplit.split(":");
				if (codes.length == 2) {
					String sequenceKey = codes[0];
					String sequenceVal = codes[1];
					String val = "";
					if (sequenceKey.equals("string")) {
						val = sequenceVal;
					} else if (sequenceKey.equals("date")) {
						SimpleDateFormat format = new SimpleDateFormat(sequenceVal);
						val = format.format(geneTime.getTime());
					} else if (sequenceKey.equals("sequence")) {
						int number = lastGenerateNumber + (i + 1);

						String[] sequences = sequenceVal.split("\\|");
						int width = Integer.parseInt(sequences[0]);

						String pattern = getPattern(width);

						val = getNumber(pattern, number);
					} else if (sequenceKey.equals("rnd")) {
						val = RandomUtils.random(Integer.parseInt(sequenceVal));
					}

					serialNo.append(val);
				}
			}

			serialNos.add(serialNo.toString());
		}
		return serialNos;
	}

	/***
	 * 更新流水号
	 * @param snKey 流水号规则数据库的key值
	 * @param snTempl 流水号规则数据库的流水号模板值
	 * @param comment 
	 * @param count 这次生成的流水号数量
	 * @param genTime 生成时间
	 * @return
	 */
	private SerialNumber updateSnLastGeneNum(String snKey, String snTempl, String comment, int count, Calendar genTime) {
		// 取一条才从本地内存取，批量取得话就直接取数据库
		if (count == 1) {
			return genOneSerialNumberFromCache(snKey, snTempl, comment, genTime);
		} else {
			return genBatchSerialNumberFromDb(snKey, snTempl, comment, count, genTime);
		}
	}

	private SerialNumber genOneSerialNumberFromCache(String snKey, String snTempl, String comment, Calendar genTime) {
		try {
			LOCK.lock();
			// 看本地缓存的数据
			MaxSerialNumber localSeqDto = seqMap.get(snKey);
			if (localSeqDto == null) {
				localSeqDto = genBatchSerialNumberFromDb(snKey, snTempl, comment, CACHE_COUNT, genTime);
				seqMap.put(snKey, localSeqDto);
			} 
			// 检查本地流水号是否用完，如果用完则从内存中读取一批
			if(localSeqDto.getMaxSerialNumber() <= localSeqDto.getLastGenerateNumber()) {
				
				localSeqDto = genBatchSerialNumberFromDb(snKey, snTempl, comment, CACHE_COUNT, genTime);
				seqMap.put(snKey, localSeqDto);
			}
			// 流水号需要重置，重新从数据库中加载
			if (needResetSn(localSeqDto, genTime)) {
				localSeqDto = genBatchSerialNumberFromDb(snKey, snTempl, comment, CACHE_COUNT, genTime);
				seqMap.put(snKey, localSeqDto);
			}
	
			SerialNumber serialNumberHelper = new SerialNumber();
			BeanUtils.copyToBean(localSeqDto, serialNumberHelper);
			localSeqDto.setLastGenerateNumber(localSeqDto.getLastGenerateNumber() + 1);// 设置本地缓存
	
			return serialNumberHelper;
		} finally {
			LOCK.unlock();
		}
	}

	/***
	 * 从数据库中获取一批可用的流水号。
	 * @param serialNumberKey
	 * @param serialNumberTmpl
	 * @param comment
	 * @param count
	 * @param geneTime
	 * @return
	 */
	private MaxSerialNumber genBatchSerialNumberFromDb(String serialNumberKey, String serialNumberTmpl, String comment,
			int count, Calendar geneTime) {
		Lock lock = new ReentrantLock();// 锁对象 
		try{
			lock.lock();
			SerialNumber serialNumberHelper = serialNumberHelperDao.getRoleByKey(serialNumberKey);
			//不存在，新增一个流水号实体 
			if (serialNumberHelper == null) {
				serialNumberHelper = new SerialNumber();
				serialNumberHelper.setLastGenerateNumber(0); //默认最后产生的流水号为0
				serialNumberHelper.setLastGenerateTime(geneTime.getTime());// 设置新的时间
				serialNumberHelper.setSerialNumberKey(serialNumberKey);
				serialNumberHelper.setSerialNumberTmpl(serialNumberTmpl);
				serialNumberHelper.setComments(comment);
			}
			
			//更新数据到实体
			int origLastGeneNum = serialNumberHelper.getLastGenerateNumber();
			origLastGeneNum = needResetSn(serialNumberHelper, geneTime) ? 0 : origLastGeneNum;
			int lastGenerateNumber = origLastGeneNum + count;
			serialNumberHelper.setLastGenerateNumber(lastGenerateNumber);// 设置新的序列值
			serialNumberHelper.setLastGenerateTime(geneTime.getTime());// 设置新的时间
			//将实体写入到数据库
			if (serialNumberHelper.getId() != null && serialNumberHelper.getId() > 0) {
				serialNumberHelperDao.update(serialNumberHelper);
			} else {
				serialNumberHelperDao.create(serialNumberHelper);
			}
			//返回给业务可以使用的最后产生的流水号
			MaxSerialNumber retSerialNumberBo = new MaxSerialNumber();
			BeanUtils.copyToBean(serialNumberHelper, retSerialNumberBo);
			retSerialNumberBo.setMaxSerialNumber(lastGenerateNumber);// 最大数量
			retSerialNumberBo.setLastGenerateNumber(origLastGeneNum);// 返回原来的号码以便生成

			return retSerialNumberBo;
		} finally {
			lock.unlock();
		}
	}

	/***
	 * 是否需要重置流水号
	 * @param serialNumberHelper
	 * @param geneTime
	 * @return
	 */
	private boolean needResetSn(SerialNumber serialNumberHelper, Calendar geneTime) {
		// serialNumberTmpl形如：string:201,date:yyyyMMdd,sequence:6|month,rnd:4
		String[] snSplits = serialNumberHelper.getSerialNumberTmpl().split(",");
		Date lastGenerateTime = serialNumberHelper.getLastGenerateTime();
		Calendar lastGenerateTimeCal = Calendar.getInstance();
		lastGenerateTimeCal.setTime(lastGenerateTime);
		for (String snSplit : snSplits) {
			if(ObjectUtils.isEmptyOrNull(snSplit)) continue;
			String[] codes = snSplit.split(":");
			if (codes.length == 2) {
				String sequenceKey = codes[0];
				String sequenceVal = codes[1];
				if (sequenceKey.equals("sequence")) {
					String[] sequences = sequenceVal.split("\\|");
					String resetCycle = sequences[1];// 如 month

					if (resetCycle.equals("no")) {
						return false;
					}
					boolean sameYear = geneTime.get(Calendar.YEAR) == lastGenerateTimeCal.get(Calendar.YEAR);// 同年
					boolean sameMonth = geneTime.get(Calendar.MONTH) == lastGenerateTimeCal.get(Calendar.MONTH);// 同月
					boolean sameDay = geneTime.get(Calendar.DAY_OF_MONTH) == lastGenerateTimeCal
							.get(Calendar.DAY_OF_MONTH);// 同日
					if (resetCycle.equals("year")) {
						return !sameYear;
					} else if (resetCycle.equals("month")) {
						return !(sameYear && sameMonth);
					} else if (resetCycle.equals("day")) {
						return !(sameYear && sameMonth && sameDay);
					}
				}
			}
		}
		return false;
	}

	/**
	 * 获取排序，位数为num位，不足的用0补足位
	 * 
	 * @param num
	 *            需要生成多少位的数格式，不足的补全位
	 * @param number
	 *            需要生成号的排序，为上次生成排序加步长1
	 * @return 例如：num为6，number为3，生成的格式就是000003
	 */
	private static String getNumber(String pattern, int number) {
		String code = new DecimalFormat(pattern).format(number);
		return code;
	}

	/**
	 * 获取显示的格式
	 * 
	 * @param num
	 *            需要生成num，不足前面补0，例如6，格式就是000000
	 * @return
	 */
	private static String getPattern(int num) {
		return num <= 1 ? "0" : "0" + getPattern(num - 1);
	}
}
