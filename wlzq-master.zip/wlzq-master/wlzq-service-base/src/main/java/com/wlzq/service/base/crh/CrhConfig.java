package com.wlzq.service.base.crh;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "crh.service") 
public class CrhConfig {
	/**
	 * 财人汇服务根url
	 */
	private String url = "http://172.19.1.96:10510/crh/";

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}
