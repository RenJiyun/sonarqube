package com.wlzq.service.base.config;

import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.druid.pool.DruidDataSource;

/**
 *
 */

@Configuration
/*这里的oracle名字要与application.properties中的相同*/
@ConfigurationProperties("oracle")

public class OracleConfig {
	private Logger logger = LoggerFactory.getLogger(OracleConfig.class);  
    /*
	@NotNull
    private String username;

    @NotNull
    private String password;

    @NotNull
    private String url;
    */
    
    @Value("${spring.datasource.url:}")  
    private String dbUrl;  
      
    @Value("${spring.datasource.username:}")  
    private String username;  
      
    @Value("${spring.datasource.password:}")  
    private String password;  
      
    @Value("${spring.datasource.driverClassName:}")  
    private String driverClassName;  
      
    @Value("${spring.datasource.initialSize:1}")  
    private int initialSize;  
      
    @Value("${spring.datasource.minIdle:5}")  
    private int minIdle;  
      
    @Value("${spring.datasource.maxActive:20}")  
    private int maxActive;  
      
    @Value("${spring.datasource.maxWait:60000}")  
    private int maxWait;  
      
    @Value("${spring.datasource.timeBetweenEvictionRunsMillis:60000}")  
    private int timeBetweenEvictionRunsMillis;  
      
    @Value("${spring.datasource.minEvictableIdleTimeMillis:300000}")  
    private int minEvictableIdleTimeMillis;  
      
    @Value("${spring.datasource.validationQuery:1}")  
    private String validationQuery;  
      
    @Value("${spring.datasource.testWhileIdle:true}")  
    private boolean testWhileIdle;  
      
    @Value("${spring.datasource.testOnBorrow:false}")  
    private boolean testOnBorrow;  
      
    @Value("${spring.datasource.testOnReturn:false}")  
    private boolean testOnReturn;  
      
    @Value("${spring.datasource.poolPreparedStatements:true}")  
    private boolean poolPreparedStatements;  
      
    @Value("${spring.datasource.maxPoolPreparedStatementPerConnectionSize:20}")  
    private int maxPoolPreparedStatementPerConnectionSize;  
      
    @Value("${spring.datasource.filters:stat,log4j}")  
    private String filters;  
      
    @Value("{spring.datasource.connectionProperties:druid.stat.mergeSql=true;druid.stat.slowSqlMillis=5000}")  
    private String connectionProperties;  
    
    /*
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    */

    @Bean
    DataSource dataSource() throws SQLException {
    	/*
        OracleDataSource dataSource = new OracleDataSource();
        dataSource.setUser(username);
        dataSource.setPassword(password);
        dataSource.setURL(url);

        return dataSource;
		*/
    	
    	DruidDataSource datasource = new DruidDataSource();  
        
        datasource.setUrl(this.dbUrl);  
        datasource.setUsername(username);  
        datasource.setPassword(password);  
        datasource.setDriverClassName(driverClassName);  
          
        //configuration  
        datasource.setInitialSize(initialSize);  
        datasource.setMinIdle(minIdle);  
        datasource.setMaxActive(maxActive);  
        datasource.setMaxWait(maxWait);  
        datasource.setTimeBetweenEvictionRunsMillis(timeBetweenEvictionRunsMillis);  
        datasource.setMinEvictableIdleTimeMillis(minEvictableIdleTimeMillis);  
        datasource.setValidationQuery(validationQuery);  
        datasource.setTestWhileIdle(testWhileIdle);  
        datasource.setTestOnBorrow(testOnBorrow);  
        datasource.setTestOnReturn(testOnReturn);  
        datasource.setPoolPreparedStatements(poolPreparedStatements);  
        datasource.setMaxPoolPreparedStatementPerConnectionSize(maxPoolPreparedStatementPerConnectionSize);  
        try {  
            datasource.setFilters(filters);  
        } catch (SQLException e) {  
            logger.error("druid configuration initialization filter", e);  
        }  
        datasource.setConnectionProperties(connectionProperties);  
          
        return datasource;  
       
    }
}
