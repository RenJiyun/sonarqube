package com.wlzq.service.base.sys.biz.impl;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wlzq.common.utils.HttpClientUtils;
import com.wlzq.common.utils.JsonUtils;
import com.wlzq.service.base.sys.biz.ExternalRequestBiz;
import com.wlzq.service.base.sys.dao.ApiExternalRequestDao;
import com.wlzq.service.base.sys.model.ApiExternalRequest;


/**
 * ExternalRequest实现类
 * 
 * @author
 * @version 1.0
 */
@Service
public class ExternalRequestBizImpl implements ExternalRequestBiz {
	private static final Logger log = LoggerFactory.getLogger(ExternalRequestBizImpl.class);
	@Autowired
	private ApiExternalRequestDao externalRequestDao;

	public <T extends Object> String doGet(String url, Map<String, T> params,String charSet) {
		Date submitTime = new Date();
		String result = HttpClientUtils.doGet(url, params, charSet);
		Date returnTime = new Date();
		saveRequest(url, JsonUtils.object2JSON(params), result, submitTime, returnTime);
		return result;
	}

	public  <T extends Object> String doPost(String url, Map<String, T> params,	Map<String, String> reqcookies,Map<String, String> header,String charset) {
		Date submitTime = new Date();
		String result = HttpClientUtils.doPost(url, params,reqcookies,header,charset);
		Date returnTime = new Date();
		saveRequest(url, JsonUtils.object2JSON(params), result, submitTime, returnTime);
		return result;
	}

	public  <T extends Object> String doPost(String url, String body,Map<String, String> header) {
		Date submitTime = new Date();
		String result = HttpClientUtils.doPost(url,body,header,20000);
		Date returnTime = new Date();
		saveRequest(url, body, result, submitTime, returnTime);
		return result;
	}

	private void saveRequest(String url,String params,String result,Date submitTime,Date returnTime) {
		try {
			ApiExternalRequest request = new ApiExternalRequest();
			request.setUrl(url);
			params = params.length() > 512? params.substring(0,512):params;
			request.setParams(params);
			request.setResult(result);
			request.setSubmitTime(submitTime);
			request.setReturnTime(returnTime);
			request.setSpend(returnTime.getTime() - submitTime.getTime());
			request.setCreateTime(new Date());
			externalRequestDao.insert(request);
		}catch(Exception ex) {
			log.error("请求保存异常,",ex);
		}
	}
}
