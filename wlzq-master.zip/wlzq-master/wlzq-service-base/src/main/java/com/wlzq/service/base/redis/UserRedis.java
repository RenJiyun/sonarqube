package com.wlzq.service.base.redis;

import com.wlzq.service.base.sys.RedisFacadeAbstract;

public class UserRedis  extends RedisFacadeAbstract {

	/**令牌信息 */
	public static final UserRedis TOKEN_INFO = new UserRedis("account:access:token:",30*24*3600);
	/**用户信息, KEY:userid，值 :accuser*/
	public static final UserRedis USER_INFO = new UserRedis("account:user:info:",30*24*3600);
	/**手机号对应用户信息, KEY:mobile，值 :accuser*/
	public static final UserRedis USER_INFO_BY_MOBILE = new UserRedis("account:user:infobymobile:",30*24*3600);
	/**用户userid信息, KEY:MOBILE，值 :USERID*/
	public static final UserRedis USER_ID_INFO = new UserRedis("account:userid:info:",30*24*3600);
	/**客户信息, KEY:客户登录token，值 :客户号*/
	public static final UserRedis ACCESS_CUSTOMER_INFO = new UserRedis("account:access:customer");
	/**客户信息, KEY:客户号+类型(1:商城登录)，值 :客户信息*/
	public static final UserRedis CUSTOMER_INFO = new UserRedis("account:customer:info",24*3600);
	/**客户登录终端信息, KEY:token，值 :LoginTerminalInfo*/
	public static final UserRedis CUSTOMER_TERMINAL_INFO = new UserRedis("account:customer:terminal",24*3600);
	/**分享码信息 KEY:分享码，值 :userid*/
	public static final UserRedis SHARE_CODE_INFO = new UserRedis("account:sharecode:info:",30*24*3600);
	/**员工信息 */
	public static final UserRedis STAFF_INFO = new UserRedis("account:staff:info:",2*24*3600);
	/**客户加密密码 */
	public static final UserRedis CUSTOMER_PASS = new UserRedis("account:customer:pass:",24*3600);
	
	private String redisPrefix;
	private int timeoutSeconds;

	private UserRedis(String redisPrefix) {
		this.redisPrefix = redisPrefix;
	}

	private UserRedis(String redisPrefix,int timeoutSeconds) {
		this.redisPrefix = redisPrefix;
		this.timeoutSeconds = timeoutSeconds;
	}

	@Override
	protected String getRedisPrefix() {
		return redisPrefix;
	}

	@Override
	protected int getTimeoutSeconds() {
		return timeoutSeconds;
	}
}