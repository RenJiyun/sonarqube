package com.wlzq.service.base.serialnum;

import java.util.List;

/***
 * 流水号生成器接口描述。<br>
 * 注意：序列号模板和备注仅在第一创建时有效，用户初始化数据配置<br>
 * 在第二次执行时，模板使用数据库中已有的，备注也不会被更新到数据库。
 * @author 
 * @date 2016年3月31日
 * @version 1.0
 */
public interface ISerialNumberGenerator {
	
	/***
	 * 产生一个流水号
	 * @param key 流水号规则key
	 * @param template 流水号模板
	 * @param remark 流水号备注
	 * @return
	 */
	public String generate(String key, String template, String remark) ;
	
	
	/***
	 * 批量生成流水号
	 * @param key 流水号规则key
	 * @param template 流水号模板
	 * @param remark 流水号备注
	 * @param count 生成数量
	 * @return 
	 */
	public List<String> generateBatch(String key, String template, String remark, Integer count);	
}
