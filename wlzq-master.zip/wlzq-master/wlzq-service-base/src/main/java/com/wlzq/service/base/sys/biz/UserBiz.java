package com.wlzq.service.base.sys.biz;

import com.wlzq.common.model.account.AccTokenUser;
import com.wlzq.common.model.account.Customer;
import com.wlzq.core.dto.StatusObjDto;

/**
 *  UserBiz类
 * @author 
 * @version 1.0
 */
public interface UserBiz {	
	
	/**
	 * token查询用户信息
	 * @param token
	 * @param onlyFromCache 是否只从缓存查询信息
	 * @return
	 */
	StatusObjDto<AccTokenUser> findUserByToken(String token,boolean onlyFromCache);

	/**
	 * 手机查询用户信息
	 * @param token
	 * @return
	 */
	AccTokenUser findUserByMobile(String mobile);
	
	/**
	 * token查询客户
	 * @param custToken
	 * @param onlyFromCache 是否只从缓存查询信息
	 * @return 客户信息
	 */
	StatusObjDto<Customer> findCustomerByToken(String custToken,boolean onlyFromCache);
	
	/**
	 * customerId查询客户
	 * @param customerId 客户ID
	 * @return 客户信息
	 */
	StatusObjDto<Customer> findCustomerByCustomerId(String customerId);
}
