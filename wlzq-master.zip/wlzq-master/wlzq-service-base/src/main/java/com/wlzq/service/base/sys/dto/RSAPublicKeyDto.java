package com.wlzq.service.base.sys.dto;

public class RSAPublicKeyDto {
	private String modulus;
	private String publicExponent;
	
	public RSAPublicKeyDto() {
	}
	public RSAPublicKeyDto(String modulus, String publicExponent) {
		super();
		this.modulus = modulus;
		this.publicExponent = publicExponent;
	}
	public String getModulus() {
		return modulus;
	}
	public void setModulus(String modulus) {
		this.modulus = modulus;
	}

	public String getPublicExponent() {
		return publicExponent;
	}
	public void setPublicExponent(String publicExponent) {
		this.publicExponent = publicExponent;
	}
}
