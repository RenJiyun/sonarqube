package com.wlzq.service.base.sys.service;

/**
 * Activity service类
 * @author 
 * @version 1.0
 */
public interface IDictionaryService {	

	/**
	 * 获取字典值
	 * @param key
	 * @return
	 */
	String getValue(String key);
	
	/**
	 * 获取整型字典值
	 * @param key
	 * @return
	 */
	Integer getInteger(String key);
}
