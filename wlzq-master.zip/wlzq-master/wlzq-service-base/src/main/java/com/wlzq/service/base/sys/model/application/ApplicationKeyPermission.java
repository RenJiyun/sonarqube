package com.wlzq.service.base.sys.model.application;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * 应用权限
 * @author louie
 * @version 2017-11-07
 */
public class ApplicationKeyPermission  implements Serializable {
	
	private static final long serialVersionUID = 14814284833473L;
	private String key;		// key
	private Map<String,List<String>> methods;		//方法权限,key:方法，value:ip列表
	
	public ApplicationKeyPermission() {
		super();
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public Map<String, List<String>> getMethods() {
		return methods;
	}

	public void setMethods(Map<String, List<String>> methods) {
		this.methods = methods;
	}

}