package com.wlzq.service.base.sys.biz.application.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.service.base.redis.SysRedis;
import com.wlzq.service.base.sys.biz.application.AccApplicationBiz;
import com.wlzq.service.base.sys.dao.application.AccApplicationDao;
import com.wlzq.service.base.sys.dao.application.ApplicationMethodDao;
import com.wlzq.service.base.sys.model.application.ApplicationKeyPermission;
import com.wlzq.service.base.sys.model.application.ApplicationMethod;
import com.wlzq.service.base.sys.model.application.ApplicationMethodPermission;

/**
 * AccApplicationBiz接口实现
 * @author louie
 *
 */
@Service
public class AccApplicationBizImpl implements AccApplicationBiz {
	@Autowired
	private AccApplicationDao accApplicationDao;
	@Autowired
	private ApplicationMethodDao applicationMethodDao;

	public String getSecret(String key) {
		if(ObjectUtils.isEmptyOrNull(key)) {
			return null;
		}
		String secret = (String) SysRedis.APP_INFO.get(key);
		
		if(ObjectUtils.isEmptyOrNull(secret)) {
			secret = accApplicationDao.findByKey(key);
			if(!ObjectUtils.isEmptyOrNull(secret)) {
				SysRedis.APP_INFO.set(key, secret,30*24*3600);
			}
		}
		
		return secret;
	}

	public void deleteCache(String key) {
		SysRedis.APP_INFO.del(key);
	}

	public List<ApplicationMethod> methods(String key) {
		if(ObjectUtils.isEmptyOrNull(key)) {
			return new ArrayList<ApplicationMethod>();
		}
		List<ApplicationMethod> methods = (List<ApplicationMethod>) SysRedis.APP_METHODS.get(key);
		if(methods == null) {
			methods = applicationMethodDao.findMethods(key);
			if(methods != null) {
				SysRedis.APP_METHODS.set(key, methods,3600);
			}
		}
		return methods;
	}
	

	public boolean hasPermission(String key, String method,String ip) {
		if(ObjectUtils.isEmptyOrNull(key) || ObjectUtils.isEmptyOrNull(method) || 
				ObjectUtils.isEmptyOrNull(ip)) {
			return false;
		}
		
		ApplicationKeyPermission keyPermission = getKeyPermission(key);
		if(keyPermission == null) {//没有配置应用权限，判断方法权限
			ApplicationMethodPermission permission = getMethodPermission(method);
			if(permission == null) {
				return true;
			}
			
			List<String> keys = permission.getKeys();
			List<String> ips = permission.getIps();
			if(keys.size() > 0 && !keys.contains(key)){ //若添加key限制且不在权限key中,无权限
				return false;
			}
			if(ips.size() > 0 && !ips.contains(ip)){ //若添加ip限制且不在权限ip中,无权限
				return false;
			}
			return true;
		}else {//判断应用权限
			//若应用无方法限制，有权限
			if(keyPermission.getMethods().keySet().size() == 0) return true;
			
			//若应用不包含方法的访问，无权限
			if(!keyPermission.getMethods().containsKey(method)) {
				return false;
			}
			//无IP限制,有权限
			if(keyPermission.getMethods().get(method).size() == 0) return true;
			boolean isContainsIp = keyPermission.getMethods().get(method).contains(ip);
			return isContainsIp;
		}
	}

	public boolean hasPermission(String method,String ip) {
		if(ObjectUtils.isEmptyOrNull(method) || ObjectUtils.isEmptyOrNull(ip)) {
			return false;
		}
		
		ApplicationMethodPermission permission = getMethodPermission(method);
		if(permission == null) {
			return true;
		}
		
		List<String> ips = permission.getIps();
		if(ips.size() > 0 && !ips.contains(ip)){ //若添加ip限制且不在权限ip中,无权限
			return false;
		}
		return true;
	}
	/**
	 * 获取方法权限信息
	 * @param method
	 * @return
	 */
	private ApplicationMethodPermission getMethodPermission(String method) {
		ApplicationMethodPermission permission = (ApplicationMethodPermission) SysRedis.APP_METHODS.get(method);
		if(permission != null) {
			return permission;
		}

		permission = new ApplicationMethodPermission();
		List<ApplicationMethod> methods = applicationMethodDao.findMethodByName(method);
		if(methods.size() == 0) {
			permission.setKeys(Lists.newArrayList());
			permission.setIps(Lists.newArrayList());
			permission.setMethod(method);
		}else {
			List<String> keys = new ArrayList<String>();
			List<String> ips = new ArrayList<String>();
			for(ApplicationMethod met:methods) {
				if(!keys.contains(met.getKey())) {
					keys.add(met.getKey());
				}
				String pips = met.getIp();
				if(ObjectUtils.isEmptyOrNull(pips)) continue;
				String[] pipa = pips.split(",");
				for(String pip:pipa) {
					if(!ips.contains(pip)) {
						ips.add(pip);
					}
				}
			}
			permission.setKeys(keys);
			permission.setIps(ips);
			permission.setMethod(method);
		}
		SysRedis.APP_METHODS.set(method, permission);
		
		return permission;
	}
	
	/**
	 * 获取应用权限信息
	 * @param key
	 * @return
	 */
	private ApplicationKeyPermission getKeyPermission(String key) {
		if(ObjectUtils.isEmptyOrNull(key)) return null;
		ApplicationKeyPermission permission = (ApplicationKeyPermission) SysRedis.APP_KEY_PERMISSION.get(key);
		if(permission != null) {
			return permission;
		}
		
		List<ApplicationMethod> methods = applicationMethodDao.findMethods(key);
		if(methods.size() == 0) {
			permission = new ApplicationKeyPermission();
			permission.setKey(key);
			Map<String, List<String>> pMethods = Maps.newHashMap();
			permission.setMethods(pMethods);
			SysRedis.APP_KEY_PERMISSION.set(key, permission);
			return permission;
		}
		permission = new ApplicationKeyPermission();
		permission.setKey(key);
		Map<String,List<String>> keyPermission = new HashMap<String,List<String>>();
		for(ApplicationMethod met:methods) {
			String method = met.getMethod();
			if(keyPermission.containsKey(method))  continue;
			String pips = met.getIp();
			List<String> ips = new ArrayList<String>();
			if(ObjectUtils.isEmptyOrNull(pips)) {
				keyPermission.put(method, ips);
				continue;
			}
			String[] pipa = pips.split(",");
			for(String pip:pipa) {
				if(!ips.contains(pip)) {
					ips.add(pip);
				}
			}

			keyPermission.put(method, ips);
		}
		permission.setMethods(keyPermission);
		
		SysRedis.APP_KEY_PERMISSION.set(key, permission);
		
		return permission;
	}
}
