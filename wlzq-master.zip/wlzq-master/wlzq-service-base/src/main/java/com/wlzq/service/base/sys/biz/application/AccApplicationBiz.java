package com.wlzq.service.base.sys.biz.application;

import java.util.List;

import com.wlzq.service.base.sys.model.application.ApplicationMethod;

/**
 * AccApplicationBiz类
 * @author 
 * @version 1.0
 */
public interface AccApplicationBiz {	
	/**
	 * 获取秘钥
	 * @param key
	 * @return
	 */
	String getSecret(String key);

	void deleteCache(String key);
	/**
	 * 获取应用所有方法
	 * @param key
	 * @return
	 */
	List<ApplicationMethod> methods(String key);
	/**
	 * 是否有权限访问,未添加限制，则可以访问全部接口；若添加访问方法和IP，指定IP才能访问该方法，若无指定
	 * ip,则任何ip可访问
	 * @param key
	 * @param method
	 * @param ip
	 * @return
	 */
	boolean hasPermission(String key,String method,String ip);
	
	/**
	 * 检查ip是否有权限访问，未添加限制，则可以访问全部接口；若添加访问方法和IP，指定IP才能访问该方法 ，若无ip,则任何ip可访问
	 * @param method
	 * @param ip
	 * @return
	 */
	boolean hasPermission(String method,String ip);
}
