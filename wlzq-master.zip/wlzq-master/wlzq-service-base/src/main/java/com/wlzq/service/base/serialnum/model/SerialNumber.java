package com.wlzq.service.base.serialnum.model;

import java.io.Serializable;

/**
 * SerialNumberHelper 实体类
 * @author 雅居乐 2015-10-12 15:22:36
 * @version 1.0
 */
public class SerialNumber implements Serializable{
	private static final long serialVersionUID = -3704383662316578110L;
	
	/**流水号生成规则id*/
	private java.lang.Integer id;
	/**流水号生成规则key*/
	private java.lang.String serialNumberKey;	
	/**流水号生成模板*/
	private java.lang.String serialNumberTmpl;	
	/**上次生成的流水号*/
	private java.lang.Integer lastGenerateNumber;	
	/**上次生成流水号的时间*/
	private java.util.Date lastGenerateTime;	
	/**序列号说明*/
	private java.lang.String comments;	
	//columns END
	

	public java.lang.Integer getId() {
		return id;
	}

	public void setId(java.lang.Integer id) {
		this.id = id;
	}
	
	public java.lang.String getSerialNumberKey() {
		return this.serialNumberKey;
	}

	public void setSerialNumberKey(java.lang.String value) {
		this.serialNumberKey = value;
	}
	public java.lang.String getSerialNumberTmpl() {
		return this.serialNumberTmpl;
	}
	
	public void setSerialNumberTmpl(java.lang.String value) {
		this.serialNumberTmpl = value;
	}
	public java.lang.Integer getLastGenerateNumber() {
		return this.lastGenerateNumber;
	}
	
	public void setLastGenerateNumber(java.lang.Integer value) {
		this.lastGenerateNumber = value;
	}
	
	public java.util.Date getLastGenerateTime() {
		return this.lastGenerateTime;
	}
	
	public void setLastGenerateTime(java.util.Date value) {
		this.lastGenerateTime = value;
	}
	public java.lang.String getComments() {
		return this.comments;
	}
	
	public void setComments(java.lang.String value) {
		this.comments = value;
	}

}

