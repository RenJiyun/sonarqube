package com.wlzq.service.base.mq;

import org.apache.rocketmq.client.producer.DefaultMQProducer;
import org.apache.rocketmq.common.message.Message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.wlzq.core.SpringApplicationContext;
import com.wlzq.service.base.mq.consumer.MessageConsumer;

public class MessageUtils {
	/**
	 * 发送消息到消息队列
	 * @param topic 消息主题
	 * @param tags	消息标签，标识一类业务的处理
	 * @param data
	 */
	public static void send(String topic,String tags,Object data) {
		DefaultMQProducer defaultProducer = (DefaultMQProducer) SpringApplicationContext.getBean("defaultProducer");
		if(defaultProducer == null) return;
		String json = JSON.toJSONString(data, SerializerFeature.WriteMapNullValue);
        Message msg = new Message(topic,tags,json.getBytes());
        try {
	           defaultProducer.sendOneway(msg);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	}
	
	/**
	 * 发送消息到消息队列
	 * @param topic 消息主题
	 * @param tags	消息标签，标识一类业务的处理
	 * @param data
	 */
	public static void sendDelay(String topic,String tags, Integer level, Object data) {
		DefaultMQProducer defaultProducer = (DefaultMQProducer) SpringApplicationContext.getBean("defaultProducer");
		if(defaultProducer == null) return;
		String json = JSON.toJSONString(data, SerializerFeature.WriteMapNullValue);
        Message msg = new Message(topic,tags,json.getBytes());
        if (level != null) {
        	msg.setDelayTimeLevel(level);
		}
        try {
	           defaultProducer.sendOneway(msg);
	      } catch (Exception e) {
	         e.printStackTrace();
	      }
	}
	
	/**
	 * 注册消息消费处理器，只处理对应应用的业务
	 * @param tags 标识一类业务的处理
	 * @param messageConsumer 消息消费处理器
	 */
	public static void registConsumeHandler(String tags,MessageConsumer messageConsumer)  {
		MessageConsumerHandlers.registHandler(tags, messageConsumer);
	}
}
