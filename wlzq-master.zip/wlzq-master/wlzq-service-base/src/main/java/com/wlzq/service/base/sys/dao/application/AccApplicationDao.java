package com.wlzq.service.base.sys.dao.application;

import com.wlzq.common.persist.CrudDao;
import com.wlzq.core.annotation.MybatisScan;
import com.wlzq.service.base.sys.model.application.AccApplication;

/**
 * 应用信息DAO接口
 * @author louie
 * @version 2017-09-28
 */
@MybatisScan
public interface AccApplicationDao extends CrudDao<AccApplication> {
	String findByKey(String key);
}