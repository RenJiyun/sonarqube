package com.wlzq.service.base.sys.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.wlzq.common.utils.ObjectUtils;
import com.wlzq.service.base.sys.dao.DictionariesDao;
import com.wlzq.service.base.sys.model.Dictionaries;
import com.wlzq.service.base.sys.service.IDictionaryService;
/**
 * IDictionaryService service实现类
 * @author 
 * @version 1.0
 */
@Service("dictionaryService")
@Lazy(true)
public class DictionaryServiceImpl  implements IDictionaryService{
	
	@Autowired
	private DictionariesDao dictionariesDao;

	public String getValue(String key) {
		Dictionaries dic = dictionariesDao.findByCode(key);
		String value = dic == null?null:dic.getValue();
		return value;
	}

	public Integer getInteger(String key) {
		String value = getValue(key);
		if(ObjectUtils.isEmptyOrNull(value)) return null;
		Integer iValue = Integer.valueOf(value);
		return iValue;
	}
	
}
