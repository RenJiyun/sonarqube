package com.wlzq.service.base.sd.common;

public class SDFunctions {
	/** 获取RSA加密key */
	public static String STORE_RSA_KEY="1000000";
	/** 保证金支付 */
	public static String STORE_DEPOSIT_PAY="1001909";
	
}
