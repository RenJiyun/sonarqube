package com.wlzq.service.base.sys.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource({"classpath:image.properties"}) 
@ConfigurationProperties(prefix="imageconfig")
public class ImageConfig {
	@Value("${image.upload.url}")
	private String uploadUrl;

	@Value("${image.root.url}")
	private String rootUrl;

	@Value("${image.root.localurl:}")
	private String rootLocalUrl;
	
	@Value("${file.root.url}")
	private String fileRootUrl;

	public String getUploadUrl() {
		return uploadUrl;
	}

	public void setUploadUrl(String uploadUrl) {
		this.uploadUrl = uploadUrl;
	}

	public String getRootUrl() {
		return rootUrl;
	}

	public void setRootUrl(String rootUrl) {
		this.rootUrl = rootUrl;
	}
	
	public String getRootLocalUrl() {
		return rootLocalUrl;
	}

	public void setRootLocalUrl(String rootLocalUrl) {
		this.rootLocalUrl = rootLocalUrl;
	}

	public String getFileRootUrl() {
		return fileRootUrl;
	}
	
	public void setFileRootUrl(String fileRootUrl) {
		this.fileRootUrl = fileRootUrl;
	}
}
