package com.wlzq.service.base.sys.dao;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;

import org.springframework.core.annotation.Order;
import org.springframework.data.redis.core.Cursor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ScanOptions;
import org.springframework.stereotype.Component;

@Component("baseRedisDao")
@Order(1)
public class BaseRedisDao<K, V> {
	
	@Resource(name = "redisDatabase1")
	private RedisTemplate<K, V>  redisTemplate;
	@Resource(name = "redisDatabase2")
	private RedisTemplate<String, String> stringRedisTemplate;

//	@Resource(name = "redisDatabase0")
//	private RedisTemplate<K, V>  redisTemplate0;
	
	public void del(K key) {
		redisTemplate.delete(key);
//		redisTemplate0.delete(key);
	}

	
	public boolean exists(K key) {
		RedisTemplate<K, V> template = getRedisTemplate();
		return template.hasKey(key);
	}
	
	public boolean setNXEX(K key, V value) {
		return redisTemplate.opsForValue().setIfAbsent(key, value);
	}
	
	public void set(K key, V value) {
		redisTemplate.opsForValue().set(key, value);
	}

	
	public void set(K key, V value, int timeout, TimeUnit timeUnit) {
		redisTemplate.opsForValue().set(key, value, timeout, timeUnit);
	}

	
	public V get(K key) {
		return redisTemplate.opsForValue().get(key);
	}

	
	public Long size(K key) {
		return redisTemplate.opsForList().size(key);
	}
	
	
	public V index(K key, long index) {
		// TODO Auto-generated method stub
		return redisTemplate.opsForList().index(key, index);
	}
	
	public List<V> range(K key, long start, long end) {
		// TODO Auto-generated method stub
		return redisTemplate.opsForList().range(key, start, end);
	}
	
	
	public Long leftPush(K key, V value) {
		return redisTemplate.opsForList().leftPush(key, value);
	}

	
	public Long rightPush(K key, V value) {
		return redisTemplate.opsForList().rightPush(key, value);
	}

	
	public V leftPop(K key) {
		return redisTemplate.opsForList().leftPop(key);
	}

	
	public V leftPop(K key, long timeout, TimeUnit unit) {
		return redisTemplate.opsForList().leftPop(key, timeout, unit);
	}

	
	public V rightPop(K key) {
		return redisTemplate.opsForList().rightPop(key);
	}

	
	public V rightPop(K key, long timeout, TimeUnit unit) {
		return redisTemplate.opsForList().rightPop(key, timeout, unit);
	}

	
	public V rightPopAndLeftPush(K sourceKey, K destinationKey) {
		return redisTemplate.opsForList()
				.rightPopAndLeftPush(sourceKey, destinationKey);
	}

	
	public V rightPopAndLeftPush(K sourceKey, K destinationKey, long timeout,
			TimeUnit unit) {
		return redisTemplate.opsForList()
				.rightPopAndLeftPush(sourceKey, destinationKey, timeout, unit);
	}
	
	/** for hash */
	public boolean opsForMapHasKey(K key, K field) {
		
		return redisTemplate.opsForHash().hasKey(key, field);
	}
	
	public void opsForMapPut(K key, K field, V value) {
		redisTemplate.opsForHash().put(key, field, value);
	}
	
	public V opsForMapGet(K key, K field) {
		return (V) redisTemplate.opsForHash().get(key, field);
	}
	
	public void opsForMapDelete(K key, Object... hashKeys) {
		redisTemplate.opsForHash().delete(key, hashKeys);
	}
	

	
	public Map<K, V> opsForMapScan(K key) {
		Map<K, V> map = new HashMap<K,V>();
		Cursor<Entry<Object, Object>> cursor = null;
		try {
			cursor = redisTemplate.opsForHash().scan(key, ScanOptions.NONE);
			if(cursor != null) {
				while(cursor.hasNext()) {
					Map.Entry<K, V> entry = (Entry<K, V>) cursor.next();
					map.put(entry.getKey(), entry.getValue());
				}
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			if(cursor != null) {
				try {
					cursor.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					cursor = null;
				}
			}
		}
		
		return map;
	}
	
	/** redis 自增  start */
	
	public long inc(String key) {
		// TODO Auto-generated method stub
		return redisTemplate.opsForValue().increment((K) key, 1);
	}

	
	public long incBy(String key, long step) {
		return redisTemplate.opsForValue().increment((K) key, step);
	}
	/** redis 自增  end */
	
	
	protected RedisTemplate<K, V> getRedisTemplate() {
		RedisTemplate<K, V> template = redisTemplate;
		if(template == null) 
			throw new RuntimeException(); //该异常只会在开发阶段出现
		
		return template;
	}

	/**
	 * 设置过期
	 */
	
	public void expire(String key, long timeout, TimeUnit unit) {
		redisTemplate.expire((K) key, timeout, unit);
	}
	
	/**
	 * 过期时间
	 */
	
	public long getExpire(String key) {
		return redisTemplate.getExpire((K) key);
	}
	
	/** set oper */
	
	public Long sadd(K key, V... values) {
		return redisTemplate.opsForSet().add(key, values);
	}

	public Long scard(K key) {
		return redisTemplate.opsForSet().size(key);
	}
	
	public V sRandomMember(K key) {
		return redisTemplate.opsForSet().randomMember(key);
	}

	public V sPop(K key) {
		return redisTemplate.opsForSet().pop(key);
	}

	public Long sremove(K key, V... values) {
		return redisTemplate.opsForSet().remove(key, values);
	}

	public Set<String> keys(String pattern) {
		return stringRedisTemplate.keys(pattern);
	}
}