package com.wlzq.service.base.sys.biz;

import com.wlzq.service.base.sys.model.CoopRequestRecord;

/**
 * CoopRequestRecordBiz类
 * @author 
 * @version 1.0
 */
public interface CoopRequestRecordBiz {	
	
	void save(CoopRequestRecord record);
}
