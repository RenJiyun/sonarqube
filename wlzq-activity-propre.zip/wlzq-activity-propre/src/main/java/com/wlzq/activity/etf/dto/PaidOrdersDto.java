package com.wlzq.activity.etf.dto;

import lombok.Data;

@Data
public class PaidOrdersDto {
    /**
     * 客户号
     */
    private String customerId;
    /**
     * 用户ID
     */
    private String userId;
}
