package com.wlzq.activity.actWL20.dto;

import lombok.Data;

/**
 * 
 * @author jjw
 *
 */
@Data
public class ActFDRecieveDto {	
	private String code;		// 编码
	private String name;		// 名称
	private String value;		// 价值
}
