package com.wlzq.activity.renewed.biz;

import com.wlzq.core.dto.StatusDto;

public interface RenewedReceiveBiz {
    StatusDto batchReceive();
}
