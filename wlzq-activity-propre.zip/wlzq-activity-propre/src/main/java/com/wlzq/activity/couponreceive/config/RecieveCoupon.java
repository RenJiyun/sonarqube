package com.wlzq.activity.couponreceive.config;

import lombok.Data;

@Data
public class RecieveCoupon {
	private String id;
	private String couponTemplateCode;
	private Integer limit;
}
