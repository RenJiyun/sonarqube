package com.wlzq.activity.push.executor;

import com.wlzq.core.dto.StatusDto;

public interface BaseExecutor {

	public StatusDto run();
}
