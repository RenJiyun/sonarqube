package com.wlzq.activity.base.dto;

import java.util.List;

import lombok.Data;

/**
 * 
 * @author zhaozx
 * @version 2019-08-19
 */
@Data
public class PrizeCustomerListDto {

	private List<PrizeCustomerDto> dto;
}
